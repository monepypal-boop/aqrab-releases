/* ui-pages.js — الرئيسية، المبيعات، العملاء، المشتريات، المخزون */
'use strict';
const KINDL = { sale: 'بيع', collect: 'تحصيل', refund: 'رد مبلغ', 'sup-pay': 'سداد مورد', 'sup-refund': 'استرداد من مورد', expense: 'مصروف', 'expense-void': 'إلغاء مصروف', deposit: 'إيداع', withdraw: 'سحب', open: 'رصيد افتتاحي' };
const FLT = { inv: { q: '', st: '' }, sr: { from: '', to: '', c: '', r: '' }, prod: { q: '' }, mv: { p: '' }, cust: { q: '' }, sup: { q: '' }, pur: { q: '', from: '', to: '', s: '', st: '' } };
const userName = id => { const u = S().users.find(x => x.id === id); return u ? esc(u.name) : '—'; };
const curOpts = () => S().set.cur.filter(c => !c.unset).map(c => [c.code, c.code + ' — ' + c.name]);
const fmBal = o => { const e = Object.entries(o || {}).filter(([, v]) => v !== 0); return e.length ? e.map(([c, v]) => `<span class="${v > 0 ? 'bd' : 'ok'}">${fm(v, c)}</span>`).join('<br>') : '—'; };
const sumVals = o => Object.values(o).reduce((s, x) => s + x, 0);
const toB = (amt, cur, fx) => Engine.toBase(S(), amt, cur, fx);
const rateOf = cur => (cur === baseCode() ? 1000000 : cdef(cur).rate);
const prodDef = (p, cur, key) => (cur === baseCode() ? p[key] : Money.fromBase(p[key], decOf(baseCode()), decOf(cur), rateOf(cur)));
const lim = (a, n) => a.slice(0, n);
const notice = (n, tot) => (tot > n ? `<p class=mu style="font-size:12px">يُعرض أحدث ${n} من أصل ${tot}. استخدم البحث لتضييق النتائج.</p>` : '');
ACT.toPos = () => go('pos');
const newBtn = (a, label, perm) => (!perm || can(perm) ? `<button class=btn data-a=${a}>${label}</button>` : '');

/* ================= الرئيسية ================= */
PAGES.home = () => {
  const s = S(), b = baseCode(), pl = Engine.profitLoss(s, {}), cb = Engine.cashBalances(s), pmap = Engine.paidMap(s);
  let collected = 0; s.cash.forEach(c => { if (c.ref && c.ref.t === 'inv') collected += toB(c.amt, c.cur, c.fx); });
  let dues = 0; s.inv.forEach(i => { if (!i.void) { const v = Engine.invView(s, i, pmap); if (v.due > 0) dues += toB(v.due, i.cur, i.fx); } });
  const sdue = Object.values(Engine.balances(s, 'sup')).reduce((a, o) => a + Object.entries(o).reduce((x, [c, v]) => x + (v > 0 ? toB(v, c, rateOf(c)) : 0), 0), 0);
  const mon = Engine.periodReport(s, {}, 'month').slice(-6), mx = Math.max(1, ...mon.map(m => m.sales));
  const low = s.prod.filter(p => !p.arch && p.q <= p.mn), rec = Engine.reconcileList(s), okAll = rec.every(c => c.ok);
  const cashTxt = Object.keys(cb).length ? Object.entries(cb).map(([c, m]) => fm(sumVals(m), c)).join('<br>') : fm(0);
  const stk = Engine.stockReport(s), capCost = stk.reduce((a, x) => a + x.value, 0), capSell = stk.reduce((a, x) => a + Money.lineTotal(x.pr, Math.max(x.q, 0)), 0);
  AQ.homeDay = AQ.en.today(); AQ.homeAt = new Date();
  const todayStr = AQ.homeDay, yStr = (() => { const d = new Date(todayStr + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() - 1); return d.toISOString().slice(0, 10); })();
  const tp = Engine.profitLoss(s, { from: todayStr, to: todayStr }), yp = Engine.profitLoss(s, { from: yStr, to: yStr });
  const todayCol = s.cash.filter(c => c.date === todayStr && (c.kind === 'sale' || c.kind === 'collect')).reduce((a, c) => a + toB(c.amt, c.cur, c.fx), 0);
  const d7 = (() => { const d = new Date(todayStr + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() - 6); return d.toISOString().slice(0, 10); })();
  const last7 = Engine.periodReport(s, { from: d7, to: todayStr }, 'day').slice().reverse();
  const cmp = (a, b) => (b === 0 && a === 0 ? 'أمس: 0' : 'أمس: ' + fm(b) + (b !== 0 ? ' (' + (a >= b ? '▲' : '▼') + ' ' + Math.abs(Math.round((a - b) / Math.abs(b) * 100)) + '%)' : ''));
  const stamp = AQ.homeAt.toLocaleDateString('en-GB') + ' ' + AQ.homeAt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  return `<h2 class=pt>الرئيسية <small class=mu style="font-size:13px;font-weight:400">— آخر تحديث ${stamp} <button class=s data-a=homeRefresh>🔄 تحديث</button></small></h2>
  <h3 style="margin:0 0 8px">اليوم — ${todayStr}</h3>
  <div class=g><div class="k hi"><small>صافي ربح اليوم (بعد مصاريف اليوم)</small><b>${fm(tp.net)}</b><small>${cmp(tp.net, yp.net)}</small></div><div class=k><small>مبيعات اليوم (إجمالي الفواتير)</small><b>${fm(tp.salesTotal)}</b><small>${cmp(tp.salesTotal, yp.salesTotal)}</small></div><div class=k><small>عدد فواتير اليوم</small><b>${tp.invoices}</b><small>أمس: ${yp.invoices}</small></div><div class=k><small>المحصّل اليوم</small><b class=ok>${fm(todayCol)}</b></div></div>
  <div class=cd><h3>آخر 7 أيام ${newBtn('homeDay', 'فتح التقرير اليومي الكامل', 'rep')}</h3>${tbl(['اليوم', 'الفواتير', 'المبيعات', 'الربح', 'المصروفات', 'صافي الربح'], last7.map(r => [r.k + (r.k === todayStr ? ' ' + chip('اليوم') : ''), r.invoices, fm(r.sales), fm(r.profit), fm(r.expenses), `<b>${fm(r.net)}</b>`]), 'لا مبيعات في آخر 7 أيام')}<p class=mu style="margin:6px 0 0;font-size:12.5px">كل الفواتير محفوظة في «التقارير ← يومي / شهري» ولا تُحذف عند بدء يوم جديد؛ البطاقات أعلاه تبدأ من الصفر تلقائيًا مع كل يوم.</p></div>
  <h3 style="margin:0 0 8px">الإجمالي (كل الفترات)</h3>
  <div class=g><div class=k><small>صافي الربح (بعد المصاريف)</small><b>${fm(pl.net)}</b></div><div class=k><small>إجمالي المبيعات</small><b>${fm(pl.salesTotal)}</b></div><div class=k><small>المحصّل (صافي الرد)</small><b class=ok>${fm(collected)}</b></div><div class=k><small>مستحقات عند العملاء</small><b class=bd>${fm(dues)}</b></div><div class=k><small>مستحقات للموردين</small><b>${fm(sdue)}</b></div><div class=k><small>المصروفات</small><b>${fm(pl.expenses)}</b></div><div class=k><small>رصيد الصندوق (كل الطرق)</small><b>${cashTxt}</b></div><div class=k><small>رأس مال المخزون (بسعر التكلفة)</small><b>${fm(capCost)}</b><small>بسعر البيع: ${fm(capSell)} — ${stk.length} منتج</small></div></div>
  <div class=cd><h3>المبيعات الشهرية (آخر 6 أشهر)</h3>${mon.length ? `<div class=bars>${mon.map(m => `<div><i style="height:${Math.round(m.sales / mx * 120)}px"></i>${m.k}<br>${fm(m.sales)}</div>`).join('')}</div>` : '<p class=mu>لا توجد مبيعات بعد.</p>'}</div>
  <div class=cd><h3>تنبيهات المخزون</h3>${low.length ? lim(low, 15).map(p => `<p class=bd style="margin:4px 0">⚠ ${esc(p.n)}: المتبقي ${fq(p.q)}</p>`).join('') : '<p class=mu>كل المنتجات متوفرة بكميات كافية.</p>'}</div>
  <div class=cd><h3>مطابقة الحسابات ${okAll ? chip('سليمة ✓', 'ok') : chip('يوجد اختلاف', 'bd')}</h3><p class=mu style="margin:0">الأرقام أعلاه تُحتسب من الحركات المسجلة فقط. ${okAll ? 'كل فحوص الاتساق ناجحة.' : 'راجع صفحة التقارير ← المطابقة قبل الاعتماد على الأرقام.'}</p></div>
  ${newBtn('toPos', '+ فاتورة جديدة', 'sell')}`;
};

ACT.homeRefresh = () => render();
ACT.homeDay = () => { FLT.rp = Object.assign(FLT.rp || {}, { from: AQ.en.today(), to: AQ.en.today(), by: 'day' }); AQ.sub.reports = 'period'; go('reports'); };

/* ================= المبيعات ================= */
PAGES.sales = () => {
  const sub = curSub('sales', 'inv');
  return `<h2 class=pt>المبيعات</h2>${tabsHTML([['inv', 'الفواتير'], ['qt', 'عروض الأسعار'], ['ret', 'المرتجعات'], ['rep', 'تقرير المبيعات']], sub)}${sub === 'inv' ? salesInv() : sub === 'qt' ? salesQt() : sub === 'ret' ? salesRet() : salesRep()}`;
};
const invStatus = (i, v) => (i.void ? chip('ملغاة', 'mu') : v.due < 0 ? chip('رصيد للعميل') : v.due === 0 ? chip('مدفوعة', 'ok') : v.paid > 0 ? chip('جزئي') : chip('غير مدفوعة', 'bd'));
function salesInv() {
  const s = S(), f = FLT.inv, pmap = Engine.paidMap(s), q = f.q.trim().toLowerCase();
  const all0 = s.inv.slice().reverse().filter(i => riMatch(i, q)).map(i => ({ i, v: Engine.invView(s, i, pmap) }))
    .filter(x => !f.st || (f.st === 'void' ? x.i.void : f.st === 'open' ? !x.i.void && x.v.due > 0 : f.st === 'paid' ? !x.i.void && x.v.due <= 0 : true));
  const all = exactNo(all0, q, x => x.i.no);
  const rows = lim(all, 300).map(({ i, v }) => [esc(i.no) + ((i.rev || []).length ? ` <span class="chip mu" title="عُدّلت ${(i.rev || []).length} مرة">معدّلة</span>` : ''), i.date, esc(i.cn), fm(v.c.totEff, i.cur), fm(v.paid, i.cur), v.due ? `<span class="${v.due > 0 ? 'bd' : 'ok'}">${fm(v.due, i.cur)}</span>` : fm(0, i.cur), invStatus(i, v),
    btn('invDetail', 'تفاصيل', { id: i.id }) + btn('print', 'طباعة A5', { id: i.id }) + (i.void ? '' : (can('invedit') ? btn('invEdit', 'تعديل', { id: i.id }) : '') + (can('ret') ? btn('invRet', 'مرتجع', { id: i.id }) : '') + (can('collect') && v.due > 0 ? btn('invCollect', 'تسديد', { id: i.id }) : '') + (can('collect') && v.due < 0 ? btn('invRefund', 'رد رصيد', { id: i.id }) : '') + (can('void') ? btn('invVoid', 'إلغاء', { id: i.id }, 'dl') : ''))]);
  return `<div class=cd><div class=tb><label>بحث برقم الفاتورة أو العميل<input data-c=invq value="${esc(f.q)}"></label><label>الحالة<select data-c=invst><option value="">الكل</option><option value=open${f.st === 'open' ? ' selected' : ''}>غير مسددة</option><option value=paid${f.st === 'paid' ? ' selected' : ''}>مسددة</option><option value=void${f.st === 'void' ? ' selected' : ''}>ملغاة</option></select></label>${newBtn('toPos', '+ فاتورة جديدة', 'sell')}</div>${tbl(['الرقم', 'التاريخ', 'العميل', 'الإجمالي', 'المدفوع', 'المتبقي', 'الحالة', ''], rows)}${notice(300, all.length)}</div>`;
}
CHG.invq = v => { FLT.inv.q = v; render(); };
CHG.invst = v => { FLT.inv.st = v; render(); };

/* ---- محرر البنود المشترك (تعديل فاتورة بيع / فاتورة شراء) ---- */
const LE = { mode: '', id: '', rows: [], cur: '', req: '' };
const leKey = () => (LE.mode === 'pur' ? 'co' : 'pr');
const leProdOpts = sel => S().prod.filter(p => !p.arch || p.id === sel).map(p => `<option value="${esc(p.id)}"${p.id === sel ? ' selected' : ''}>${esc(p.n)} (${Money.fmtQty(p.q)})</option>`).join('');
function leRowsHTML() {
  return LE.rows.map((r, k) => `<div class=lerow><select data-c=lep data-k=${k}>${leProdOpts(r.p)}</select><input data-i=leq data-k=${k} value="${esc(r.qs)}" inputmode=decimal title="الكمية"><input data-i=lepr data-k=${k} value="${esc(r.ps)}" inputmode=decimal title="${LE.mode === 'pur' ? 'سعر الشراء' : 'سعر البيع'}"><span class="num lt" id=let_${k}></span>${LE.rows.length > 1 ? `<button class="s dl" data-a=leDel data-k=${k}>×</button>` : '<span></span>'}</div>`).join('');
}
function leDefPrice(pid) { const p = S().prod.find(x => x.id === pid); return Money.fmt(prodDef(p, LE.cur, LE.mode === 'pur' ? 'co' : 'pr'), decOf(LE.cur), { nogroup: true }); }
function leParse() {
  const dec = decOf(LE.cur);
  const items = LE.rows.map(r => ({ p: r.p, q: Money.parse(r.qs, 3), pr: Money.parse(r.ps, dec) }));
  const bad = items.some(x => x.q === null || x.q <= 0 || x.pr === null || x.pr < 0);
  let disc = 0, derr = ''; const ds = ($('#led2') || {}).value || '';
  if (ds.trim() !== '') { const d = Money.parse(ds, dec); if (d === null || d < 0) derr = 'الخصم غير صحيح'; else disc = d; }
  return { items: items.map(x => ({ p: x.p, q: x.q, pr: x.pr, co: x.pr })), bad, disc, derr, dec };
}
function leTot() {
  const o = leParse(), el = $('#letot'); if (!el) return;
  if (o.bad || o.derr) { el.innerHTML = `<span class=bd>${o.derr || 'تحقق من الكميات والأسعار'}</span>`; return; }
  const rate = LE.mode === 'pur' ? (Money.parse((($('#lerate') || {}).value || '0'), 2) || 0) : LE.rate;
  const sub = o.items.reduce((s, x) => s + Money.lineTotal(x.pr, x.q), 0);
  if (o.disc > sub) { el.innerHTML = '<span class=bd>الخصم أكبر من المجموع</span>'; return; }
  const c = Engine.calcDoc({ items: o.items, disc: o.disc, rate }, leKey());
  o.items.forEach((x, k) => { const e = $('#let_' + k); if (e) e.innerHTML = fm(c.lines[k].total, LE.cur); });
  el.innerHTML = `المجموع <b>${fm(c.sub, LE.cur)}</b> | الصافي <b>${fm(c.net, LE.cur)}</b> | الضريبة <b>${fm(c.tax, LE.cur)}</b> | الإجمالي <b>${fm(c.tot, LE.cur)}</b>`;
}
INP.leq = (v, el) => { LE.rows[+el.dataset.k].qs = v; leTot(); };
INP.lepr = (v, el) => { LE.rows[+el.dataset.k].ps = v; leTot(); };
INP.ledisc = () => leTot();
CHG.lep = (v, el) => { const r = LE.rows[+el.dataset.k]; r.p = v; r.ps = leDefPrice(v); $('#lerows').innerHTML = leRowsHTML(); leTot(); };
ACT.leDel = d => { LE.rows.splice(+d.k, 1); $('#lerows').innerHTML = leRowsHTML(); leTot(); };
ACT.leAdd = () => { const p = S().prod.find(x => !x.arch); if (!p) { toast('أضف منتجًا أولًا', 'err'); return; } LE.rows.push({ p: p.id, qs: '1', ps: leDefPrice(p.id) }); $('#lerows').innerHTML = leRowsHTML(); leTot(); };
const optsHTML = (list, sel, blank) => (blank != null ? `<option value="">${blank}</option>` : '') + list.map(([v, l]) => `<option value="${esc(v)}"${String(v) === String(sel) ? ' selected' : ''}>${esc(l)}</option>`).join('');
function leModal(title, head, foot) {
  $('#md').innerHTML = `<div class=ov><div class="bx wide"><h3>${title}</h3><div class=tb>${head}</div><div class=lerow style="font-size:12px;color:var(--mu)"><span>المنتج (المتاح)</span><span>الكمية</span><span>${LE.mode === 'pur' ? 'سعر الشراء' : 'السعر'}</span><span>المجموع</span><span></span></div><div id=lerows>${leRowsHTML()}</div><button class=g2 data-a=leAdd>+ بند</button>
  <div class=tb style="margin-top:10px">${foot}</div><div id=letot class=cd style="margin:8px 0"></div><p id=er class=bd></p><div class=ac><button class=btn id=lesave>حفظ</button><button class=g2 data-a=close>إلغاء</button></div></div></div>`;
  leTot();
}

/* ---- تسديد / رد رصيد / إلغاء ---- */
ACT.invCollect = d => {
  const i = S().inv.find(x => x.id === d.id), v = Engine.invView(S(), i), dec = decOf(i.cur);
  form({ title: 'تسديد دفعة — ' + esc(i.no), msg: 'المتبقي: ' + fm(v.due, i.cur), fields: [{ k: 'a', l: 'المبلغ', t: 'money', dec, req: 1 }, { k: 'm', l: 'طريقة الدفع', t: 'select', opts: METHODS }, { k: 'd', l: 'التاريخ', t: 'date' }], values: { a: mInput(v.due, dec), d: today() },
    submit: async o => { AQ.en.collect(i.id, o.a, o.m, AQ.me, o.d); toast('تم تسجيل الدفعة', 'ok'); render(); } });
};
ACT.invRefund = d => {
  const i = S().inv.find(x => x.id === d.id), v = Engine.invView(S(), i), dec = decOf(i.cur);
  form({ title: 'رد رصيد للعميل — ' + esc(i.no), msg: 'الرصيد الدائن للعميل: ' + fm(-v.due, i.cur) + ' (سيخرج من الصندوق)', fields: [{ k: 'a', l: 'المبلغ', t: 'money', dec, req: 1 }, { k: 'm', l: 'طريقة الرد', t: 'select', opts: METHODS }, { k: 'd', l: 'التاريخ', t: 'date' }], values: { a: mInput(-v.due, dec), d: today() },
    submit: async o => { AQ.en.refundCustomer(i.id, o.a, o.m, AQ.me, o.d); toast('تم رد المبلغ', 'ok'); render(); } });
};
ACT.invVoid = d => {
  const i = S().inv.find(x => x.id === d.id), v = Engine.invView(S(), i);
  form({ title: 'إلغاء الفاتورة ' + esc(i.no), msg: 'لا تُحذف الفاتورة؛ تُعلَّم ملغاة ويُسجَّل الأثر في سجل التدقيق. ستعود الكميات إلى المخزون' + (v.paid > 0 ? ' ويُردّ المبلغ المدفوع (' + fm(v.paid, i.cur) + ') من الصندوق.' : '.'),
    fields: [{ k: 'reason', l: 'سبب الإلغاء', req: 1, full: 1 }, ...(v.paid > 0 ? [{ k: 'm', l: 'طريقة رد المبلغ', t: 'select', opts: METHODS }] : [])], ok: 'إلغاء الفاتورة',
    submit: async o => { AQ.en.voidSale(i.id, { reason: o.reason, method: o.m || 'cash', user: AQ.me }); toast('تم إلغاء الفاتورة', 'ok'); render(); } });
};

/* ---- المرتجعات ---- */
const RT = { kind: 'sale', id: '', touched: false };
function rtLines() { const inv = RT.kind === 'sale' ? S().inv.find(x => x.id === RT.id) : S().pur.find(x => x.id === RT.id); return inv.items.map((x, k) => ({ k, q: Money.parse(($('#rq_' + k) || {}).value || '0', 3) })).filter(l => l.q !== null && l.q > 0); }
function rtPreview() {
  const s = S(), doc = RT.kind === 'sale' ? s.inv.find(x => x.id === RT.id) : s.pur.find(x => x.id === RT.id), key = RT.kind === 'sale' ? 'pr' : 'co';
  const lines = rtLines(), t = JSON.parse(JSON.stringify(doc)); t.rt = (t.rt || []).concat([{ id: 'tmp', lines, ts: '' }]);
  const c = Engine.calcDoc(t, key), v = RT.kind === 'sale' ? Engine.invView(s, doc) : Engine.purView(s, doc);
  const max = Math.max(0, v.paid - c.totEff), val = lines.length ? c.returns.tmp.gross : 0;
  $('#rtval').innerHTML = `قيمة المرتجع: <b>${fm(val, doc.cur)}</b> | القابل للرد: <b>${fm(max, doc.cur)}</b>`;
  const ra = $('#rta'); if (!RT.touched) ra.value = Money.fmt(max, decOf(doc.cur), { nogroup: true });
}
INP.rtq = () => rtPreview();
INP.rta = () => { RT.touched = true; };
function retDialog(kind, id) {
  const s = S(), doc = kind === 'sale' ? s.inv.find(x => x.id === id) : s.pur.find(x => x.id === id), c = kind === 'sale' ? Engine.calcInv(doc) : Engine.calcPur(doc);
  RT.kind = kind; RT.id = id; RT.touched = false; const dec = decOf(doc.cur);
  const rows = doc.items.map((x, k) => [esc(x.n), fq(x.q), fq(c.lines[k].left), c.lines[k].left > 0 ? `<input id=rq_${k} data-i=rtq value="0" inputmode=decimal style="width:90px;direction:ltr">` : '—']);
  $('#md').innerHTML = `<div class=ov><div class="bx mid"><h3>${kind === 'sale' ? 'مرتجع مبيعات' : 'مرتجع مشتريات للمورد'} — ${esc(doc.no)}</h3>${tbl(['المنتج', 'الكمية', 'المتاح للإرجاع', 'الكمية المرتجعة'], rows)}
  <div id=rtval class=cd style="margin:10px 0"></div><div class=tb><label>مبلغ ${kind === 'sale' ? 'الرد للعميل' : 'الاسترداد من المورد'} (${esc(doc.cur)}) — ${kind === 'sale' && !doc.c ? 'فاتورة بدون عميل: يُرَدّ المدفوع كاملًا تلقائيًا' : 'اتركه 0 لإبقائه رصيدًا'}<input id=rta data-i=rta inputmode=decimal value="0"></label><label>الطريقة<select id=rtm>${optsHTML(METHODS, 'cash')}</select></label><label>التاريخ<input id=rtd type=date value="${today()}"></label></div>
  <p id=er class=bd></p><div class=ac><button class=btn id=rtok>تسجيل المرتجع</button><button class=g2 data-a=close>إلغاء</button></div></div></div>`;
  rtPreview();
  $('#rtok').onclick = () => {
    try {
      const lines = rtLines(); if (!lines.length) throw new Error('اختر كمية للإرجاع');
      const amt = Money.parse($('#rta').value || '0', dec); if (amt === null || amt < 0) throw new Error('مبلغ الرد غير صحيح');
      const o = { lines, date: $('#rtd').value, refund: amt ? { amt, method: $('#rtm').value } : null, user: AQ.me, req: AQ.en.uid() };
      if (kind === 'sale') AQ.en.returnItems(id, o); else AQ.en.returnPurchase(id, o);
      closeModal(); toast('تم تسجيل المرتجع', 'ok'); render();
    } catch (e) { $('#er').textContent = e.message; }
  };
}
ACT.invRet = d => retDialog('sale', d.id);
function salesRet() {
  const s = S(), rows = [];
  s.inv.forEach(i => { const c = Engine.calcInv(i); (i.rt || []).forEach(r => rows.push({ r, i, c })); });
  rows.sort((a, b) => (a.r.date + a.r.ts < b.r.date + b.r.ts ? 1 : -1));
  const tot = rows.filter(x => !x.r.void).reduce((a, x) => a + toB(x.c.returns[x.r.id].gross, x.i.cur, x.i.fx), 0);
  return `<div class=g><div class="k hi"><small>إجمالي المرتجعات</small><b>${fm(tot)}</b></div><div class=k><small>عدد العمليات</small><b>${rows.filter(x => !x.r.void).length}</b></div></div><div class=cd><p class=mu style="margin-top:0">لتسجيل مرتجع اضغط «مرتجع» بجانب الفاتورة من تبويب الفواتير.</p>${tbl(['التاريخ', 'المرتجع', 'الفاتورة', 'العميل', 'المنتجات', 'القيمة', 'الحالة', ''], lim(rows, 300).map(x => [x.r.date, esc(x.r.no || ''), esc(x.i.no), esc(x.i.cn), x.r.lines.map(l => esc(x.i.items[l.k].n) + ' × ' + Money.fmtQty(l.q)).join('، '), fm(x.c.returns[x.r.id].gross, x.i.cur), x.r.void ? chip('ملغى', 'mu') : chip('نافذ', 'ok'), !x.r.void && can('ret') && !x.i.void ? btn('rtVoid', 'إلغاء المرتجع', { i: x.i.id, r: x.r.id }, 'dl') : '']))}</div>`;
}
ACT.rtVoid = d => ask('إلغاء المرتجع', 'ستُخصم الكمية من المخزون من جديد. ملاحظة: إن كنت قد رددت مبلغًا نقدًا للعميل فسجّل ذلك يدويًا (تسديد) إذا لزم.', () => { AQ.en.voidReturn(d.i, d.r, AQ.me); toast('تم إلغاء المرتجع', 'ok'); render(); }, 'إلغاء المرتجع');

/* ---- تقرير المبيعات ---- */
function salesRep() {
  const s = S(), f = FLT.sr, rows = Engine.salesRows(s, { from: f.from, to: f.to, c: f.c, r: f.r });
  const tot = rows.reduce((a, r) => a + r.totBase, 0), profit = rows.reduce((a, r) => a + r.profitBase, 0), by = {};
  rows.forEach(r => { by[r.cn] = (by[r.cn] || 0) + r.totBase; });
  const invMap = {}; s.inv.forEach(i => { invMap[i.id] = i; });
  const paid = rows.reduce((a, r) => a + toB(r.paid, r.cur, invMap[r.id].fx), 0), due = rows.reduce((a, r) => a + toB(r.due, r.cur, invMap[r.id].fx), 0);
  const sel = (id, list, v, all) => `<select data-c=${id}><option value="">${all}</option>${list.map(x => `<option value="${esc(x.id)}"${v === x.id ? ' selected' : ''}>${esc(x.n)}</option>`).join('')}</select>`;
  return `<div class=cd><div class=tb><label>من<input type=date data-c=srfrom value="${f.from}"></label><label>إلى<input type=date data-c=srto value="${f.to}"></label><label>العميل${sel('src', s.cust, f.c, 'الكل')}</label><label>المندوب${sel('srr', s.rep, f.r, 'الكل')}</label></div>
  <div class=g><div class="k hi"><small>إجمالي المبيعات (${esc(baseCode())})</small><b>${fm(tot)}</b></div><div class=k><small>عدد الفواتير</small><b>${rows.length}</b></div><div class=k><small>المحصّل</small><b class=ok>${fm(paid)}</b></div><div class=k><small>المتبقي</small><b class=bd>${fm(due)}</b></div><div class=k><small>الربح الإجمالي</small><b>${fm(profit)}</b></div></div></div>
  <div class=cd><h3>المبيعات حسب العميل</h3>${tbl(['العميل', 'المبيعات', 'النسبة'], Object.entries(by).sort((a, b) => b[1] - a[1]).map(([k, v]) => [esc(k), fm(v), (tot ? Money.fmt(Money.mulDiv(v, 10000, tot), 2) : '0.00') + '%']))}</div>
  <div class=cd><h3>أداء المندوبين</h3>${tbl(['المندوب', 'صافي المبيعات', 'العمولة %', 'العمولة'], s.rep.map(r => { const n = rows.filter(x => x.rep === r.id).reduce((a, x) => a + x.netBase, 0); return [esc(r.n), fm(n), Money.fmtPct(r.r) + '%', fm(Money.pct(n, r.r))]; }))}<small class=mu>العمولة تُحسب على صافي المبيعات بعد الخصم وقبل الضريبة وبعد المرتجعات.</small></div>`;
}
CHG.srfrom = v => { FLT.sr.from = v; render(); }; CHG.srto = v => { FLT.sr.to = v; render(); };
CHG.src = v => { FLT.sr.c = v; render(); }; CHG.srr = v => { FLT.sr.r = v; render(); };

/* ================= العملاء والمندوبون ================= */
PAGES.customers = () => {
  const sub = curSub('customers', 'cust'), s = S();
  const head = `${newBtn(sub === 'cust' ? 'custAdd' : 'repAdd', '+ إضافة', 'party')}`;
  if (sub === 'rep') return `<h2 class=pt>العملاء والمندوبون</h2>${tabsHTML([['cust', 'العملاء'], ['rep', 'المندوبون']], sub)}<div class=cd><div class=tb style="justify-content:flex-end">${head}</div>${tbl(['الاسم', 'العمولة', ''], s.rep.filter(r => !r.arch).map(r => [esc(r.n), Money.fmtPct(r.r) + '%', can('party') ? btn('repEdit', 'تعديل', { id: r.id }) + btn('entDel', 'حذف', { k: 'rep', id: r.id }, 'dl') : '']))}</div>`;
  const bal = Engine.balances(s, 'cust');
  return `<h2 class=pt>العملاء والمندوبون</h2>${tabsHTML([['cust', 'العملاء'], ['rep', 'المندوبون']], sub)}<div class=cd><div class=tb><label>بحث باسم العميل أو الهاتف<input data-c=custq value="${esc(FLT.cust.q)}" placeholder="اكتب الاسم..."></label>${head}</div>${tbl(['الاسم', 'الهاتف', 'الرصيد المستحق', ''], s.cust.filter(c => !c.arch && partyMatch(c, FLT.cust.q)).map(c => [esc(c.n), esc(c.ph), fmBal(bal[c.id]), btn('stmt', 'كشف حساب', { k: 'cust', id: c.id }) + (can('collect') && Object.values(bal[c.id] || {}).some(v => v > 0) ? btn('custCollect', 'تحصيل', { id: c.id }) : '') + (can('party') ? btn('custEdit', 'تعديل', { id: c.id }) + btn('entDel', 'حذف', { k: 'cust', id: c.id }, 'dl') : '')]))}</div>`;
};
const partyMatch = (c, q) => { q = nrm(q); return !q || nrm(c.n).includes(q) || String(c.ph || '').replace(/\s/g, '').includes(q.replace(/\s/g, '')); };
CHG.custq = v => { FLT.cust.q = v; render(); }; CHG.supq = v => { FLT.sup.q = v; render(); };
const partyFields = [{ k: 'n', l: 'الاسم', req: 1, full: 1 }, { k: 'ph', l: 'الهاتف' }, { k: 'ad', l: 'العنوان' }];
const repFields = [{ k: 'n', l: 'الاسم', req: 1, full: 1 }, { k: 'r', l: 'نسبة العمولة %', t: 'pct' }];
ACT.custAdd = () => form({ title: 'إضافة عميل', fields: partyFields, submit: async v => { AQ.en.addParty('cust', Object.assign({ user: AQ.me }, v)); render(); } });
ACT.custEdit = d => { const c = S().cust.find(x => x.id === d.id); form({ title: 'تعديل عميل', fields: partyFields, values: c, submit: async v => { AQ.en.updateParty('cust', c.id, Object.assign({ user: AQ.me }, v)); render(); } }); };
ACT.repAdd = () => form({ title: 'إضافة مندوب', fields: repFields, submit: async v => { AQ.en.addParty('rep', Object.assign({ user: AQ.me }, v)); render(); } });
ACT.repEdit = d => { const c = S().rep.find(x => x.id === d.id); form({ title: 'تعديل مندوب', fields: repFields, values: { n: c.n, r: Money.fmt(c.r, 2, { nogroup: true }) }, submit: async v => { AQ.en.updateParty('rep', c.id, Object.assign({ user: AQ.me }, v)); render(); } }); };
ACT.entDel = d => ask('حذف', 'هل تريد الحذف؟ إن كان العنصر مستخدمًا في فواتير فسيُؤرشف (يختفي من القوائم وتبقى فواتيره سليمة).', () => { const r = AQ.en.removeEntity(d.k, d.id, AQ.me); toast(r === 'archived' ? 'تمت الأرشفة لأنه مستخدم في مستندات' : 'تم الحذف', 'ok'); render(); });
ACT.custCollect = d => {
  const b = Engine.balances(S(), 'cust')[d.id] || {}, cs = Object.entries(b).filter(([, v]) => v > 0);
  form({ title: 'تحصيل من العميل', msg: 'يُوزَّع المبلغ على أقدم الفواتير المستحقة أولًا. المستحق: ' + cs.map(([c, v]) => fm(v, c)).join(' + '), fields: [{ k: 'cur', l: 'العملة', t: 'select', opts: cs.map(([c]) => [c, c]) }, { k: 'a', l: 'المبلغ', t: 'money', dec: () => decOf($('#f_cur').value), req: 1 }, { k: 'm', l: 'طريقة الدفع', t: 'select', opts: METHODS }, { k: 'd', l: 'التاريخ', t: 'date' }], values: { d: today(), a: cs[0] ? mInput(cs[0][1], decOf(cs[0][0])) : '' },
    submit: async o => { const r = AQ.en.collectParty(d.id, o.cur, o.a, o.m, AQ.me, o.d); toast('تم التحصيل', 'ok'); render(); vchDone({ kind: 'in', pk: 'cust', pid: d.id, cur: o.cur, amt: o.a, method: o.m, date: r.date, parts: r.parts }); } });
};
ACT.stmt = d => {
  const s = S(), e = s.cust.concat(s.sup).find(x => x.id === d.id), r = Engine.statement(s, d.k, d.id);
  const tb = tbl(['التاريخ', 'البيان', 'المرجع', 'عليه / مدين', 'له / دائن', 'الرصيد'], r.rows.map(x => [x.date, x.type, esc(x.ref), x.d ? fm(x.d, x.cur) : '', x.c ? fm(x.c, x.cur) : '', fm(x.bal, x.cur)]));
  $('#md').innerHTML = `<div class=ov><div class="bx wide"><h3>كشف حساب — ${esc(e ? e.n : '')}</h3>${tb}<p>الأرصدة الحالية: ${fmBal(r.balances)}</p><div class=ac><button class=btn data-a=stmtPrint data-k="${d.k}" data-id="${esc(d.id)}">🖨 طباعة</button><button class=g2 data-a=close>إغلاق</button></div></div></div>`;
};
ACT.stmtPrint = d => {
  const s = S(), e = s.cust.concat(s.sup).find(x => x.id === d.id), r = Engine.statement(s, d.k, d.id);
  printHTML(`<div class=iv><div class=hd><h1 style="margin:0">${esc(s.co.n)}</h1></div><h2>كشف حساب — ${esc(e ? e.n : '')}</h2>${tbl(['التاريخ', 'البيان', 'المرجع', 'مدين', 'دائن', 'الرصيد'], r.rows.map(x => [x.date, x.type, esc(x.ref), x.d ? fm(x.d, x.cur) : '', x.c ? fm(x.c, x.cur) : '', fm(x.bal, x.cur)]))}<p>الرصيد: ${fmBal(r.balances)}</p></div>`, 'a4');
};

/* ================= المشتريات والموردون ================= */
PAGES.purchases = () => {
  const sub = curSub('purchases', 'pur'), s = S();
  const tabs = tabsHTML([['pur', 'فواتير الشراء'], ['sup', 'الموردون']], sub);
  if (sub === 'sup') {
    const bal = Engine.balances(s, 'sup');
    return `<h2 class=pt>المشتريات والموردون</h2>${tabs}<div class=cd><div class=tb><label>بحث باسم المورد أو الهاتف<input data-c=supq value="${esc(FLT.sup.q)}" placeholder="اكتب الاسم..."></label>${newBtn('supAdd', '+ مورد', 'party')}</div>${tbl(['الاسم', 'الهاتف', 'المستحق للمورد', ''], s.sup.filter(c => !c.arch && partyMatch(c, FLT.sup.q)).map(c => [esc(c.n), esc(c.ph), fmBal(bal[c.id]), btn('stmt', 'كشف حساب', { k: 'sup', id: c.id }) + (can('collect') && Object.values(bal[c.id] || {}).some(v => v > 0) ? btn('supPay', 'سداد', { id: c.id }) : '') + (can('party') ? btn('supEdit', 'تعديل', { id: c.id }) + btn('entDel', 'حذف', { k: 'sup', id: c.id }, 'dl') : '')]))}</div>`;
  }
  const f = FLT.pur, pm_ = Engine.purPaidMap(s), all = purList(), cnt = all.filter(x => !x.p.void);
  const sel = (id, k, opts, lbl) => `<label>${lbl}<select data-c=${id}>${optsHTML(opts, f[k], 'الكل')}</select></label>`;
  return `<h2 class=pt>المشتريات والموردون</h2>${tabs}<div class=cd><div class=tb style="flex-wrap:wrap;gap:8px"><label>بحث برقم الفاتورة أو المورد أو مرجع المورد<input data-c=purq value="${esc(f.q)}"></label><label>من تاريخ<input type=date data-c=purfrom value="${esc(f.from)}"></label><label>إلى تاريخ<input type=date data-c=purto value="${esc(f.to)}"></label>${sel('purs', 's', s.sup.map(c => [c.id, c.n]), 'المورد')}${sel('purst', 'st', [['due', 'غير مسددة/جزئي'], ['paid', 'مسددة'], ['void', 'ملغاة']], 'الحالة')}<button class=g2 data-a=purClear>مسح الفلاتر</button><button class=g2 data-a=xlPur>📥 تصدير Excel</button>${newBtn('purNew', '+ فاتورة شراء', 'buy')}</div>
  <p class=mu style="margin-top:0">${all.length} فاتورة — غير الملغاة: ${cnt.length}. اضغط «تفاصيل» لعرض كل فاتورة لوحدها.</p>
  ${tbl(['الرقم', 'التاريخ', 'المورد', 'العملة', 'الإجمالي', 'المدفوع', 'المتبقي', 'الحالة', ''], lim(all, 300).map(({ p, v }) => [esc(p.no), p.date, esc(p.sn), esc(p.cur), fm(v.c.totEff, p.cur), fm(v.paid, p.cur), v.due ? `<span class=bd>${fm(v.due, p.cur)}</span>` : fm(0, p.cur), p.void ? chip('ملغاة', 'mu') : v.due > 0 ? chip(v.paid > 0 ? 'جزئي' : 'غير مسددة', 'bd') : chip('مسددة', 'ok'), btn('purDetail', 'تفاصيل', { id: p.id }) + btn('purPrint', 'طباعة A5', { id: p.id }) + (p.void ? '' : (can('collect') && v.due > 0 ? btn('purPay', 'سداد', { id: p.id }) : '') + (can('buy') ? btn('purRet', 'مرتجع', { id: p.id }) + btn('purVoid', 'إلغاء', { id: p.id }, 'dl') : ''))]))}${notice(300, all.length)}</div>`;
};
CHG.purq = v => { FLT.pur.q = v; render(); };
ACT.supAdd = () => form({ title: 'إضافة مورد', fields: partyFields, submit: async v => { AQ.en.addParty('sup', Object.assign({ user: AQ.me }, v)); render(); } });
ACT.supEdit = d => { const c = S().sup.find(x => x.id === d.id); form({ title: 'تعديل مورد', fields: partyFields, values: c, submit: async v => { AQ.en.updateParty('sup', c.id, Object.assign({ user: AQ.me }, v)); render(); } }); };
ACT.supPay = d => {
  const b = Engine.balances(S(), 'sup')[d.id] || {}, cs = Object.entries(b).filter(([, v]) => v > 0);
  form({ title: 'سداد للمورد', msg: 'يُوزَّع المبلغ على أقدم الفواتير أولًا. المستحق: ' + cs.map(([c, v]) => fm(v, c)).join(' + '), fields: [{ k: 'cur', l: 'العملة', t: 'select', opts: cs.map(([c]) => [c, c]) }, { k: 'a', l: 'المبلغ', t: 'money', dec: () => decOf($('#f_cur').value), req: 1 }, { k: 'm', l: 'طريقة الدفع', t: 'select', opts: METHODS }, { k: 'd', l: 'التاريخ', t: 'date' }], values: { d: today(), a: cs[0] ? mInput(cs[0][1], decOf(cs[0][0])) : '' },
    submit: async o => { const r = AQ.en.payParty(d.id, o.cur, o.a, o.m, AQ.me, o.d); toast('تم السداد', 'ok'); render(); vchDone({ kind: 'out', pk: 'sup', pid: d.id, cur: o.cur, amt: o.a, method: o.m, date: r.date, parts: r.parts }); } });
};
ACT.purPay = d => {
  const p = S().pur.find(x => x.id === d.id), v = Engine.purView(S(), p), dec = decOf(p.cur);
  form({ title: 'سداد — ' + esc(p.no), msg: 'المتبقي: ' + fm(v.due, p.cur), fields: [{ k: 'a', l: 'المبلغ', t: 'money', dec, req: 1 }, { k: 'm', l: 'طريقة الدفع', t: 'select', opts: METHODS }, { k: 'd', l: 'التاريخ', t: 'date' }], values: { a: mInput(v.due, dec), d: today() },
    submit: async o => { AQ.en.payPurchase(p.id, o.a, o.m, AQ.me, o.d); toast('تم السداد', 'ok'); render(); } });
};
ACT.purRet = d => retDialog('pur', d.id);
ACT.purVoid = d => {
  const p = S().pur.find(x => x.id === d.id);
  form({ title: 'إلغاء فاتورة الشراء ' + esc(p.no), msg: 'ستُخصم الكميات من المخزون ويُسجَّل استرداد ما دُفع للمورد. لا تُحذف الفاتورة.', fields: [{ k: 'reason', l: 'سبب الإلغاء', req: 1, full: 1 }], ok: 'إلغاء الفاتورة', submit: async o => { AQ.en.voidPurchase(p.id, { reason: o.reason, user: AQ.me }); toast('تم الإلغاء', 'ok'); render(); } });
};
ACT.purNew = () => {
  const s = S(); if (!s.prod.some(p => !p.arch)) return toast('أضف منتجًا أولًا من صفحة المخزون', 'err');
  const cur = baseCode(), p0 = s.prod.find(p => !p.arch);
  Object.assign(LE, { mode: 'pur', id: '', cur, req: AQ.en.uid(), rate: 0, rows: [{ p: p0.id, qs: '1', ps: '' }] }); LE.rows[0].ps = leDefPrice(p0.id);
  leModal('فاتورة شراء جديدة', `<label>المورد<select id=lec>${optsHTML(s.sup.filter(c => !c.arch).map(c => [c.id, c.n]), '', 'مورد نقدي')}</select></label><label>العملة<select id=lecur data-c=lecur>${optsHTML(curOpts(), cur)}</select></label><label>التاريخ<input id=led type=date value="${today()}"></label><label>رقم فاتورة المورد<input id=leref></label>`,
    `<label>الخصم<input id=led2 data-i=ledisc inputmode=decimal></label><label>الضريبة %<input id=lerate data-i=ledisc value="0" inputmode=decimal></label><label>المدفوع للمورد<input id=lepaid inputmode=decimal value="0"></label><label>طريقة الدفع<select id=lem>${optsHTML(METHODS, 'cash')}</select></label>`);
  $('#lesave').onclick = () => {
    try {
      const o = leParse(); if (o.bad || o.derr) throw new Error(o.derr || 'تحقق من الكميات والأسعار');
      const rate = Money.parse($('#lerate').value || '0', 2), paid = Money.parse($('#lepaid').value || '0', o.dec);
      if (rate === null || rate < 0 || paid === null || paid < 0) throw new Error('قيمة غير صحيحة في الضريبة أو المدفوع');
      const r = AQ.en.createPurchase({ req: LE.req, date: $('#led').value, s: $('#lec').value, cur: LE.cur, fx: rateOf(LE.cur), items: o.items.map(x => ({ p: x.p, q: x.q, co: x.pr })), disc: o.disc, rate, ref: $('#leref').value.trim(), pay: { amt: paid, method: $('#lem').value }, user: AQ.me });
      closeModal(); toast('تم حفظ ' + r.no, 'ok'); render();
    } catch (e) { $('#er').textContent = e.message; }
  };
};
CHG.lecur = v => { LE.cur = v; LE.rows.forEach(r => { r.ps = leDefPrice(r.p); }); $('#lerows').innerHTML = leRowsHTML(); leTot(); };

/* ================= المخزون والمنتجات ================= */
PAGES.inventory = () => {
  const sub = curSub('inventory', 'prod'), s = S(), tabs = tabsHTML([['prod', 'المنتجات'], ['mv', 'حركة المخزون'], ['stock', 'تقرير المخزون'], ['cnt', 'الجرد']], sub);
  if (sub === 'cnt') return `<h2 class=pt>المخزون والمنتجات</h2>${tabs}${cntPage()}`;
  if (sub === 'mv') {
    const f = FLT.mv, pn = {}; s.prod.forEach(p => { pn[p.id] = p.n; });
    const l = s.mv.filter(m => !f.p || m.p === f.p).slice().reverse();
    const MVL = { count: 'جرد', open: 'رصيد افتتاحي', sale: 'بيع', 'sale-edit': 'تعديل فاتورة', 'sale-void': 'إلغاء فاتورة', return: 'مرتجع بيع', 'return-void': 'إلغاء مرتجع', purchase: 'شراء', 'pur-return': 'مرتجع شراء', 'pur-void': 'إلغاء شراء', adjust: 'تسوية' };
    return `<h2 class=pt>المخزون والمنتجات</h2>${tabs}<div class=cd><div class=tb><label>المنتج<select data-c=mvp><option value="">الكل</option>${s.prod.map(p => `<option value="${esc(p.id)}"${f.p === p.id ? ' selected' : ''}>${esc(p.n)}</option>`).join('')}</select></label></div>${tbl(['الوقت', 'المنتج', 'النوع', 'التغيير', 'بواسطة'], lim(l, 300).map(m => [fdt(m.ts), esc(pn[m.p] || '—'), MVL[m.kind] || esc(m.kind), `<span class="num ${m.dq < 0 ? 'bd' : 'ok'}">${fq(m.dq)}</span>`, userName(m.by)]))}${notice(300, l.length)}</div>`;
  }
  if (sub === 'stock') {
    const r = Engine.stockReport(s), tot = r.reduce((a, x) => a + x.value, 0);
    return `<h2 class=pt>المخزون والمنتجات</h2>${tabs}<div class=g><div class="k hi"><small>قيمة المخزون بسعر التكلفة (${esc(baseCode())})</small><b>${fm(tot)}</b></div><div class=k><small>عدد الأصناف</small><b>${r.length}</b></div><div class=k><small>أصناف منخفضة / نافدة</small><b class=bd>${r.filter(x => x.low).length}</b></div></div><div class=cd><div class=tb style="justify-content:flex-end">${xlBtn('xlStock')}</div>${tbl(['المنتج', 'الباركود', 'الكمية', 'التكلفة', 'سعر البيع', 'القيمة'], r.map(x => [esc(x.n) + (x.low ? ' ' + chip('منخفض', 'bd') : ''), esc(x.bc), fq(x.q), fm(x.co), fm(x.pr), fm(x.value)]))}</div>`;
  }
  const q = FLT.prod.q.trim().toLowerCase();
  const list = s.prod.filter(p => !p.arch && (!q || [p.n, p.bc, p.model, p.brand, p.cat].some(x => String(x || '').toLowerCase().includes(q))));
  return `<h2 class=pt>المخزون والمنتجات</h2>${tabs}<div class=cd><div class=tb><label>بحث بالاسم أو الباركود أو الموديل أو الصنف<input data-c=prodq value="${esc(FLT.prod.q)}"></label>${newBtn('prodAdd', '+ منتج', 'prod')}${xlBtn('xlProd')}</div>${tbl(['المنتج', 'الصنف', 'الباركود', 'سعر البيع', 'التكلفة', 'الكمية', ''], lim(list, 300).map(p => [(p.img ? `<img class=pimg src="${esc(p.img)}" alt="">` : '') + esc(p.n) + (p.brand || p.model ? `<br><small class=mu>${esc(p.brand)} ${esc(p.model)}</small>` : ''), esc(p.cat), p.bc ? bsv(p.bc) : '<span class=mu>—</span>', fm(p.pr), fm(p.co), p.q <= p.mn ? `<b class=bd>${fq(p.q)} ⚠</b>` : fq(p.q), (p.bc ? btn('prodLabel', 'ملصق', { id: p.id }) : '') + (can('prod') ? btn('prodEdit', 'تعديل', { id: p.id }) + btn('entDel', 'حذف', { k: 'prod', id: p.id }, 'dl') : '')]))}${notice(300, list.length)}</div>`;
};
CHG.prodq = v => { FLT.prod.q = v; render(); };
CHG.mvp = v => { FLT.mv.p = v; render(); };
const prodFields = (isNew) => [{ k: 'n', l: 'اسم المنتج', req: 1, full: 1 }, { k: 'bc', l: 'الباركود (أرقام وحروف إنجليزية — تُدخله أنت، ولا يُولَّد تلقائيًا)', t: 'bc', full: 1 }, { k: 'cat', l: 'الصنف' }, { k: 'brand', l: 'الماركة' }, { k: 'model', l: 'الموديل' }, { k: 'pr', l: 'سعر البيع', t: 'money' }, { k: 'co', l: 'سعر التكلفة', t: 'money' }, ...(isNew || can('stock') ? [{ k: 'q', l: isNew ? 'الكمية الافتتاحية' : 'الكمية (تسوية)', t: 'qty' }] : []), { k: 'mn', l: 'حد تنبيه المخزون', t: 'qty' }, { k: 'img', l: 'صورة المنتج (اختياري)', t: 'file', full: 1 }];
ACT.prodAdd = () => form({ title: 'إضافة منتج', fields: prodFields(true), submit: async v => { if (v.img === undefined) delete v.img; AQ.en.addProduct(Object.assign({ user: AQ.me }, v)); toast('تمت إضافة المنتج', 'ok'); render(); } });
ACT.prodEdit = d => {
  const p = S().prod.find(x => x.id === d.id), dec = decOf(baseCode());
  form({ title: 'تعديل منتج', fields: prodFields(false), values: { n: p.n, bc: p.bc, cat: p.cat, brand: p.brand, model: p.model, pr: mInput(p.pr, dec), co: mInput(p.co, dec), q: Money.fmt(p.q, 3, { nogroup: true }).replace(/\.?0+$/, ''), mn: Money.fmt(p.mn, 3, { nogroup: true }).replace(/\.?0+$/, '') },
    submit: async v => { if (v.img === undefined) delete v.img; if (v.q === p.q || v.q === undefined) delete v.q; AQ.en.updateProduct(p.id, Object.assign({ user: AQ.me }, v)); toast('تم الحفظ', 'ok'); render(); } });
};
/* ---- الباركود Code 39 (أرقام وحروف كبيرة؛ الحروف الصغيرة تُطبع كبيرة) ---- */
const B39 = { '0': 'nnnwwnwnn', '1': 'wnnwnnnnw', '2': 'nnwwnnnnw', '3': 'wnwwnnnnn', '4': 'nnnwwnnnw', '5': 'wnnwwnnnn', '6': 'nnwwwnnnn', '7': 'nnnwnnwnw', '8': 'wnnwnnwnn', '9': 'nnwwnnwnn', 'A': 'wnnnnwnnw', 'B': 'nnwnnwnnw', 'C': 'wnwnnwnnn', 'D': 'nnnnwwnnw', 'E': 'wnnnwwnnn', 'F': 'nnwnwwnnn', 'G': 'nnnnnwwnw', 'H': 'wnnnnwwnn', 'I': 'nnwnnwwnn', 'J': 'nnnnwwwnn', 'K': 'wnnnnnnww', 'L': 'nnwnnnnww', 'M': 'wnwnnnnwn', 'N': 'nnnnwnnww', 'O': 'wnnnwnnwn', 'P': 'nnwnwnnwn', 'Q': 'nnnnnnwww', 'R': 'wnnnnnwwn', 'S': 'nnwnnnwwn', 'T': 'nnnnwnwwn', 'U': 'wwnnnnnnw', 'V': 'nwwnnnnnw', 'W': 'wwwnnnnnn', 'X': 'nwnnwnnnw', 'Y': 'wwnnwnnnn', 'Z': 'nwwnwnnnn', '-': 'nwnnnnwnw', '.': 'wwnnnnwnn', '$': 'nwnwnwnnn', '/': 'nwnwnnnwn', '+': 'nwnnnwnwn', '%': 'nnnwnwnwn', '*': 'nwnnwnwnn' };
function bsv(v0) {
  const v = String(v0).toUpperCase();
  if (![...v].every(ch => B39[ch] && ch !== '*')) return `<div style='font:12px monospace;direction:ltr'>${esc(v0)}</div>`;
  let x = 0, r = '';
  for (const ch of '*' + v + '*') { [...B39[ch]].forEach((c, i) => { const w = c === 'w' ? 3 : 1; if (i % 2 === 0) r += `<rect x=${x} width=${w} height=44 />`; x += w; }); x += 1; }
  return `<svg viewBox='0 0 ${x} 58' width=${Math.min(Math.round(x * 1.5), 200)} style='background:#fff;padding:3px;direction:ltr' fill='#000'>${r}<text x=${x / 2} y=56 font-size=10 text-anchor=middle>${esc(v)}</text></svg>`;
}
ACT.prodLabel = d => { const p = S().prod.find(x => x.id === d.id); printHTML(`<div style='display:grid;grid-template-columns:repeat(3,1fr);gap:8px;text-align:center'>${Array(12).fill(`<div style='border:1px dashed #999;padding:6px;font-size:12px'>${esc(p.n)}<br>${bsv(p.bc)}<br>${fm(p.pr)}</div>`).join('')}</div>`, 'a4'); };
