/* ui-pos.js — شاشة نقطة البيع */
'use strict';
const POS = { qm: null, req: null, c: '', r: '', cur: null, lines: [], ex: [], disc: '', dmode: 'amt', paid: '', paidAuto: true, method: 'cash', q: '', cat: '', busy: false };
const METHODS = [['cash', 'نقدي'], ['card', 'بطاقة'], ['transfer', 'تحويل بنكي']];
const METHOD_L = Object.fromEntries(METHODS);
const pad4 = n => String(n).padStart(4, '0');

function posReset() { POS.qm = null; POS.req = AQ.en.uid(); POS.c = ''; POS.r = ''; POS.lines = []; POS.ex = []; POS.disc = ''; POS.dmode = 'amt'; POS.paid = ''; POS.paidAuto = true; }
const posRate = () => (POS.cur === baseCode() ? 1000000 : cdef(POS.cur).rate);
function posPrice(p) { return POS.cur === baseCode() ? p.pr : Money.fromBase(p.pr, decOf(baseCode()), decOf(POS.cur), posRate()); }
function posCalc() {
  const dec = decOf(POS.cur), items = POS.lines.map(l => ({ q: l.q, pr: l.pr, co: 0 }));
  const sub = items.reduce((s, x) => s + Money.lineTotal(x.pr, x.q), 0);
  let disc = 0, bad = '';
  if (POS.disc.trim() !== '') {
    if (POS.dmode === 'pct') { const bp = Money.parse(POS.disc, 2); if (bp === null || bp < 0 || bp > 10000) bad = 'نسبة الخصم بين 0 و100'; else disc = Money.pct(sub, bp); }
    else { const a = Money.parse(POS.disc, dec); if (a === null || a < 0) bad = 'قيمة الخصم غير صحيحة'; else if (a > sub) bad = 'الخصم أكبر من المجموع'; else disc = a; }
  }
  const c = Engine.calcDoc({ items, disc, rate: S().set.taxBp }, 'pr');
  let paid = 0, perr = '';
  if (POS.paidAuto) paid = c.tot; else if (POS.paid.trim() === '') paid = 0; else { const v = Money.parse(POS.paid, dec); if (v === null || v < 0) perr = 'المبلغ المدفوع غير صحيح'; else paid = v; }
  const ex = [], exErr = exParse(POS.ex, dec, ex);
  return { c, disc, bad, paid, perr, dec, ex, exErr };
}
/* الرسوم الإضافية: تُحوَّل من نص إلى أعداد صحيحة بدقة العملة. تُرجع رسالة خطأ أو '' */
function exParse(rows, dec, out) {
  for (const r of rows || []) {
    const l = String(r.l || '').trim(), t = String(r.as == null ? '' : r.as).trim();
    if (!l && !t) continue;
    if (!l) return 'اكتب بيان الرسم الإضافي';
    const a = Money.parse(t, dec); if (a === null || a <= 0) return 'مبلغ الرسم الإضافي غير صحيح: ' + l;
    out.push({ l, a });
  }
  return '';
}
const EX_SUG = ['أجور توصيل', 'أجور تركيب', 'أجور نقل', 'أجور شحن'];
function exModal(o) { // محرر مشترك: o = { rows, dec, cur, onSave(rows) }
  const rowsHTML = rows => rows.map((r, k) => `<div class=exrow><input list=exsug data-i=exl data-k=${k} value="${esc(r.l)}" placeholder="البيان (مثال: أجور توصيل)" maxlength=60><input data-i=exa data-k=${k} value="${esc(r.as)}" placeholder="المبلغ" inputmode=decimal style="direction:ltr;text-align:center"><button class="s dl" data-a=exDel data-k=${k} title="حذف">🗑</button></div>`).join('');
  EXM.rows = o.rows.map(r => ({ l: r.l, as: r.as })); EXM.dec = o.dec; EXM.save = o.onSave; EXM.cur = o.cur;
  $('#md').innerHTML = `<div class=ov><div class=bx><h3>رسوم إضافية على الفاتورة <small class=mu>(اختياري)</small></h3>
  <p class=mu style="margin-top:0">تُكتب على الفاتورة المطبوعة فقط (مثل أجور التوصيل أو التركيب). <b>لا تدخل</b> في إجمالي الفاتورة ولا الأرباح ولا الضريبة ولا حساب العميل.</p>
  <datalist id=exsug>${EX_SUG.map(x => `<option value="${x}">`).join('')}</datalist>
  <div id=exrows>${rowsHTML(EXM.rows)}</div><button class=g2 data-a=exAdd id=exadd>+ إضافة سطر</button>
  <p id=er class=bd></p><div class=ac><button class=btn id=exok>حفظ</button><button class=g2 data-a=close>إلغاء</button></div></div></div>`;
  EXM.paint = () => { $('#exrows').innerHTML = rowsHTML(EXM.rows); $('#exadd').disabled = EXM.rows.length >= 5; };
  $('#exok').onclick = () => { const out = [], e = exParse(EXM.rows, EXM.dec, out); if (e) { $('#er').textContent = e; return; } EXM.save(EXM.rows.filter(r => String(r.l).trim() || String(r.as).trim())); closeModal(); };
  if (!EXM.rows.length) ACT.exAdd(); else EXM.paint();
}
const EXM = { rows: [], dec: 2, save: null, paint: null };
ACT.exAdd = () => { if (EXM.rows.length >= 5) return; EXM.rows.push({ l: '', as: '' }); EXM.paint(); const i = document.querySelectorAll('#exrows input[data-i=exl]'); if (i.length) i[i.length - 1].focus(); };
ACT.exDel = d => { EXM.rows.splice(+d.k, 1); EXM.paint(); };
INP.exl = (v, t) => { EXM.rows[+t.dataset.k].l = v; }; INP.exa = (v, t) => { EXM.rows[+t.dataset.k].as = v; };
ACT.posEx = () => exModal({ rows: POS.ex, dec: decOf(POS.cur), cur: POS.cur, onSave: rows => { POS.ex = rows; posSum(); } });
function posNextNo() { return 'INV-' + pad4(S().seq.inv); }

PAGES.pos = () => {
  const s = S(); if (!POS.cur || !s.set.cur.some(c => c.code === POS.cur && !c.unset)) POS.cur = s.set.base;
  if (!POS.req) POS.req = AQ.en.uid();
  const custs = s.cust.filter(c => !c.arch), reps = s.rep.filter(c => !c.arch);
  return `<div class=posw><div class=postop>
  <label>العميل<div class=row><select id=pc data-c=posc><option value="">عميل نقدي</option>${custs.map(c => `<option value="${esc(c.id)}"${POS.c === c.id ? ' selected' : ''}>${esc(c.n)}</option>`).join('')}</select>${can('party') ? '<button class=plus data-a=posNewCust title="عميل جديد">+</button>' : ''}</div></label>
  <label>رقم الفاتورة<input readonly id=pno value="${posNextNo()}" style="direction:ltr;text-align:center"></label>
  <label>المبلغ المدفوع<input id=ppaid data-i=pospaid inputmode=decimal style="direction:ltr;text-align:center"></label>
  <label>طريقة الدفع<select id=pmeth data-c=posmeth>${METHODS.map(m => `<option value=${m[0]}${POS.method === m[0] ? ' selected' : ''}>${m[1]}</option>`).join('')}</select></label>
  <label>العملة<select id=pcur data-c=poscur>${s.set.cur.filter(c => !c.unset).map(c => `<option value="${c.code}"${POS.cur === c.code ? ' selected' : ''}>${esc(c.code)} — ${esc(c.name)}</option>`).join('')}</select></label>
  <label>المندوب<select id=prep data-c=posrep><option value="">بدون</option>${reps.map(c => `<option value="${esc(c.id)}"${POS.r === c.id ? ' selected' : ''}>${esc(c.n)}</option>`).join('')}</select></label>
  </div><div class=posmain>
  <section class=cart><h3>🛒 سلة المشتريات</h3><div class=cl id=pcart></div><div id=psum></div></section>
  <section class=prods><div class=tools><select id=pcat data-c=poscat></select><input id=psearch data-i=possearch placeholder="ابحث بالاسم أو الباركود أو الموديل... (F2)" autocomplete=off><button class=g2 data-a=posRefresh title="تحديث">⟳</button></div><div class=tw id=ptab></div></section>
  </div></div>`;
};
HOOKS.pos = () => {
  posCats(); posTable(); posCart();
  const sb = $('#psearch'); sb.value = POS.q; sb.focus();
  sb.addEventListener('keydown', e => {
    if (e.key !== 'Enter') return; e.preventDefault();
    const v = sb.value.trim(); if (!v) return;
    const exact = S().prod.find(p => !p.arch && p.bc && p.bc.toLowerCase() === String(v).toLowerCase());
    if (exact) { posAdd(exact.id); sb.value = ''; POS.q = ''; posTable(); return; }
    const list = posFiltered(); if (list.length === 1) { posAdd(list[0].id); sb.value = ''; POS.q = ''; posTable(); } else if (!list.length) toast('لا يوجد منتج مطابق: ' + v, 'err');
  });
};
function posCats() {
  const cats = [...new Set(S().prod.filter(p => !p.arch && p.cat).map(p => p.cat))].sort();
  $('#pcat').innerHTML = '<option value="">جميع الأصناف</option>' + cats.map(c => `<option${POS.cat === c ? ' selected' : ''}>${esc(c)}</option>`).join('');
}
function posFiltered() {
  const q = POS.q.trim().toLowerCase();
  return S().prod.filter(p => !p.arch && (!POS.cat || p.cat === POS.cat) && (!q || [p.n, p.bc, p.model, p.cat, p.brand].some(x => String(x || '').toLowerCase().includes(q))));
}
function posTable() {
  const list = posFiltered().slice(0, 300);
  const st = p => (p.q <= 0 ? chip('نافد', 'bd') : p.q <= p.mn ? chip('منخفض') : chip('متوفر', 'ok'));
  $('#ptab').innerHTML = `<table><thead><tr><th>#</th><th>الحالة</th><th>الكمية</th><th>السعر</th><th>الباركود</th><th>الموديل</th><th>الماركة</th><th>الصنف</th><th>الاسم</th></tr></thead><tbody>${list.length ? list.map((p, i) => `<tr data-a=posAddRow data-id="${esc(p.id)}"><td>${i + 1}</td><td>${st(p)}</td><td class=num>${fq(p.q)}</td><td class=num>${fm(posPrice(p), POS.cur)}</td><td class=num>${esc(p.bc)}</td><td>${esc(p.model)}</td><td>${esc(p.brand)}</td><td>${esc(p.cat)}</td><td>${p.img ? `<img class=pimg src="${esc(p.img)}" alt="">` : '<span class="pimg ph">▣</span>'}${esc(p.n)}</td></tr>`).join('') : '<tr><td colspan=9 class=mu style="text-align:center;padding:24px">لا توجد منتجات مطابقة</td></tr>'}</tbody></table>`;
}
INP.possearch = v => { POS.q = v; posTable(); };
CHG.poscat = v => { POS.cat = v; posTable(); };
ACT.posRefresh = () => { POS.q = ''; POS.cat = ''; $('#psearch').value = ''; posCats(); posTable(); $('#psearch').focus(); };
ACT.posAddRow = d => { posAdd(d.id); $('#psearch').focus(); };

function posAdd(pid, q) {
  const p = S().prod.find(x => x.id === pid); if (!p) return;
  q = q || 1000;
  const inCart = POS.lines.filter(l => l.p === pid).reduce((s, l) => s + l.q, 0);
  if (inCart + q > p.q && !S().set.negStock && !(can('negstock'))) { toast('الكمية غير كافية في المخزون: ' + p.n + ' (المتاح ' + Money.fmtQty(p.q) + ')', 'err'); return; }
  const pr = posPrice(p), ex = POS.lines.find(l => l.p === pid && l.pr === pr);
  if (ex) ex.q += q; else POS.lines.push({ p: pid, q, pr });
  posCart();
}
function posCart() {
  const s = S(), dec = decOf(POS.cur);
  const rows = POS.lines.map((l, k) => { const p = s.prod.find(x => x.id === l.p); return `<tr><td>${k + 1}</td><td>${p && p.img ? `<img class=pimg style="width:30px;height:30px" src="${esc(p.img)}" alt="">` : ''}${esc(p ? p.n : '?')}</td>
  <td><div class=qty><button data-a=posQ data-k=${k} data-d=1>+</button><input data-i=posqty data-k=${k} value="${Money.fmtQty(l.q).replace(/,/g, '')}" inputmode=decimal><button data-a=posQ data-k=${k} data-d=-1>−</button></div></td>
  <td>${can('price') ? `<input class=pi data-i=posprice data-k=${k} value="${Money.fmt(l.pr, dec, { nogroup: true })}" inputmode=decimal>` : `<span class=num>${fm(l.pr, POS.cur)}</span>`}</td>
  <td class=num id=lt_${k}>${fm(Money.lineTotal(l.pr, l.q), POS.cur)}</td><td><button class="s dl" data-a=posDel data-k=${k} title="حذف">🗑</button></td></tr>`; }).join('');
  $('#pcart').innerHTML = POS.lines.length ? `<table><thead><tr><th>#</th><th>المنتج</th><th>الكمية</th><th>السعر</th><th>المجموع</th><th></th></tr></thead><tbody>${rows}</tbody></table>` : `<div class=empty>🛒<br><b>أضف منتجات إلى السلة</b><br><small>يمكنك البحث أو مسح الباركود لإضافة المنتجات بسرعة</small></div>`;
  posSum();
}
function posSum() {
  const k = posCalc(), c = k.c, cur = POS.cur;
  POS.lines.forEach((l, i) => { const e = $('#lt_' + i); if (e) e.innerHTML = fm(Money.lineTotal(l.pr, l.q), cur); });
  const rem = c.tot - k.paid;
  const pf = $('#ppaid'); if (pf && (POS.paidAuto || document.activeElement !== pf)) pf.value = POS.paidAuto ? Money.fmt(c.tot, k.dec, { nogroup: true }) : POS.paid;
  $('#psum').innerHTML = `<div class=sum>
  <div class=r><span>📄 إجمالي المبلغ</span><b>${fm(c.sub, cur)}</b></div>
  <div class=r><span>٪ الخصم</span><span style="display:flex;gap:6px;align-items:center"><span class=seg><button data-a=posDM data-m=amt class="${POS.dmode === 'amt' ? 'on' : ''}">قيمة</button><button data-a=posDM data-m=pct class="${POS.dmode === 'pct' ? 'on' : ''}">%</button></span><input id=pdisc data-i=posdisc value="${esc(POS.disc)}" placeholder="0" ${can('disc') ? '' : 'disabled'} ${k.bad ? 'style="border-color:var(--bd)"' : ''}></span></div>
  ${k.bad ? `<div class="r bd">${k.bad}</div>` : ''}
  <div class=r><span>🧾 الضريبة (${Money.fmtPct(S().set.taxBp)}%)</span><b>${fm(c.tax, cur)}</b></div>
  <div class=tot><span>المجموع الكلي</span><span>${fm(c.tot, cur)}</span></div>
  <div class=r><button class=g2 data-a=posEx style="padding:3px 10px">➕ رسوم إضافية (اختياري)</button><span class=mu style="font-size:12px">${k.ex.length ? 'للطباعة فقط: ' + k.ex.map(e => esc(e.l) + ' ' + fm(e.a, cur)).join('، ') : ''}</span></div>
  ${k.exErr ? `<div class="r bd">${esc(k.exErr)}</div>` : ''}</div>
  <div class=payb><div>المقبوض<b class=ok>${fm(Math.min(k.paid, c.tot), cur)}</b></div><div>المتبقي<b class="${rem > 0 ? 'bd' : ''}">${fm(Math.max(rem, 0), cur)}</b></div><div>الباقي للعميل<b>${fm(Math.max(-rem, 0), cur)}</b></div></div>
  ${k.perr ? `<p class=bd style="margin:4px 12px">${k.perr}</p>` : ''}
  ${POS.qm ? `<div class=qmb>${POS.qm.kind === 'edit' ? '✏️ تعديل عرض السعر' : '🔄 تحويل عرض السعر إلى فاتورة'} <b>${esc(POS.qm.no)}</b> <button class=g2 data-a=posQuoteExit style="padding:2px 10px">إنهاء</button></div>` : ''}
  <button class=done data-a=posDone id=pdone ${POS.lines.length && !POS.busy ? '' : 'disabled'}>${POS.qm && POS.qm.kind === 'edit' ? '💾 حفظ تعديلات العرض (F8)' : 'إتمام البيع (F8)'}</button>
  ${POS.qm ? '' : '<button class=g2 data-a=posQuote style="width:calc(100% - 24px);margin:6px 12px 0" ' + (POS.lines.length ? '' : 'disabled') + '>📝 حفظ كعرض سعر</button>'}`;
}
INP.posqty = (v, el) => { const q = Money.parse(v, 3); if (q && q > 0) { POS.lines[+el.dataset.k].q = q; posSum(); } };
INP.posprice = (v, el) => { const p = Money.parse(v, decOf(POS.cur)); if (p !== null && p >= 0) { POS.lines[+el.dataset.k].pr = p; posSum(); } };
INP.posdisc = v => { POS.disc = v; posSum(); };
INP.pospaid = v => { POS.paidAuto = false; POS.paid = v; posSum(); };
ACT.posDM = d => { POS.dmode = d.m; POS.disc = ''; posSum(); };
ACT.posQ = d => { const l = POS.lines[+d.k], nq = l.q + (+d.d) * 1000; if (nq <= 0) { POS.lines.splice(+d.k, 1); posCart(); return; } const p = S().prod.find(x => x.id === l.p); if (+d.d > 0) { const inCart = POS.lines.filter(z => z.p === l.p).reduce((s, z) => s + z.q, 0); if (inCart + 1000 > p.q && !S().set.negStock && !can('negstock')) { toast('الكمية غير كافية في المخزون', 'err'); return; } } l.q = nq; posCart(); };
ACT.posDel = d => { POS.lines.splice(+d.k, 1); posCart(); };
CHG.posc = v => { POS.c = v; };
CHG.posrep = v => { POS.r = v; };
CHG.posmeth = v => { POS.method = v; };
CHG.poscur = v => {
  POS.cur = v; POS.disc = ''; POS.paidAuto = true; POS.paid = '';
  POS.lines.forEach(l => { const p = S().prod.find(x => x.id === l.p); l.pr = posPrice(p); });
  posTable(); posCart();
};
ACT.posNewCust = () => form({
  title: 'عميل جديد', fields: [{ k: 'n', l: 'الاسم', req: 1, full: 1 }, { k: 'ph', l: 'الهاتف' }, { k: 'ad', l: 'العنوان' }],
  submit: async v => { const id = AQ.en.addParty('cust', Object.assign({ user: AQ.me }, v)); POS.c = id; render(); }
});
ACT.posDone = () => {
  if (POS.busy || !POS.lines.length) return;
  if (POS.qm && POS.qm.kind === 'edit') return ACT.posQuoteSave();
  const k = posCalc(); if (k.bad || k.perr || k.exErr) { toast(k.bad || k.perr || k.exErr, 'err'); return; }
  POS.busy = true; const btn = $('#pdone'); if (btn) btn.disabled = true;
  try {
    const items = POS.lines.map(l => ({ p: l.p, q: l.q, pr: l.pr }));
    const sale = { req: POS.req, date: today(), c: POS.c, r: POS.r, cur: POS.cur, fx: posRate(), items, ex: k.ex, disc: k.disc, pay: { amt: Math.min(k.paid, k.c.tot), method: POS.method }, user: AQ.me };
    const r = POS.qm && POS.qm.kind === 'convert' ? AQ.en.convertQuote(POS.qm.id, sale) : AQ.en.createSale(sale);
    const change = Math.max(0, k.paid - k.c.tot);
    posReset();
    saleDone(r, change);
  } catch (e) { fail(e); }
  POS.busy = false; render();
};
function saleDone(r, change) {
  const v = S().inv.find(x => x.id === r.id), cur = v.cur, due = r.tot - r.paid;
  $('#md').innerHTML = `<div class=ov><div class="bx okbox" role=alertdialog aria-live=polite>
  <div class=okic>✓</div><h3 class=okt>تم بيع الفاتورة بنجاح</h3>
  <div class=oks>رقم الفاتورة: <b>${esc(r.no)}</b> — العميل: <b>${esc(v.cn)}</b></div>
  <table class=okn><tr><td>الإجمالي</td><td><b>${fm(r.tot, cur)}</b></td></tr><tr><td>المدفوع</td><td><b>${fm(r.paid, cur)}</b></td></tr>${due > 0 ? `<tr class=bd><td>المتبقي (آجل)</td><td><b>${fm(due, cur)}</b></td></tr>` : ''}${change ? `<tr><td>الباقي للعميل</td><td><b>${fm(change, cur)}</b></td></tr>` : ''}</table>
  <div class=ac><button class=btn data-a=print data-id="${r.id}">🖨 طباعة الفاتورة (A5)</button><button class=g2 data-a=close id=newsale>فاتورة جديدة</button></div></div></div>`;
  $('#newsale').focus();
}
KEYS.push(e => {
  if (AQ.tab !== 'pos' || $('#md').innerHTML) return false;
  if (e.key === 'F8') { e.preventDefault(); ACT.posDone(); return true; }
  if (e.key === 'F2') { e.preventDefault(); const s = $('#psearch'); if (s) s.focus(); return true; }
  return false;
});
