﻿$ErrorActionPreference = 'Continue'
Add-Type -AssemblyName System.Windows.Forms
$title = 'العقرب الحسابي'
function Msg($t, $b = 'OK', $i = 'Information') {
  [System.Windows.Forms.MessageBox]::Show($t, $title, $b, $i, 'Button2', 'RtlReading,RightAlign')
}
Set-Location $env:TEMP
if (Get-Process -Name AqrabAccounting -ErrorAction SilentlyContinue) {
  Msg 'البرنامج مفتوح حاليًا. أغلقه أولًا ثم أعد المحاولة.' 'OK' 'Warning' | Out-Null
  exit 1
}
$r = Msg 'هل تريد إزالة برنامج العقرب الحسابي من هذا الجهاز؟' 'YesNo' 'Question'
if ($r -ne 'Yes') { exit 0 }
$data = Join-Path $env:APPDATA 'AqrabAccounting'
$delData = $false
if (Test-Path $data) {
  $r2 = Msg ("هل تريد أيضًا حذف بيانات البرنامج (الفواتير والعملاء...) من هذا الجهاز؟`n`nالنسخ الاحتياطية المحفوظة في مجلد المستندات لن تُحذف أبدًا، ويمكنك استعادة بياناتك منها عند إعادة التثبيت.`n`nالاختيار الآمن: لا") 'YesNo' 'Warning'
  $delData = ($r2 -eq 'Yes')
}
foreach ($d in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  Remove-Item (Join-Path $d ($title + '.lnk')) -Force -ErrorAction SilentlyContinue
}
Remove-Item 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AqrabAccounting' -Recurse -Force -ErrorAction SilentlyContinue
if ($delData) { Remove-Item $data -Recurse -Force -ErrorAction SilentlyContinue }
$dst = $PSScriptRoot
Start-Process powershell.exe -WindowStyle Hidden -ArgumentList '-NoProfile','-Command',("Start-Sleep 2; Remove-Item -LiteralPath '" + $dst + "' -Recurse -Force -ErrorAction SilentlyContinue")
Msg 'تمت إزالة البرنامج. النسخ الاحتياطية في مجلد المستندات باقية.' 'OK' 'Information' | Out-Null
