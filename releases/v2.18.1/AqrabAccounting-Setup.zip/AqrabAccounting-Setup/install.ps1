﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$title = 'العقرب الحسابي'
function Msg($t, $b = 'OK', $i = 'Information') {
  [System.Windows.Forms.MessageBox]::Show($t, $title, $b, $i, 'Button1', 'RtlReading,RightAlign')
}
try {
  $files = Join-Path $PSScriptRoot 'src'
  if (-not (Test-Path (Join-Path $files 'main.js'))) {
    Msg 'لم يتم العثور على ملفات البرنامج. فك ضغط المجلد بالكامل أولًا ثم شغّل التثبيت.' 'OK' 'Error' | Out-Null
    exit 1
  }
  $run = @(Get-Process -Name AqrabAccounting -ErrorAction SilentlyContinue)
  if ($run.Count -gt 0) {
    # قد تبقى عملية خفية بعد إغلاق النافذة أو بعد خطأ عند التشغيل. نحاول الإغلاق العادي أولًا ثم الإجباري.
    $ans = Msg 'البرنامج ما زال يعمل (قد تكون عملية خفية بعد إغلاق النافذة). هل تريد إغلاقه الآن للمتابعة؟ بياناتك محفوظة ولا تتأثر.' 'YesNo' 'Question'
    if ($ans -ne 'Yes') { exit 1 }
    $run | ForEach-Object { try { [void]$_.CloseMainWindow() } catch {} }
    Start-Sleep -Seconds 4
    Get-Process -Name AqrabAccounting -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    if (Get-Process -Name AqrabAccounting -ErrorAction SilentlyContinue) {
      Msg 'تعذّر إغلاق البرنامج. افتح مدير المهام (Ctrl+Shift+Esc)، ابحث عن AqrabAccounting، اختر «إنهاء المهمة» ثم أعد التثبيت.' 'OK' 'Warning' | Out-Null
      exit 1
    }
  }
  # ---- تنزيل Electron الرسمي والتحقق من بصمته ثم تجميع البرنامج ----
  $ver = '33.4.11'
  $sha = 'f64c8a5a81d9b420b636fdba13e180f49d69f2198e1d86a8b01f858b17a9483c'
  $work = Join-Path $env:TEMP 'aqrab-setup'
  if (Test-Path $work) { Remove-Item $work -Recurse -Force }
  New-Item -ItemType Directory -Path $work -Force | Out-Null
  $zip = Join-Path $work 'electron.zip'
  $cache = Join-Path $PSScriptRoot 'electron-win32-x64.zip'
  if (Test-Path $cache) { Copy-Item $cache $zip } else {
    Write-Host 'Downloading Electron runtime (about 110 MB), please wait...'
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $url = 'https://github.com/electron/electron/releases/download/v' + $ver + '/electron-v' + $ver + '-win32-x64.zip'
    $ok = $false
    $curl = Join-Path $env:SystemRoot 'System32\curl.exe'
    if (Test-Path $curl) { # curl مدمج في ويندوز 10/11: يستأنف التنزيل ويعيد المحاولة عند ضعف الإنترنت
      for ($i = 1; $i -le 4 -and -not $ok; $i++) {
        & $curl -L --fail --connect-timeout 30 --retry 5 --retry-delay 3 -C - -o $zip $url
        if ($LASTEXITCODE -eq 0 -and (Test-Path $zip) -and ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -eq $sha)) { $ok = $true }
      }
    }
    if (-not $ok) {
      $ProgressPreference = 'SilentlyContinue'
      Remove-Item $zip -Force -ErrorAction SilentlyContinue
      try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 1800 -Uri $url -OutFile $zip } catch {
        throw ('تعذّر تنزيل مكوّن التشغيل بسبب الاتصال بالإنترنت. الحل: نزّل الملف electron-win32-x64.zip (المرسل لك) وضعه بجانب Install.bat ثم أعد التثبيت. التفاصيل: ' + $_.Exception.Message)
      }
    }
  }
  if ((Get-FileHash $zip -Algorithm SHA256).Hash.ToLower() -ne $sha) { throw 'ملف التشغيل الذي تم تنزيله غير مطابق للبصمة المتوقعة. أعد المحاولة.' }
  Write-Host 'Preparing application...'
  $stage = Join-Path $work 'app'
  Expand-Archive -Path $zip -DestinationPath $stage -Force
  Rename-Item (Join-Path $stage 'electron.exe') 'AqrabAccounting.exe'
  Remove-Item (Join-Path $stage 'resources\default_app.asar') -Force -ErrorAction SilentlyContinue
  Get-ChildItem (Join-Path $stage 'locales') | Where-Object { $_.Name -notin @('ar.pak', 'en-US.pak') } | Remove-Item -Force
  $ra = Join-Path $stage 'resources\app'
  New-Item -ItemType Directory -Path $ra -Force | Out-Null
  foreach ($f in @('package.json', 'main.js', 'preload.js', 'storage.js', 'index.html', 'icon.png')) {
    $fp = Join-Path $files $f
    if (-not (Test-Path $fp)) { throw ('ملف ناقص في الحزمة: ' + $f) }
    Copy-Item $fp $ra -Force
  }
  # أي ملف .js آخر في الجذر يُنسخ أيضًا حتى لا يتكرر نسيان ملف
  Get-ChildItem $files -Filter *.js -File | ForEach-Object { Copy-Item $_.FullName $ra -Force }
  foreach ($d in @('css', 'js')) { Copy-Item (Join-Path $files $d) $ra -Recurse -Force }
  Copy-Item (Join-Path $files 'icon.ico') $stage -Force
  $src = $stage
  $dst = Join-Path $env:LOCALAPPDATA 'Programs\AqrabAccounting'
  if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
  New-Item -ItemType Directory -Path $dst -Force | Out-Null
  Copy-Item (Join-Path $src '*') $dst -Recurse -Force
  Copy-Item (Join-Path $PSScriptRoot 'uninstall.ps1') $dst -Force
  $exe = Join-Path $dst 'AqrabAccounting.exe'
  $ico = Join-Path $dst 'icon.ico'
  $sh = New-Object -ComObject WScript.Shell
  $dirs = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))
  foreach ($d in $dirs) {
    $l = $sh.CreateShortcut((Join-Path $d ($title + '.lnk')))
    $l.TargetPath = $exe
    $l.WorkingDirectory = $dst
    $l.IconLocation = $ico
    $l.Description = $title
    $l.Save()
  }
  $k = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\AqrabAccounting'
  New-Item -Path $k -Force | Out-Null
  Set-ItemProperty $k DisplayName $title
  Set-ItemProperty $k DisplayVersion '1.0.0'
  Set-ItemProperty $k Publisher $title
  Set-ItemProperty $k DisplayIcon $ico
  Set-ItemProperty $k InstallLocation $dst
  Set-ItemProperty $k UninstallString ('powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $dst 'uninstall.ps1') + '"')
  Set-ItemProperty $k NoModify 1 -Type DWord
  Set-ItemProperty $k NoRepair 1 -Type DWord
  Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
  $r = Msg ("تم تثبيت البرنامج بنجاح.`nتم إنشاء اختصار على سطح المكتب وفي قائمة ابدأ.`n`nهل تريد تشغيله الآن؟") 'YesNo' 'Information'
  if ($r -eq 'Yes') { Start-Process $exe }
} catch {
  Msg ('فشل التثبيت: ' + $_.Exception.Message) 'OK' 'Error' | Out-Null
  exit 1
}
