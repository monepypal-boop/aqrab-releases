@echo off
title Aqrab Accounting - Setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
