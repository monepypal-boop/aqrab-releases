'use strict';
/* updater.js — التحقق من التحديثات (بدون Electron ليسهل اختباره).
 * ملف الوصف update.json موقّع بالمفتاح الخاص للبائع: {payload: base64url(JSON), sig}. البرنامج يرفض أي ملف غير موقّع أو معدّل،
 * ويتحقق من بصمة SHA-256 للحزمة بعد تنزيلها قبل أن يعرضها للتثبيت. لا يُثبَّت شيء تلقائيًا بدون موافقة المستخدم. */
const crypto = require('crypto');
const L = require('./license');
const unb64u = s => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');

function cmpVer(a, b) {
  const pa = String(a).split('.').map(n => parseInt(n, 10)), pb = String(b).split('.').map(n => parseInt(n, 10));
  for (let i = 0; i < 3; i++) { const x = pa[i] || 0, y = pb[i] || 0; if (x !== y) return x > y ? 1 : -1; }
  return 0;
}
const okVer = v => /^\d{1,4}\.\d{1,4}\.\d{1,4}$/.test(String(v));
const okUrl = u => { try { const x = new URL(u); return x.protocol === 'https:' && !x.username && !x.password; } catch (e) { return false; } };

/* يتحقق من نص update.json ويُرجع { ok, info } أو { ok:false, error } */
function parseManifest(text, pub) {
  let m; try { m = JSON.parse(text); } catch (e) { return { ok: false, error: 'ملف التحديث ليس JSON صالحًا' }; }
  if (!m || typeof m.payload !== 'string' || typeof m.sig !== 'string') return { ok: false, error: 'ملف التحديث غير موقّع' };
  try { if (!crypto.verify(null, Buffer.from(m.payload), pub || L.PUBLIC_KEY, unb64u(m.sig))) return { ok: false, error: 'توقيع ملف التحديث غير صحيح — لن يُستعمل' }; } catch (e) { return { ok: false, error: 'تعذّر التحقق من توقيع ملف التحديث' }; }
  let p; try { p = JSON.parse(unb64u(m.payload).toString('utf8')); } catch (e) { return { ok: false, error: 'محتوى التحديث تالف' }; }
  if (!okVer(p.version) || !okUrl(p.url) || !/^[0-9a-f]{64}$/.test(String(p.sha256 || '')) || !Number.isInteger(p.size) || p.size <= 0) return { ok: false, error: 'بيانات التحديث ناقصة أو غير صحيحة' };
  return { ok: true, info: { version: p.version, url: p.url, sha256: p.sha256, size: p.size, notes: String(p.notes || '').slice(0, 2000), date: String(p.date || '') } };
}
function sign(info, privatePem) {
  const payload = L.b64u(JSON.stringify(info));
  return { payload, sig: L.b64u(crypto.sign(null, Buffer.from(payload), privatePem)) };
}
/* يقرر: { state:'uptodate'|'available'|'error', info?, error? } */
function decide(currentVersion, text, pub) {
  const r = parseManifest(text, pub); if (!r.ok) return { state: 'error', error: r.error };
  return cmpVer(r.info.version, currentVersion) > 0 ? { state: 'available', info: r.info } : { state: 'uptodate', info: r.info };
}
const sha256 = buf => crypto.createHash('sha256').update(buf).digest('hex');
module.exports = { cmpVer, okVer, okUrl, parseManifest, sign, decide, sha256 };
