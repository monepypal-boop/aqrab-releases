'use strict';
/* العقرب الحسابي — نسخة سطح المكتب (Electron)
 * - البيانات تُحفظ في ملف على الجهاز (مجلد بيانات التطبيق) وليس في المتصفح.
 * - النسخ الاحتياطية تُحفظ في مجلد "المستندات" ليبقى بعد حذف/إعادة تثبيت البرنامج.
 */
const { app, BrowserWindow, ipcMain, dialog, shell, Menu, session, safeStorage, net } = require('electron');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

app.setName('AqrabAccounting');
if (process.platform === 'win32') app.setAppUserModelId('com.aqrab.accounting');
app.setPath('userData', path.join(app.getPath('appData'), 'AqrabAccounting'));

const APP_TITLE = 'العقرب الحسابي';
const VERSION = require('./package.json').version;
const USER = app.getPath('userData');
const DATA_FILE = path.join(USER, 'data.json');
const SETTINGS_FILE = path.join(USER, 'settings.json');
const DEFAULT_BACKUP_DIR = path.join(app.getPath('documents'), 'العقرب الحسابي', 'النسخ الاحتياطية');
const KEEP_AUTO = 30;
const KEEP_SAFETY = 15;
const KIND_RE = /^[a-z-]{3,14}$/;

/* ---------------- ملفات صغيرة آمنة (انظر storage.js) ---------------- */
const ST = require('./storage');
const { writeAtomic, readJson } = ST;

/* ---------------- مخزن البيانات ---------------- */
const LOADED = ST.loadStore(DATA_FILE);
let store = LOADED.store;
let startupNotice = null; // رسالة تُعرض للمستخدم عند فتح النافذة إذا حدث استرداد
let writeTimer = null;
let saveErr = '', retryTimer = null;
function notifySave(ok, msg) {
  try { if (win && !win.isDestroyed()) win.webContents.send(ok ? 'store:ok' : 'store:error', msg || ''); } catch (e) {}
}
function flushStore() {
  if (writeTimer) { clearTimeout(writeTimer); writeTimer = null; }
  try {
    writeAtomic(DATA_FILE, JSON.stringify(store));
    if (saveErr) { saveErr = ''; notifySave(true); }
    if (retryTimer) { clearTimeout(retryTimer); retryTimer = null; }
    return true;
  } catch (e) {
    console.error('save failed', e);
    saveErr = e.message || String(e);
    notifySave(false, saveErr);
    if (!retryTimer) retryTimer = setTimeout(() => { retryTimer = null; flushStore(); }, 5000); // أعد المحاولة كل 5 ثوانٍ
    return false;
  }
}
function scheduleWrite() {
  if (writeTimer) clearTimeout(writeTimer);
  writeTimer = setTimeout(flushStore, 250);
}
const DB = 'aqrab_db', V2 = 'aqrab_v2', PW = 'aqrab_pw'; // DB/PW: بيانات النسخة القديمة (تبقى كما هي)، V2: بيانات النظام الجديد
const hasData = () => !!(store.items[V2] || store.items[DB]);
const dataHash = () => crypto.createHash('sha256').update((store.items[V2] || '') + '|' + (store.items[DB] || '') + '|' + (store.items[PW] || '')).digest('hex');

/* ---------------- الإعدادات ---------------- */
let settings = Object.assign({ backupDir: '', mirrorDir: '', onClose: 'ask', lastBackupHash: '', lastBackupAt: '', lastDaily: '', lastMirror: null }, readJson(SETTINGS_FILE) || {});
const saveSettings = () => { try { writeAtomic(SETTINGS_FILE, JSON.stringify(settings)); } catch (e) {} };
const backupDir = () => settings.backupDir || DEFAULT_BACKUP_DIR;

/* ---------------- النسخ الاحتياطي ---------------- */
const stamp = ST.stamp;
function parseDb(raw) { try { return JSON.parse(raw); } catch (e) { return null; } }
function statsOf(db) {
  const n = k => (db && Array.isArray(db[k]) ? db[k].length : 0);
  return { inv: n('inv'), cust: n('cust'), prod: n('prod'), exp: n('exp') };
}
function makeSnapshot(kind) {
  const db = parseDb(store.items[DB]), v2 = parseDb(store.items[V2]);
  return {
    app: 'aqrab-accounting', format: 2, version: VERSION, kind,
    created: new Date().toISOString(), stats: statsOf(v2 || db),
    db, v2, pw: store.items[PW] || null
  };
}
function createBackup(kind, targetFile) {
  if (!hasData()) return { ok: false, empty: true, error: 'لا توجد بيانات لحفظها بعد.' };
  kind = KIND_RE.test(kind || '') ? kind : 'manual';
  try {
    if (!flushStore()) return { ok: false, error: 'تعذّر حفظ البيانات الحالية على القرص قبل النسخ: ' + saveErr };
    const snap = makeSnapshot(kind);
    const text = JSON.stringify(snap, null, 1);
    const file = targetFile || path.join(backupDir(), `aqrab-backup_${kind}_${stamp()}.json`);
    const w = ST.writeVerified(file, text); // كتابة ثم قراءة ومطابقة
    if (!w.ok) return { ok: false, error: 'تعذّر حفظ النسخة: ' + w.error };
    settings.lastBackupHash = dataHash();
    settings.lastBackupAt = snap.created;
    let mirror = null;
    if (!targetFile && settings.mirrorDir) { // نسخة إضافية في مكان ثانٍ (فلاش / OneDrive …)
      const mf = path.join(settings.mirrorDir, path.basename(file)), m = ST.writeVerified(mf, text);
      mirror = m.ok ? { ok: true, file: mf } : { ok: false, error: m.error };
      settings.lastMirror = { ok: m.ok, at: snap.created, error: m.ok ? '' : m.error };
    }
    saveSettings();
    if (!targetFile) { prune(backupDir()); if (settings.mirrorDir) prune(settings.mirrorDir); }
    return { ok: true, file, name: path.basename(file), created: snap.created, mirror, verified: true };
  } catch (e) {
    return { ok: false, error: 'تعذّر حفظ النسخة: ' + e.message };
  }
}
function listBackups(dir) {
  dir = dir || backupDir();
  let names = [];
  try { names = fs.readdirSync(dir).filter(n => /^aqrab-backup_.*\.json$/.test(n)); } catch (e) { return []; }
  const out = [];
  for (const name of names) {
    try {
      const full = path.join(dir, name);
      const st = fs.statSync(full);
      const s = JSON.parse(fs.readFileSync(full, 'utf8'));
      if (!s || !(s.db || s.v2)) continue;
      out.push({ name, kind: s.kind || 'manual', created: s.created || st.mtime.toISOString(), size: st.size, stats: s.stats || statsOf(s.v2 || s.db) });
    } catch (e) { /* ملف تالف: يُتجاهل */ }
  }
  return out.sort((a, b) => (a.created < b.created ? 1 : -1));
}
function prune(dir) {
  const all = listBackups(dir);
  ST.pickPrune(all).forEach(n => { try { fs.unlinkSync(path.join(dir, n)); } catch (e) {} });
}
/* يقبل: ملف نسخة العقرب، أو نص قاعدة البيانات القديم (النسخة الاحتياطية النصية) */
function parseSnapshotText(text) {
  let o;
  try { o = JSON.parse(String(text).replace(/^﻿/, '').trim()); } catch (e) { return { ok: false, error: 'الملف أو النص غير صالح (ليس JSON).' }; }
  const isV1 = x => x && x.co && Array.isArray(x.inv) && !x.ver;
  const isV2 = x => x && x.ver === 2 && x.set && Array.isArray(x.inv) && Array.isArray(x.cash);
  if (o && o.app === 'aqrab-accounting' && (isV1(o.db) || isV2(o.v2))) {
    const v2 = isV2(o.v2) ? o.v2 : null, db = isV1(o.db) ? o.db : null;
    return { ok: true, db, v2, pw: o.pw || null, created: o.created, stats: o.stats || statsOf(v2 || db) };
  }
  if (isV2(o)) return { ok: true, db: null, v2: o, pw: null, created: null, stats: statsOf(o), keepLegacy: true };
  if (isV1(o)) return { ok: true, db: o, v2: null, pw: null, created: null, stats: statsOf(o), keepLegacy: true };
  return { ok: false, error: 'هذا ليس ملف نسخة احتياطية للعقرب الحسابي.' };
}
function applySnapshot(p) {
  let safety = null;
  if (hasData()) {
    safety = createBackup('pre-restore');
    if (!safety.ok) return { ok: false, error: 'لم تتم الاستعادة لأن النسخة الأمنية للبيانات الحالية فشلت: ' + safety.error };
  }
  if (p.v2) store.items[V2] = JSON.stringify(p.v2); else delete store.items[V2]; // نسخة قديمة فقط: يُعاد ترحيلها عند التشغيل
  if (p.db) store.items[DB] = JSON.stringify(p.db); else if (!p.keepLegacy) delete store.items[DB];
  if (p.pw) store.items[PW] = p.pw;
  flushStore();
  settings.lastBackupHash = dataHash(); // البيانات المستعادة مطابقة لنسخة موجودة
  saveSettings();
  return { ok: true, safety: safety && safety.name };
}
const safeName = n => path.basename(String(n || ''));
let pickedFile = null;

/* ---------------- IPC ---------------- */
ipcMain.on('store:get', (e, k) => { e.returnValue = Object.prototype.hasOwnProperty.call(store.items, k) ? store.items[k] : null; });
ipcMain.on('store:set', (e, k, v) => {
  if (k === DB || k === PW || k === V2) { store.items[k] = String(v); scheduleWrite(); }
  e.returnValue = true;
});
ipcMain.on('store:remove', (e, k) => { delete store.items[k]; scheduleWrite(); e.returnValue = true; });

ipcMain.handle('backup:create', (e, kind) => createBackup(['pre-delete', 'pre-migrate', 'pre-import'].includes(kind) ? kind : 'manual'));
ipcMain.handle('backup:snap', () => { // نسخة أمان قبل الحذف، بحد أقصى مرة كل 10 دقائق
  if (!hasData() || dataHash() === settings.lastBackupHash) return { ok: true, skipped: true };
  const last = settings.lastBackupAt ? Date.parse(settings.lastBackupAt) : 0;
  if (Date.now() - last < 10 * 60 * 1000) return { ok: true, skipped: true };
  return createBackup('auto');
});
ipcMain.handle('backup:list', () => ({ dir: backupDir(), mirrorDir: settings.mirrorDir || '', dataFile: DATA_FILE, version: VERSION, saveErr, settings: { onClose: settings.onClose, lastBackupAt: settings.lastBackupAt, lastMirror: settings.lastMirror }, items: listBackups() }));
ipcMain.handle('backup:restore', (e, name) => {
  const full = path.join(backupDir(), safeName(name));
  let t; try { t = fs.readFileSync(full, 'utf8'); } catch (err) { return { ok: false, error: 'تعذّر قراءة ملف النسخة.' }; }
  const p = parseSnapshotText(t);
  return p.ok ? applySnapshot(p) : p;
});
ipcMain.handle('backup:delete', (e, name) => {
  try { fs.unlinkSync(path.join(backupDir(), safeName(name))); return { ok: true }; } catch (err) { return { ok: false, error: err.message }; }
});
ipcMain.handle('import:pick', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'اختر ملف حزمة الاستيراد (brhan-import.json)', properties: ['openFile'], filters: [{ name: 'حزمة استيراد', extensions: ['json'] }, { name: 'كل الملفات', extensions: ['*'] }] });
  if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
  try {
    const st = fs.statSync(r.filePaths[0]); if (st.size > 60 * 1024 * 1024) return { ok: false, error: 'الملف كبير جدًا.' };
    const pkg = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8'));
    if (!pkg || pkg.app !== 'aqrab-import') return { ok: false, error: 'هذا ليس ملف حزمة استيراد للعقرب الحسابي.' };
    return { ok: true, pkg, file: path.basename(r.filePaths[0]) };
  } catch (err) { return { ok: false, error: 'تعذّر قراءة الملف: ' + err.message }; }
});
ipcMain.handle('backup:pick', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'اختر ملف النسخة الاحتياطية', properties: ['openFile'],
    filters: [{ name: 'نسخة احتياطية', extensions: ['json', 'txt'] }, { name: 'كل الملفات', extensions: ['*'] }]
  });
  if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
  let t; try { t = fs.readFileSync(r.filePaths[0], 'utf8'); } catch (err) { return { ok: false, error: 'تعذّر قراءة الملف.' }; }
  const p = parseSnapshotText(t);
  if (!p.ok) return p;
  pickedFile = r.filePaths[0];
  return { ok: true, created: p.created, stats: p.stats, file: path.basename(pickedFile) };
});
ipcMain.handle('backup:restorePicked', () => {
  if (!pickedFile) return { ok: false, error: 'لم يتم اختيار ملف.' };
  const p = parseSnapshotText(fs.readFileSync(pickedFile, 'utf8'));
  pickedFile = null;
  return p.ok ? applySnapshot(p) : p;
});
ipcMain.handle('backup:restoreText', (e, text) => {
  const p = parseSnapshotText(text);
  return p.ok ? applySnapshot(p) : p;
});
ipcMain.handle('backup:export', async () => {
  if (!hasData()) return { ok: false, error: 'لا توجد بيانات لتصديرها بعد.' };
  const r = await dialog.showSaveDialog(win, {
    title: 'تصدير نسخة احتياطية', defaultPath: path.join(app.getPath('documents'), `aqrab-backup_export_${stamp()}.json`),
    filters: [{ name: 'نسخة احتياطية', extensions: ['json'] }]
  });
  if (r.canceled || !r.filePath) return { ok: false, canceled: true };
  const res = createBackup('export', r.filePath);
  return res.ok ? { ok: true, file: r.filePath } : res;
});
ipcMain.handle('backup:openDir', async () => {
  try { fs.mkdirSync(backupDir(), { recursive: true }); } catch (e) {}
  const err = await shell.openPath(backupDir());
  return { ok: !err, error: err };
});
ipcMain.handle('backup:chooseDir', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'اختر مجلد النسخ الاحتياطية', properties: ['openDirectory', 'createDirectory'], defaultPath: backupDir() });
  if (r.canceled || !r.filePaths[0]) return { ok: false, canceled: true };
  settings.backupDir = r.filePaths[0] === DEFAULT_BACKUP_DIR ? '' : r.filePaths[0];
  saveSettings();
  return { ok: true, dir: backupDir() };
});
ipcMain.handle('backup:chooseMirror', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'اختر مجلد النسخة الإضافية (فلاش / قرص خارجي / OneDrive)', properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths[0]) return { ok: false };
  if (path.resolve(r.filePaths[0]) === path.resolve(backupDir())) return { ok: false, error: 'اختر مكانًا مختلفًا عن مجلد النسخ الأساسي، وإلا لا فائدة منه.' };
  try { fs.mkdirSync(r.filePaths[0], { recursive: true }); const t = path.join(r.filePaths[0], '.aq-write-test'); fs.writeFileSync(t, 'ok'); fs.unlinkSync(t); } catch (e) { return { ok: false, error: 'لا يمكن الكتابة في هذا المجلد: ' + e.message }; }
  settings.mirrorDir = r.filePaths[0]; settings.lastMirror = null; saveSettings();
  const b = createBackup('manual'); // نسخة فورية للتأكد أن النسخ الإضافي يعمل
  return { ok: true, dir: settings.mirrorDir, test: b };
});
ipcMain.handle('backup:clearMirror', () => { settings.mirrorDir = ''; settings.lastMirror = null; saveSettings(); return { ok: true }; });
ipcMain.handle('settings:onClose', (e, v) => {
  if (['ask', 'auto', 'never'].includes(v)) { settings.onClose = v; saveSettings(); }
  return { ok: true };
});

/* ---------------- العقرب الذكي: الاتصال بالخدمة من العملية الرئيسية فقط ---------------- */
const AI_PROVIDERS = {
  local: { name: 'وضع بدون إنترنت (مجاني، بدون مفتاح)', model: '', keyRe: /^$/ },
  anthropic: { name: 'Anthropic (Claude)', model: 'claude-sonnet-5-5', keyRe: /^[\x21-\x7e]{20,300}$/ },
  gemini: { name: 'Google Gemini (مجاني)', model: 'gemini-flash-latest', keyRe: /^[A-Za-z0-9_-]{20,100}$/ }
};
let aiBusy = false;
const aiProv = () => (AI_PROVIDERS[settings.aiProvider] ? settings.aiProvider : 'local');
const aiKeys = () => { settings.aiKeys = settings.aiKeys || {}; if (settings.aiKeyEnc && !settings.aiKeys.anthropic) settings.aiKeys.anthropic = settings.aiKeyEnc; return settings.aiKeys; };
const aiKey = () => { try { const e = aiKeys()[aiProv()]; return e && safeStorage.isEncryptionAvailable() ? safeStorage.decryptString(Buffer.from(e, 'base64')) : ''; } catch (e) { return ''; } };
const aiModel = () => ((settings.aiModels || {})[aiProv()]) || AI_PROVIDERS[aiProv()].model;
ipcMain.handle('ai:status', () => ({ provider: aiProv(), providers: Object.entries(AI_PROVIDERS).map(([k, v]) => [k, v.name]), hasKey: aiProv() === 'local' ? true : !!aiKey(), canStore: safeStorage.isEncryptionAvailable(), model: aiModel(), welcome: settings.aiWelcome !== false, speak: !!settings.aiSpeak }));
ipcMain.handle('ai:setKey', (e, key, prov) => {
  prov = AI_PROVIDERS[prov] ? prov : aiProv(); key = String(key || '').trim();
  if (prov === 'local') return { ok: false, error: 'الوضع بدون إنترنت لا يحتاج مفتاحًا.' };
  if (!AI_PROVIDERS[prov].keyRe.test(key)) return { ok: false, error: 'المفتاح غير صالح (يجب أن يكون نصًا إنجليزيًا بدون مسافات).' };
  if (!safeStorage.isEncryptionAvailable()) return { ok: false, error: 'تعذّر تشفير المفتاح على هذا الجهاز، فلم يُحفظ.' };
  aiKeys()[prov] = safeStorage.encryptString(key).toString('base64'); saveSettings(); return { ok: true };
});
ipcMain.handle('ai:clearKey', () => { aiKeys(); delete settings.aiKeys[aiProv()]; if (aiProv() === 'anthropic') delete settings.aiKeyEnc; saveSettings(); return { ok: true }; });
ipcMain.handle('ai:setOpts', (e, o) => {
  o = o || {};
  if (AI_PROVIDERS[o.provider]) settings.aiProvider = o.provider;
  if (typeof o.model === 'string' && /^[A-Za-z0-9._-]{3,80}$/.test(o.model.trim())) { settings.aiModels = settings.aiModels || {}; settings.aiModels[aiProv()] = o.model.trim(); }
  if (typeof o.welcome === 'boolean') settings.aiWelcome = o.welcome;
  if (typeof o.speak === 'boolean') settings.aiSpeak = o.speak;
  saveSettings(); return { ok: true };
});
/* الواجهة تتحدث بصيغة واحدة (صيغة Anthropic)؛ التحويل إلى Gemini وبالعكس هنا */
const tryJson = s => { try { return JSON.parse(s); } catch (e) { return s; } };
function toGemini(p) {
  const idName = {};
  p.messages.forEach(m => { if (Array.isArray(m.content)) m.content.forEach(b => { if (b.type === 'tool_use') idName[b.id] = b.name; }); });
  const contents = p.messages.map(m => {
    if (typeof m.content === 'string') return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] };
    if (m.role === 'assistant') return { role: 'model', parts: m.content.map(b => (b.type === 'tool_use' ? Object.assign({ functionCall: { name: b.name, args: b.input || {} } }, b._sig ? { thoughtSignature: b._sig } : {}) : (b.text ? { text: b.text } : null))).filter(Boolean) };
    return { role: 'user', parts: m.content.filter(b => b.type === 'tool_result').map(b => { const v = tryJson(b.content); return { functionResponse: { name: idName[b.tool_use_id] || 'tool', response: v && typeof v === 'object' && !Array.isArray(v) ? v : { result: v } } }; }) };
  });
  const decl = (p.tools || []).slice(0, 20).map(t => { const d = { name: t.name, description: t.description }; const pr = t.input_schema && t.input_schema.properties; if (pr && Object.keys(pr).length) d.parameters = { type: 'object', properties: pr }; if ((t.input_schema.required || []).length) d.parameters.required = t.input_schema.required; return d; });
  return { systemInstruction: { parts: [{ text: String(p.system || '').slice(0, 8000) }] }, contents, tools: decl.length ? [{ functionDeclarations: decl }] : undefined, generationConfig: { maxOutputTokens: 1024, temperature: 0.2 } };
}
function fromGemini(j) {
  const c = j && j.candidates && j.candidates[0], parts = (c && c.content && c.content.parts) || [], out = [];
  parts.forEach(pt => {
    if (pt.functionCall) out.push({ type: 'tool_use', id: 'g' + Math.random().toString(36).slice(2, 10), name: pt.functionCall.name, input: pt.functionCall.args || {}, _sig: pt.thoughtSignature });
    else if (pt.text && !pt.thought) out.push({ type: 'text', text: pt.text });
  });
  if (!out.length) out.push({ type: 'text', text: 'لم يتمكن النموذج من تكوين إجابة لهذا السؤال، جرّب صياغته بشكل آخر.' });
  return { content: out, stop_reason: c && c.finishReason };
}
const aiHttpError = (prov, status, body) => {
  const msg = body && body.error && body.error.message ? String(body.error.message).replace(/\s+/g, ' ').slice(0, 160) : '';
  const tag = ' [' + (prov === 'gemini' ? 'Gemini' : 'Anthropic') + ' — ' + status + (msg ? ': ' + msg : '') + ']';
  if (status === 401 || (status === 400 && /API key|API_KEY/i.test(msg)) || (prov === 'gemini' && status === 403)) return 'مفتاح الخدمة غير صحيح أو غير مسموح به.' + (prov === 'anthropic' ? ' تأكد أن المزوّد المختار في ⚙ يطابق نوع المفتاح (مفتاح Gemini يبدأ بـ AIza).' : '') + tag;
  if (status === 404) return 'النموذج غير موجود. غيّر اسم النموذج من ⚙.' + tag;
  if (status === 429) return (prov === 'gemini' ? 'انتهت الحصة المجانية لهذه الفترة (اليوم أو الدقيقة)، حاول لاحقًا.' : 'تجاوزتَ حد الاستخدام أو الرصيد، حاول لاحقًا.') + tag;
  if (status >= 500) return 'الخدمة غير متاحة مؤقتًا.' + tag;
  return 'رفضت الخدمة الطلب.' + tag;
};
ipcMain.handle('ai:complete', async (e, p) => {
  const key = aiKey(), prov = aiProv(); if (prov === 'local') return { ok: false, error: 'الوضع بدون إنترنت لا يستخدم الخدمة الخارجية.' };
  if (!key) return { ok: false, error: 'لم يُضبط مفتاح الخدمة بعد. افتح ⚙ في نافذة العقرب الذكي.' };
  if (aiBusy) return { ok: false, error: 'هناك طلب قيد التنفيذ، انتظر انتهاءه.' };
  if (!p || !Array.isArray(p.messages) || p.messages.length > 60 || JSON.stringify(p).length > 400000) return { ok: false, error: 'طلب غير صالح.' };
  aiBusy = true; const ac = new AbortController(), to = setTimeout(() => ac.abort(), 60000);
  try {
    let url, headers, body;
    if (prov === 'gemini') {
      url = 'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(aiModel()) + ':generateContent';
      headers = { 'content-type': 'application/json', 'x-goog-api-key': key }; body = toGemini(p);
    } else {
      url = 'https://api.anthropic.com/v1/messages'; headers = { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' };
      const clean = p.messages.map(m => (Array.isArray(m.content) ? { role: m.role, content: m.content.map(b => { const c = Object.assign({}, b); delete c._sig; return c; }) } : m));
      body = { model: aiModel(), max_tokens: 1024, system: String(p.system || '').slice(0, 8000), messages: clean, tools: Array.isArray(p.tools) ? p.tools.slice(0, 20) : undefined };
    }
    const r = await net.fetch(url, { method: 'POST', signal: ac.signal, headers, body: JSON.stringify(body) });
    const j = await r.json().catch(() => null);
    if (!r.ok) return { ok: false, error: aiHttpError(prov, r.status, j) };
    return { ok: true, data: prov === 'gemini' ? fromGemini(j) : { content: j && j.content, stop_reason: j && j.stop_reason } };
  } catch (err) { return { ok: false, error: err && err.name === 'AbortError' ? 'انتهت مهلة الاتصال.' : 'تعذّر الاتصال بالإنترنت أو بالخدمة.' }; }
  finally { clearTimeout(to); aiBusy = false; }
});
/* ---------------- الترخيص (انظر license.js) ---------------- */
const LIC = require('./license');
const LIC_FILE = path.join(USER, 'license.json');
const LIC_REQUIRED = require('./package.json').aqrabLicense === 'required';
/* المفتاح يُحفظ مشفّرًا (DPAPI عبر safeStorage) فلا يُقرأ من الملف؛ إن لم يتوفر التشفير يُحفظ كما هو */
function licLoad() {
  const r = readJson(LIC_FILE); if (!r) return null;
  if (typeof r.key === 'string' && r.key.startsWith('enc:')) {
    try { r.key = safeStorage.decryptString(Buffer.from(r.key.slice(4), 'base64')); } catch (e) { r.key = ''; }
  }
  return r;
}
function licSave(rec) {
  const o = Object.assign({}, rec);
  try { if (o.key && safeStorage.isEncryptionAvailable()) o.key = 'enc:' + safeStorage.encryptString(o.key).toString('base64'); } catch (e) { /* يبقى كما هو */ }
  writeAtomic(LIC_FILE, JSON.stringify(o), { noBak: true });
}
function licStatus() {
  const rec = licLoad();
  const e = LIC.evaluate(rec, Date.now(), LIC_REQUIRED);
  try { if (LIC_REQUIRED) licSave(e.rec); } catch (x) { /* لا يوقف التطبيق */ }
  const { rec: r, ...pub } = e; return pub;
}
ipcMain.handle('lic:status', () => licStatus());
ipcMain.handle('lic:activate', (e, text) => {
  const r = LIC.activate(licLoad(), text, Date.now());
  if (!r.ok) return r;
  try { licSave(r.rec); } catch (x) { return { ok: false, error: 'تعذّر حفظ الترخيص: ' + x.message }; }
  return { ok: true, status: licStatus() };
});
/* ---------------- التحديثات (انظر updater.js) ---------------- */
const UPD = require('./updater');
const UPDATE_URL = require('./package.json').aqrabUpdateUrl || '';
const https = require('https');
function httpsGet(url, opt, hops) {
  opt = opt || {}; hops = hops || 0;
  return new Promise((resolve, reject) => {
    if (!UPD.okUrl(url)) return reject(new Error('رابط غير آمن (يجب أن يبدأ بـ https)'));
    if (hops > 5) return reject(new Error('تحويلات كثيرة'));
    const req = https.get(url, { headers: { 'User-Agent': 'AqrabAccounting/' + VERSION } }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) { res.resume(); return httpsGet(new URL(res.headers.location, url).href, opt, hops + 1).then(resolve, reject); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('الخادم أجاب برمز ' + res.statusCode)); }
      const chunks = []; let got = 0;
      res.on('data', c => { got += c.length; if (got > (opt.max || 5e6)) { req.destroy(new Error('الملف أكبر من المتوقع')); return; } chunks.push(c); if (opt.progress) opt.progress(got); });
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    });
    req.setTimeout(30000, () => req.destroy(new Error('انتهت مهلة الاتصال')));
    req.on('error', reject);
  });
}
const updDir = () => path.join(path.dirname(backupDir()), 'التحديثات');
let LAST_UPDATE = null;
ipcMain.handle('update:check', async () => {
  if (!UPDATE_URL || /OWNER/.test(UPDATE_URL)) return { state: 'error', error: 'رابط التحديثات غير مضبوط في هذه النسخة.', version: VERSION };
  try {
    const buf = await httpsGet(UPDATE_URL, { max: 200000 });
    const d = UPD.decide(VERSION, buf.toString('utf8'));
    LAST_UPDATE = d.state === 'available' ? d.info : null;
    return Object.assign({ version: VERSION }, d);
  } catch (e) { return { state: 'error', error: 'تعذّر الاتصال بخادم التحديثات: ' + e.message, version: VERSION }; }
});
ipcMain.handle('update:download', async () => {
  const info = LAST_UPDATE; if (!info) return { ok: false, error: 'افحص التحديثات أولًا.' };
  try {
    const buf = await httpsGet(info.url, { max: info.size + 1024, progress: got => { if (win && !win.isDestroyed()) win.webContents.send('update:progress', Math.round(got * 100 / info.size)); } });
    if (buf.length !== info.size || UPD.sha256(buf) !== info.sha256) return { ok: false, error: 'الملف الذي تم تنزيله لا يطابق التوقيع/البصمة المتوقعة، فتم رفضه ولم يُحفظ.' };
    const dir = updDir(); fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, 'AqrabAccounting-Setup-' + info.version + '.zip');
    fs.writeFileSync(file + '.part', buf); fs.renameSync(file + '.part', file);
    try { createBackup('pre-update'); } catch (e) { /* النسخة الاحتياطية اختيارية هنا */ }
    return { ok: true, file, version: info.version };
  } catch (e) { return { ok: false, error: 'فشل التنزيل: ' + e.message }; }
});
ipcMain.handle('update:show', (e, file) => { if (typeof file === 'string' && file.startsWith(updDir())) shell.showItemInFolder(file); return true; });
ipcMain.handle('win:fs', () => { if (win && !win.isDestroyed()) win.setFullScreen(!win.isFullScreen()); return true; });
ipcMain.handle('print:list', async () => {
  try {
    const l = await win.webContents.getPrintersAsync();
    return { ok: true, saved: settings.printer || '', items: l.map(p => ({ name: p.name, label: p.displayName || p.name, def: !!p.isDefault })) };
  } catch (e) { return { ok: false, items: [], saved: '' }; }
});
/* ---- الطباعة: صفحة معزولة ثابتة (A4 بهوامش 12 مم أو إيصال 80 مم) مستقلة عن تخطيط البرنامج ---- */
function buildPrintDoc(html, kind, hMm) {
  let css = '';
  try { css = fs.readFileSync(path.join(__dirname, 'css', 'print.css'), 'utf8'); } catch (e) {}
  const rc = kind === 'rc', a5 = kind === 'a5';
  const page = rc ? `@page{size:80mm ${hMm}mm;margin:0}` : a5 ? '@page{size:A5;margin:0}' : '@page{size:A4;margin:0}';
  const body = rc ? `<div class=rcwrap>${html}</div>`
    : `<table class=pgt><thead><tr><td><div class=sp></div></td></tr></thead><tbody><tr><td>${html}</td></tr></tbody><tfoot><tr><td><div class=sp></div></td></tr></tfoot></table>`;
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>${page}
*{box-sizing:border-box}
html,body{margin:0;padding:0;background:#fff;color:#000;direction:rtl;font-family:Tajawal,"Segoe UI",Tahoma,Arial,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}
table{border-collapse:collapse}th,td{text-align:right}
.pgt{width:100%}.pgt>thead>tr>td,.pgt>tfoot>tr>td{padding:0;border:0}.pgt .sp{height:${a5 ? 8 : 12}mm}.pgt>tbody>tr>td{padding:0 ${a5 ? 8 : 12}mm;border:0;vertical-align:top}
.rcwrap{width:80mm;padding:2mm}
${css}</style></head><body>${body}</body></html>`;
}
async function renderDoc(o) {
  o = o || {};
  const kind = o.kind === 'rc' ? 'rc' : o.kind === 'a5' ? 'a5' : 'a4';
  const h = Math.min(2000, Math.max(100, Math.ceil(+o.heightMm || 150) + 6));
  const file = path.join(app.getPath('temp'), 'aqrab-print-' + Date.now() + '.html');
  fs.writeFileSync(file, buildPrintDoc(String(o.html || ''), kind, h), 'utf8');
  const w = new BrowserWindow({ show: false, width: 900, height: 1200, webPreferences: { sandbox: true, contextIsolation: true, nodeIntegration: false, javascript: false } });
  await w.loadFile(file);
  await new Promise(r => setTimeout(r, 150));
  const done = () => { try { w.destroy(); } catch (e) {} try { fs.unlinkSync(file); } catch (e) {} };
  return { w, kind, h, file, done };
}
function printOpts(d, name, silent) {
  const o = { silent, printBackground: true, margins: { marginType: 'none' }, pageSize: d.kind === 'rc' ? { width: 80000, height: d.h * 1000 } : d.kind === 'a5' ? 'A5' : 'A4' };
  if (name) o.deviceName = name;
  return o;
}
async function doPrint(o, silent) {
  o = o || {};
  const name = String(o.printer || '');
  if (name !== (settings.printer || '')) { settings.printer = name; saveSettings(); }
  let d;
  try { d = await renderDoc(o); } catch (e) { return { ok: false, error: 'تعذّر تجهيز صفحة الطباعة: ' + e.message }; }
  const opts = printOpts(d, name, silent);
  if (process.env.AQ_TEST_PRINT_CAPTURE) { // للاختبار الآلي فقط
    fs.writeFileSync(process.env.AQ_TEST_PRINT_CAPTURE, JSON.stringify({ opts, doc: fs.readFileSync(d.file, 'utf8') }));
    d.done(); return { ok: true };
  }
  return new Promise(resolve => {
    try {
      d.w.webContents.print(opts, (ok, why) => { d.done(); resolve(ok ? { ok: true } : { ok: false, error: why === 'cancelled' || why === 'Print job canceled' ? 'أُلغيت الطباعة' : 'تعذّرت الطباعة' + (why ? ' (' + why + ')' : '') + '. جرّب «خيارات الطباعة» أو «حفظ PDF».' }); });
    } catch (err) { d.done(); resolve({ ok: false, error: 'تعذّرت الطباعة: ' + err.message }); }
  });
}
ipcMain.handle('print:direct', (e, o) => doPrint(o, true));
ipcMain.handle('print:dialog', (e, o) => doPrint(o, false));
ipcMain.handle('print:pdf', async (e, o) => {
  let d;
  try {
    d = await renderDoc(o);
    const buf = await d.w.webContents.printToPDF({ preferCSSPageSize: true, printBackground: true });
    const r = await dialog.showSaveDialog(win, { title: 'حفظ PDF', defaultPath: path.join(app.getPath('documents'), (d.kind === 'rc' ? 'ايصال-' : d.kind === 'a5' ? 'فاتورة-A5-' : 'فاتورة-') + stamp() + '.pdf'), filters: [{ name: 'PDF', extensions: ['pdf'] }] });
    if (r.canceled || !r.filePath) return { ok: false };
    fs.writeFileSync(r.filePath, buf);
    shell.showItemInFolder(r.filePath);
    return { ok: true, file: r.filePath };
  } catch (err) { return { ok: false, error: 'تعذّر إنشاء PDF: ' + err.message }; }
  finally { if (d) d.done(); }
});
ipcMain.handle('app:quit', () => { if (win) win.close(); });

/* ---------------- النافذة ---------------- */
let win = null, allowClose = false, closing = false;

function createWindow() {
  win = new BrowserWindow({
    width: 1280, height: 820, minWidth: 900, minHeight: 600,
    title: APP_TITLE, backgroundColor: '#141a33', show: false,
    icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: false }
  });
  win.once('ready-to-show', () => win.show());
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file://')) e.preventDefault(); });
  win.webContents.on('page-title-updated', e => e.preventDefault());
  win.on('close', async e => {
    if (allowClose) return;
    e.preventDefault();
    if (closing) return;
    closing = true;
    try {
      if (await confirmClose()) { allowClose = true; flushStore(); saveSettings(); win.close(); }
    } finally { closing = false; }
  });
  win.on('closed', () => { win = null; });
}

/* نافذة الإغلاق: خيار حفظ نسخة احتياطية */
async function confirmClose() {
  flushStore();
  if (!hasData() || dataHash() === settings.lastBackupHash) return true; // لا تغييرات منذ آخر نسخة
  if (settings.onClose === 'never') return true;
  if (settings.onClose === 'auto') {
    const r = createBackup('close');
    if (r.ok) return true;
    return (await dialog.showMessageBox(win, { type: 'error', buttons: ['إغلاق بدون نسخة', 'إلغاء'], defaultId: 1, cancelId: 1, title: APP_TITLE, message: 'فشل حفظ النسخة الاحتياطية', detail: r.error, noLink: true })).response === 0;
  }
  const last = settings.lastBackupAt ? new Date(settings.lastBackupAt).toLocaleString('ar-EG') : 'لا توجد';
  const res = await dialog.showMessageBox(win, {
    type: 'question', title: APP_TITLE, noLink: true,
    buttons: ['حفظ نسخة احتياطية ثم إغلاق', 'إغلاق بدون نسخة', 'إلغاء'], defaultId: 0, cancelId: 2,
    message: 'هل تريد حفظ نسخة احتياطية من بياناتك قبل الإغلاق؟',
    detail: `آخر نسخة احتياطية: ${last}\nمكان الحفظ: ${backupDir()}`,
    checkboxLabel: 'تذكّر اختياري ولا تسألني مرة أخرى (يمكن تغييره من الإعدادات)', checkboxChecked: false
  });
  if (res.response === 2) return false;
  if (res.checkboxChecked) { settings.onClose = res.response === 0 ? 'auto' : 'never'; saveSettings(); }
  if (res.response === 0) {
    const r = createBackup('close');
    if (!r.ok) {
      const again = await dialog.showMessageBox(win, { type: 'error', buttons: ['إغلاق بدون نسخة', 'إلغاء'], defaultId: 1, cancelId: 1, title: APP_TITLE, message: 'فشل حفظ النسخة الاحتياطية', detail: r.error, noLink: true });
      return again.response === 0;
    }
  }
  return true;
}

function buildMenu() {
  const nav = tab => () => { if (win) { win.show(); win.webContents.send('nav', tab); } };
  const T = [
    { label: 'ملف', submenu: [
      { label: 'إنشاء نسخة احتياطية الآن', accelerator: 'CmdOrCtrl+B', click: async () => {
          const r = createBackup('manual');
          dialog.showMessageBox(win, r.ok ? { type: 'info', title: APP_TITLE, message: 'تم حفظ النسخة الاحتياطية', detail: r.file, buttons: ['حسنًا'] } : { type: 'error', title: APP_TITLE, message: r.error, buttons: ['حسنًا'] });
        } },
      { label: 'إدارة النسخ الاحتياطية والاستعادة', click: nav('t') },
      { label: 'فتح مجلد النسخ الاحتياطية', click: () => { try { fs.mkdirSync(backupDir(), { recursive: true }); } catch (e) {} shell.openPath(backupDir()); } },
      { type: 'separator' },
      { label: 'خروج', accelerator: 'Alt+F4', click: () => { if (win) win.close(); } }
    ] },
    { label: 'عرض', submenu: [
      { label: 'تكبير', role: 'zoomIn' }, { label: 'تصغير', role: 'zoomOut' }, { label: 'الحجم الافتراضي', role: 'resetZoom' },
      { type: 'separator' }, { label: 'ملء الشاشة', role: 'togglefullscreen' },
      ...(process.env.AQ_DEBUG ? [{ type: 'separator' }, { label: 'أدوات المطور', role: 'toggleDevTools' }] : [])
    ] },
    { label: 'مساعدة', submenu: [
      { label: 'عن البرنامج', click: () => dialog.showMessageBox(win, { type: 'info', title: APP_TITLE, message: APP_TITLE, detail: `الإصدار ${VERSION}\n\nملف البيانات:\n${DATA_FILE}\n\nمجلد النسخ الاحتياطية:\n${backupDir()}`, buttons: ['حسنًا'] }) }
    ] }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(T));
}

/* ---------------- استرداد عند التشغيل + نسخ دوري ---------------- */
function recoverStartup() {
  const cc = LOADED.corruptCopy ? `\n\nالملف التالف محفوظ للفحص في:\n${LOADED.corruptCopy}` : '';
  if (LOADED.status === 'bak') {
    flushStore();
    startupNotice = { type: 'warning', message: 'تعذّرت قراءة ملف البيانات الرئيسي', detail: 'تمت استعادة بياناتك تلقائيًا من النسخة الداخلية السابقة (آخر حفظ قبل المشكلة). راجع آخر عملياتك للتأكد، ويمكنك الاستعادة من «الإعدادات ← النسخ الاحتياطي» إن لزم.' + cc };
  } else if (LOADED.status === 'lost') {
    const dirs = [backupDir()].concat(settings.mirrorDir ? [settings.mirrorDir] : []);
    for (const dir of dirs) {
      for (const b of listBackups(dir)) {
        try {
          const p = parseSnapshotText(fs.readFileSync(path.join(dir, b.name), 'utf8'));
          if (!p.ok) continue;
          const r = applySnapshot(p);
          if (r.ok) { startupNotice = { type: 'warning', message: 'ملف البيانات كان تالفًا — تمت الاستعادة من آخر نسخة احتياطية', detail: `النسخة: ${b.name}\nتاريخها: ${new Date(b.created).toLocaleString('ar-EG')}\nأي عمليات بعدها لن تظهر، فراجع آخر فواتيرك.` + cc }; return; }
        } catch (e) { /* جرّب التي تليها */ }
      }
    }
    startupNotice = { type: 'error', message: 'ملف البيانات تالف ولم تُوجد نسخة احتياطية صالحة', detail: 'لم يُحذف شيء: الملف التالف محفوظ ويمكن فحصه أو إرساله للدعم.' + cc };
  }
}
let lastBackupErr = '';
function backupTick(delay) {
  setTimeout(() => {
    try {
      if (!hasData()) return;
      const t = ST.todayStr();
      let r = null;
      if (settings.lastDaily !== t) { r = createBackup('daily'); if (r.ok) { settings.lastDaily = t; saveSettings(); } }
      else if (dataHash() !== settings.lastBackupHash && Date.now() - (settings.lastBackupAt ? Date.parse(settings.lastBackupAt) : 0) >= 20 * 60 * 1000) r = createBackup('auto');
      if (r && !r.ok) { lastBackupErr = r.error; if (win && !win.isDestroyed()) win.webContents.send('backup:warn', r.error); }
      else if (r && r.ok) { lastBackupErr = ''; }
    } catch (e) { console.error('backup tick', e); }
  }, delay);
}

/* ---------------- تشغيل ---------------- */
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => {
    session.defaultSession.setPermissionRequestHandler((wc, perm, cb) => cb(false));
    buildMenu();
    recoverStartup();
    // نسخة أمان تلقائية عند التشغيل إذا تغيّرت البيانات منذ آخر نسخة (تحمي من الانهيار المفاجئ)
    if (hasData() && dataHash() !== settings.lastBackupHash) createBackup('auto');
    createWindow();
    win.once('ready-to-show', () => { if (startupNotice) dialog.showMessageBox(win, Object.assign({ title: APP_TITLE, buttons: ['حسنًا'] }, startupNotice)); });
    backupTick(15000); setInterval(() => backupTick(0), 5 * 60 * 1000);
  });
  app.on('before-quit', () => { flushStore(); });
  app.on('window-all-closed', () => app.quit());
}
