/* ai-tools.js — أدوات القراءة الآمنة للعقرب الذكي
 * كل أداة: تتحقق من صلاحية المستخدم الحالي، تقرأ من المحرك الموجود (بدون أي حساب مالي خاص بها)،
 * وتعيد أرقامًا منسّقة مع الفترة والمصدر. لا توجد أداة تكتب أو تحذف أو تعدّل أي شيء. */
'use strict';
(function (root) {
  const DATE = /^\d{4}-\d{2}-\d{2}$/;
  const E = () => root.Engine, M = () => root.Money;
  const base = St => St.set.base;
  const dec = (St, c) => E().decOf(St, c || base(St));
  const f = (St, v, c) => M().fmt(v, dec(St, c)) + ' ' + (c || base(St));
  const qf = q => M().fmt(q, 3).replace(/\.?0+$/, '');
  const norm = t => String(t || '').replace(/[ً-ٰٟـ]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
    .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[؟?!،,.:؛]/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
  const err = m => { const e = new Error(m); e.user = true; return e; };

  function range(St, a, today) {
    let from = a && a.from, to = a && a.to;
    if (!from && !to) from = to = today;
    if (from && !DATE.test(from)) throw err('تاريخ البداية غير صالح (الصيغة YYYY-MM-DD)');
    if (to && !DATE.test(to)) throw err('تاريخ النهاية غير صالح (الصيغة YYYY-MM-DD)');
    if (from && to && from > to) throw err('تاريخ البداية بعد تاريخ النهاية');
    return { from: from || undefined, to: to || undefined };
  }
  const label = r => (r.from || '…') + ' → ' + (r.to || '…');
  const lim = (n, d) => Math.max(1, Math.min(50, Math.floor(+n) || d));

  /* الوحدات المباعة لكل منتج بعد خصم المرتجعات (من الفواتير غير الملغاة) */
  function sold(St, r) {
    const out = {};
    St.inv.forEach(i => {
      if (i.void || (r.from && i.date < r.from) || (r.to && i.date > r.to)) return;
      const rq = {}; (i.rt || []).filter(x => !x.void).forEach(x => x.lines.forEach(l => { rq[l.k] = (rq[l.k] || 0) + l.q; }));
      i.items.forEach((x, k) => { const q = x.q - (rq[k] || 0); if (q > 0) out[x.p] = (out[x.p] || 0) + q; });
    });
    return out;
  }
  const pname = (St, id) => { const p = St.prod.find(z => z.id === id); return p ? p.n : id; };
  const addDays = (d, n) => { const t = new Date(d + 'T12:00:00Z'); t.setUTCDate(t.getUTCDate() + n); return t.toISOString().slice(0, 10); };

  /* ctx: { S, uid, today } — يُمرَّر من الواجهة؛ any: يكفي واحدة من الصلاحيات */
  const TOOLS = [
    { name: 'sales_summary', any: ['rep'], description: 'ملخص المبيعات والربح والمصاريف لفترة (افتراضيًا اليوم). الأرقام بعملة النظام الأساسية.',
      input_schema: { type: 'object', properties: { from: { type: 'string', description: 'YYYY-MM-DD' }, to: { type: 'string', description: 'YYYY-MM-DD' } } },
      run(c, a) {
        const r = range(c.S, a, c.today), p = E().profitLoss(c.S, r);
        return { الفترة: label(r), عدد_الفواتير: p.invoices, صافي_المبيعات: f(c.S, p.revenue), إجمالي_المبيعات_مع_الضريبة: f(c.S, p.salesTotal), تكلفة_البضاعة: f(c.S, p.cogs), مجمل_الربح: f(c.S, p.gross), المصاريف: f(c.S, p.expenses), صافي_الربح: f(c.S, p.net), المصدر: 'تقرير الأرباح والخسائر' };
      } },
    { name: 'top_products', any: ['rep'], description: 'المنتجات الأكثر مبيعًا (بالكمية الصافية بعد المرتجعات) في فترة.',
      input_schema: { type: 'object', properties: { from: { type: 'string' }, to: { type: 'string' }, limit: { type: 'integer' } } },
      run(c, a) {
        const r = range(c.S, a, c.today), s = sold(c.S, r);
        const rows = Object.entries(s).sort((x, y) => y[1] - x[1]).slice(0, lim(a && a.limit, 10)).map(([id, q]) => ({ المنتج: pname(c.S, id), الكمية: qf(q) }));
        return { الفترة: label(r), المنتجات: rows, المصدر: 'بنود الفواتير غير الملغاة بعد خصم المرتجعات' };
      } },
    { name: 'low_stock', any: ['prod', 'rep'], description: 'المنتجات التي وصلت كميتها إلى حد الطلب أو أقل.',
      input_schema: { type: 'object', properties: { limit: { type: 'integer' } } },
      run(c, a) {
        const rows = E().stockReport(c.S).filter(x => x.low).sort((x, y) => x.q - y.q);
        return { عدد_المنتجات_المنخفضة: rows.length, المنتجات: rows.slice(0, lim(a && a.limit, 15)).map(x => ({ المنتج: x.n, الكمية: qf(x.q) })), المصدر: 'تقرير المخزون' };
      } },
    { name: 'stock_capital', any: ['prod', 'rep'], description: 'رأس مال المخزون: قيمة البضاعة الحالية بسعر التكلفة وبسعر البيع (الكميات السالبة لا تُحتسب، والمنتجات المؤرشفة مستبعدة).',
      input_schema: { type: 'object', properties: {} },
      run(c) {
        const r = E().stockReport(c.S), cost = r.reduce((a, x) => a + x.value, 0), sell = r.reduce((a, x) => a + M().lineTotal(x.pr, Math.max(x.q, 0)), 0);
        return { التاريخ: c.today, عدد_المنتجات: r.length, رأس_المال_بسعر_التكلفة: f(c.S, cost), القيمة_بسعر_البيع: f(c.S, sell), المصدر: 'تقرير المخزون (الكمية الحالية × التكلفة المسجلة)' };
      } },
    { name: 'find_product', any: ['prod', 'rep', 'sell'], description: 'بحث عن منتج باسمه أو بباركوده: الكمية الحالية وسعر البيع (والتكلفة لمن لديه صلاحية المنتجات).',
      input_schema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] },
      run(c, a) {
        const q = norm((a && a.query) || ''); if (!q) throw err('اكتب اسم المنتج أو باركوده');
        const showCo = E().can(c.S, c.uid, 'prod') || E().can(c.S, c.uid, 'rep');
        const hit = c.S.prod.filter(p => !p.arch && ((p.bc && p.bc.toLowerCase() === q) || norm(p.n).includes(q) || norm(p.model).includes(q)));
        return { عدد_النتائج: hit.length, المنتجات: hit.slice(0, 8).map(p => { const o = { المنتج: p.n, الباركود: p.bc || '—', الكمية: qf(p.q), سعر_البيع: f(c.S, p.pr) }; if (showCo) o.التكلفة = f(c.S, p.co); if (p.q <= p.mn) o.تنبيه = 'وصل حد الطلب أو أقل'; return o; }), المصدر: 'بطاقة المنتج' };
      } },
    { name: 'unpaid_invoices', any: ['rep', 'collect'], description: 'الفواتير غير المسددة بالكامل (المتبقي أكبر من صفر)، مع مجموع المتبقي لكل عملة.',
      input_schema: { type: 'object', properties: { limit: { type: 'integer' } } },
      run(c, a) {
        const rows = E().salesRows(c.S, {}).filter(x => x.due > 0).sort((x, y) => (x.date < y.date ? 1 : -1));
        const tot = {}; rows.forEach(x => { tot[x.cur] = (tot[x.cur] || 0) + x.due; });
        return { عدد_الفواتير: rows.length, مجموع_المتبقي: Object.fromEntries(Object.entries(tot).map(([k, v]) => [k, f(c.S, v, k)])),
          أحدث_الفواتير: rows.slice(0, lim(a && a.limit, 10)).map(x => ({ الفاتورة: x.no, التاريخ: x.date, العميل: x.cn, المتبقي: f(c.S, x.due, x.cur) })), المصدر: 'المبيعات والدفعات المسجلة' };
      } },
    { name: 'balances', any: ['party', 'rep'], description: 'أرصدة العملاء (kind=cust، الموجب = مبلغ مستحق لنا على العميل) أو الموردين (kind=sup، الموجب = مستحق للمورد علينا).',
      input_schema: { type: 'object', properties: { kind: { type: 'string', enum: ['cust', 'sup'] }, limit: { type: 'integer' } }, required: ['kind'] },
      run(c, a) {
        const kind = a && a.kind === 'sup' ? 'sup' : 'cust', b = E().balances(c.S, kind), list = kind === 'cust' ? c.S.cust : c.S.sup;
        const rows = []; Object.entries(b).forEach(([id, o]) => Object.entries(o).forEach(([cur, v]) => { if (v !== 0) rows.push({ id, cur, v }); }));
        rows.sort((x, y) => Math.abs(y.v) - Math.abs(x.v));
        const tot = {}; rows.forEach(x => { tot[x.cur] = (tot[x.cur] || 0) + x.v; });
        return { النوع: kind === 'cust' ? 'العملاء' : 'الموردون', المجموع: Object.fromEntries(Object.entries(tot).map(([k, v]) => [k, f(c.S, v, k)])), عدد_الأرصدة: rows.length,
          الأكبر: rows.slice(0, lim(a && a.limit, 10)).map(x => { const e = list.find(z => z.id === x.id); return { الاسم: e ? e.n : x.id, الرصيد: f(c.S, x.v, x.cur) }; }), ملاحظة: 'الموجب = مستحق (للعميل: نستلمه منه؛ للمورد: ندفع له)، والسالب = رصيد دائن للطرف', المصدر: 'أرصدة الفواتير والدفعات' };
      } },
    { name: 'compare_months', any: ['rep'], description: 'مقارنة الشهر الحالي حتى اليوم بنفس الأيام من الشهر السابق وبالشهر السابق كاملًا.',
      input_schema: { type: 'object', properties: {} },
      run(c) {
        const t = c.today, m0 = t.slice(0, 7) + '-01', day = +t.slice(8, 10);
        const pe = addDays(m0, -1), ps = pe.slice(0, 7) + '-01', pSame = ps.slice(0, 8) + String(Math.min(day, +pe.slice(8, 10))).padStart(2, '0');
        const g = r => { const p = E().profitLoss(c.S, r); return { الفترة: label(r), عدد_الفواتير: p.invoices, صافي_المبيعات: f(c.S, p.revenue), مجمل_الربح: f(c.S, p.gross), صافي_الربح: f(c.S, p.net) }; };
        return { الشهر_الحالي_حتى_اليوم: g({ from: m0, to: t }), نفس_الأيام_من_الشهر_السابق: g({ from: ps, to: pSame }), الشهر_السابق_كاملًا: g({ from: ps, to: pe }), المصدر: 'تقرير الأرباح والخسائر' };
      } },
    { name: 'find_invoice', any: ['rep', 'sell'], description: 'بحث عن فاتورة برقمها أو باسم العميل (أحدث 10 نتائج).',
      input_schema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] },
      run(c, a) {
        const q = norm((a && a.query) || ''); if (!q) throw err('اكتب رقم الفاتورة أو اسم العميل');
        const pm = E().paidMap(c.S);
        const rows = c.S.inv.filter(i => i.no.toLowerCase().includes(q) || norm(i.cn).includes(q)).sort((x, y) => (x.date < y.date ? 1 : -1)).slice(0, 10)
          .map(i => { const v = E().invView(c.S, i, pm); return { الفاتورة: i.no, التاريخ: i.date, العميل: i.cn, الإجمالي: f(c.S, v.c.totEff, i.cur), المدفوع: f(c.S, v.paid, i.cur), المتبقي: f(c.S, v.due, i.cur), الحالة: i.void ? 'ملغاة' : 'سارية' }; });
        return { النتائج: rows, المصدر: 'سجل الفواتير' };
      } },
    { name: 'reorder_suggestions', any: ['prod', 'rep'], description: 'اقتراح كميات إعادة الطلب لتغطية 30 يومًا بناءً على مبيعات آخر N يومًا (افتراضيًا 30). اقتراح فقط وليس أمر شراء.',
      input_schema: { type: 'object', properties: { days: { type: 'integer' }, limit: { type: 'integer' } } },
      run(c, a) {
        const days = Math.max(7, Math.min(365, Math.floor(+(a && a.days)) || 30)), r = { from: addDays(c.today, -(days - 1)), to: c.today }, s = sold(c.S, r);
        const rows = [];
        c.S.prod.forEach(p => {
          if (p.arch || !s[p.id]) return;
          const need = Math.ceil((s[p.id] * 30 / days - Math.max(p.q, 0)) / 1000);
          const cover = p.q > 0 ? Math.round(p.q / (s[p.id] / days)) : 0;
          if (need > 0 && (p.q <= p.mn || cover < 14)) rows.push({ المنتج: p.n, المخزون: qf(p.q), مبيع_الفترة: qf(s[p.id]), يكفي_تقريبًا_أيام: cover, المقترح_شراؤه: need, need });
        });
        rows.sort((x, y) => x.يكفي_تقريبًا_أيام - y.يكفي_تقريبًا_أيام);
        return { فترة_التحليل: label(r), المنتجات: rows.slice(0, lim(a && a.limit, 15)).map(x => { delete x.need; return x; }), ملاحظة: 'اقتراح تقريبي مبني على معدل البيع فقط، ولا يأخذ الموسمية ولا ميزانيتك بالحسبان', المصدر: 'بنود الفواتير والمخزون الحالي' };
      } }
  ];

  const byName = Object.fromEntries(TOOLS.map(t => [t.name, t]));
  const defs = () => TOOLS.map(t => ({ name: t.name, description: t.description, input_schema: t.input_schema }));
  /* يعيد دائمًا نصًا JSON؛ الأخطاء والصلاحيات تُعاد كنتيجة {خطأ} ليشرحها المساعد */
  function run(name, args, ctx) {
    try {
      const t = byName[name]; if (!t) return JSON.stringify({ خطأ: 'أداة غير معروفة' });
      if (!t.any.some(p => E().can(ctx.S, ctx.uid, p))) return JSON.stringify({ خطأ: 'ليست لدى المستخدم الحالي صلاحية لهذه المعلومات' });
      return JSON.stringify(t.run(ctx, args || {}));
    } catch (e) { return JSON.stringify({ خطأ: e.user ? e.message : 'تعذّر تنفيذ الطلب' }); }
  }
  root.AIT = { defs, run, TOOLS, norm };
  if (typeof module === 'object' && module.exports) module.exports = root.AIT;
})(typeof window !== 'undefined' ? window : globalThis);
