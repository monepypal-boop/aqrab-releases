/* ui-pages2.js — المصاريف والصندوق، العملات، التقارير، المستخدمون، الإعدادات */
'use strict';
Object.assign(FLT, { rp: { from: '', to: '', by: 'day' }, pl: { from: '', to: '' }, st: { k: 'cust', id: '' } });
const docNo = ref => {
  const s = S(); if (!ref) return '';
  if (ref.t === 'inv') { const i = s.inv.find(x => x.id === ref.id); return i ? i.no : ''; }
  if (ref.t === 'pur') { const i = s.pur.find(x => x.id === ref.id); return i ? i.no : ''; }
  if (ref.t === 'exp') { const i = s.exp.find(x => x.id === ref.id); return i ? i.n : ''; }
  return '';
};

/* ================= المصاريف والصندوق ================= */
PAGES.expenses = () => {
  const sub = curSub('expenses', 'exp'), s = S(), tabs = tabsHTML([['exp', 'المصاريف'], ['cash', 'الصندوق']], sub);
  if (sub === 'cash') {
    const cb = Engine.cashBalances(s), codes = Object.keys(cb);
    const led = s.cash.slice().reverse();
    return `<h2 class=pt>المصاريف والصندوق</h2>${tabs}<div class=g>${codes.length ? codes.map(c => `<div class="k hi"><small>رصيد الصندوق — ${esc(c)}</small><b>${fm(sumVals(cb[c]), c)}</b><small>${METHODS.map(m => m[1] + ': ' + fm(cb[c][m[0]] || 0, c)).join(' | ')}</small></div>`).join('') : `<div class="k hi"><small>رصيد الصندوق</small><b>${fm(0)}</b></div>`}</div>
    <div class=cd><div class=tb style="justify-content:flex-end">${newBtn('cashIn', '+ إيداع', 'cash')}${newBtn('cashOut', '− سحب', 'cash')}</div><p class=mu style="margin-top:0">كل رصيد يُحسب من الحركات أدناه فقط (مبيعات، تحصيل، رد، مصاريف، سداد موردين، إيداع وسحب).</p>${tbl(['الوقت', 'النوع', 'المرجع', 'الطريقة', 'المبلغ', 'ملاحظة', 'بواسطة'], lim(led, 200).map(c => [fdt(c.ts), KINDL[c.kind] || esc(c.kind), esc(docNo(c.ref)), METHOD_L[c.method] || esc(c.method), `<span class="num ${c.amt < 0 ? 'bd' : 'ok'}">${fm(c.amt, c.cur)}</span>`, esc(c.note || ''), userName(c.by)]))}${notice(200, led.length)}</div>`;
  }
  const l = s.exp.slice().sort((a, b) => (a.date + a.ts < b.date + b.ts ? 1 : -1)), tot = l.filter(e => !e.void).reduce((a, e) => a + toB(e.a, e.cur, e.fx), 0);
  return `<h2 class=pt>المصاريف والصندوق</h2>${tabs}<div class=g><div class="k hi"><small>إجمالي المصروفات (${esc(baseCode())})</small><b>${fm(tot)}</b></div></div><div class=cd><div class=tb style="justify-content:flex-end">${newBtn('expAdd', '+ مصروف', 'exp')}</div>${tbl(['التاريخ', 'البيان', 'التصنيف', 'المبلغ', 'بواسطة', 'الحالة', ''], lim(l, 300).map(e => [e.date, esc(e.n), esc(e.cat), fm(e.a, e.cur), userName(e.by), e.void ? chip('ملغى', 'mu') : chip('نافذ', 'ok'), !e.void && can('exp') ? btn('expVoid', 'إلغاء', { id: e.id }, 'dl') : '']))}${notice(300, l.length)}</div>`;
};
ACT.expAdd = () => form({
  title: 'إضافة مصروف', fields: [{ k: 'n', l: 'البيان', req: 1, full: 1 }, { k: 'cat', l: 'التصنيف' }, { k: 'd', l: 'التاريخ', t: 'date' }, { k: 'cur', l: 'العملة', t: 'select', opts: curOpts() }, { k: 'a', l: 'المبلغ', t: 'money', dec: () => decOf($('#f_cur').value), req: 1 }, { k: 'm', l: 'يُدفع من', t: 'select', opts: METHODS }], values: { d: today(), cur: baseCode() },
  submit: async o => { AQ.en.addExpense({ req: AQ.en.uid(), n: o.n, cat: o.cat, a: o.a, cur: o.cur, method: o.m, date: o.d, user: AQ.me }); toast('تم تسجيل المصروف', 'ok'); render(); }
});
ACT.expVoid = d => form({ title: 'إلغاء المصروف', msg: 'لا يُحذف المصروف؛ يُعلَّم ملغى ويُعاد مبلغه إلى الصندوق بقيد عكسي.', fields: [{ k: 'reason', l: 'السبب', req: 1, full: 1 }], ok: 'إلغاء المصروف', submit: async o => { AQ.en.voidExpense(d.id, { reason: o.reason, user: AQ.me }); toast('تم الإلغاء', 'ok'); render(); } });
const cashForm = out => form({
  title: out ? 'سحب من الصندوق' : 'إيداع في الصندوق', fields: [{ k: 'cur', l: 'العملة', t: 'select', opts: curOpts() }, { k: 'a', l: 'المبلغ', t: 'money', dec: () => decOf($('#f_cur').value), req: 1 }, { k: 'm', l: 'الطريقة', t: 'select', opts: METHODS }, { k: 'd', l: 'التاريخ', t: 'date' }, { k: 'note', l: 'البيان', req: 1, full: 1 }], values: { d: today(), cur: baseCode() },
  submit: async o => { AQ.en.cashMove({ cur: o.cur, amt: out ? -o.a : o.a, method: o.m, note: o.note, date: o.d, user: AQ.me }); toast('تم التسجيل', 'ok'); render(); }
});
ACT.cashIn = () => cashForm(false);
ACT.cashOut = () => cashForm(true);

/* ================= جلسة العملات ================= */
PAGES.fx = () => {
  const s = S();
  return `<h2 class=pt>جلسة العملات وأسعار الصرف</h2><div class=cd><div class=tb style="justify-content:flex-end">${newBtn('curAdd', '+ عملة', 'fx')}</div>
  <p class=mu style="margin-top:0">سعر الصرف = كم ${esc(baseCode())} تساوي وحدة واحدة من العملة. تغيير السعر لا يغيّر المعاملات القديمة؛ كل معاملة تحفظ السعر الذي تمت به.</p>
  ${tbl(['الرمز', 'الاسم', 'الرمز المعروض', 'المنازل العشرية', 'السعر (مقابل ' + esc(baseCode()) + ')', ''], s.set.cur.map(c => [esc(c.code) + (c.code === baseCode() ? ' ' + chip('أساسية', 'ok') : ''), esc(c.name), esc(c.sym), c.dec, c.code === baseCode() ? '1' : LTR(Money.fmtRate(c.rate)), c.code !== baseCode() && can('fx') ? btn('curRate', 'تغيير السعر', { c: c.code }) : '']))}</div>`;
};
ACT.curAdd = () => form({ title: 'إضافة عملة', fields: [{ k: 'code', l: 'الرمز (مثل EUR)', req: 1 }, { k: 'name', l: 'الاسم', req: 1 }, { k: 'sym', l: 'الرمز المعروض' }, { k: 'dec', l: 'المنازل العشرية', t: 'select', opts: [['2', '2'], ['0', '0'], ['1', '1'], ['3', '3']] }, { k: 'rate', l: 'سعر الصرف مقابل ' + baseCode(), t: 'rate', req: 1, full: 1 }], submit: async o => { AQ.en.addCurrency({ code: o.code, name: o.name, sym: o.sym || o.code, dec: +o.dec, rate: o.rate, user: AQ.me }); render(); } });
ACT.curRate = d => form({ title: 'سعر صرف ' + esc(d.c), fields: [{ k: 'rate', l: 'السعر الجديد', t: 'rate', req: 1, full: 1 }], values: { rate: Money.fmtRate(cdef(d.c).rate) }, submit: async o => { AQ.en.setRate(d.c, o.rate, AQ.me); toast('تم تحديث السعر', 'ok'); render(); } });

/* ================= التقارير ================= */
PAGES.reports = () => {
  const sub = curSub('reports', 'period'), tabs = tabsHTML([['period', 'يومي / شهري'], ['inv', 'الفواتير'], ['pl', 'الأرباح والخسائر'], ['stmt', 'كشوف الحساب'], ['aging', 'أعمار الديون'], ['rec', 'المطابقة'], ['audit', 'سجل التدقيق']], sub);
  return `<h2 class=pt>التقارير</h2>${tabs}${sub === 'period' ? repPeriod() : sub === 'inv' ? repInv() : sub === 'pl' ? repPL() : sub === 'stmt' ? repStmt() : sub === 'aging' ? repAging() : sub === 'rec' ? repRec() : repAudit()}`;
};
const dateFilter = (key, extra) => `<div class=tb><label>من<input type=date data-c=${key}from value="${FLT[key].from}"></label><label>إلى<input type=date data-c=${key}to value="${FLT[key].to}"></label>${extra || ''}</div>`;
CHG.rpfrom = v => { FLT.rp.from = v; render(); }; CHG.rpto = v => { FLT.rp.to = v; render(); }; CHG.rpby = v => { FLT.rp.by = v; render(); };
CHG.plfrom = v => { FLT.pl.from = v; render(); }; CHG.plto = v => { FLT.pl.to = v; render(); };
function repPeriod() {
  const f = FLT.rp, rows = Engine.periodReport(S(), { from: f.from, to: f.to }, f.by);
  const t = rows.reduce((a, r) => ({ invoices: a.invoices + r.invoices, sales: a.sales + r.sales, cost: a.cost + r.cost, profit: a.profit + r.profit, expenses: a.expenses + r.expenses, net: a.net + r.net, collected: a.collected + r.collected }), { invoices: 0, sales: 0, cost: 0, profit: 0, expenses: 0, net: 0, collected: 0 });
  const line = r => [r.k || '<b>الإجمالي</b>', r.invoices, fm(r.sales), fm(r.cost), fm(r.profit), fm(r.expenses), `<b>${fm(r.net)}</b>`, fm(r.collected)];
  return `<div class=cd>${dateFilter('rp', `<label>التجميع<select data-c=rpby><option value=day${f.by === 'day' ? ' selected' : ''}>يومي</option><option value=month${f.by === 'month' ? ' selected' : ''}>شهري</option></select></label>`)}<p class=mu style="margin-top:0"><button class=g2 data-a=xlPeriod style="float:left">📥 تصدير Excel</button>بالعملة الأساسية (${esc(baseCode())}). المبيعات بعد المرتجعات. المحصّل = المبيعات النقدية والتحصيلات.</p>${tbl(['الفترة', 'الفواتير', 'المبيعات', 'تكلفة البضاعة', 'مجمل الربح', 'المصاريف', 'الصافي', 'المحصّل'], rows.map(line).concat(rows.length ? [line(t)] : []))}</div>`;
}
function repPL() {
  const f = FLT.pl, p = Engine.profitLoss(S(), { from: f.from, to: f.to });
  const r = (l, v, b) => [b ? `<b>${l}</b>` : l, b ? `<b>${fm(v)}</b>` : fm(v)];
  return `<div class=cd>${dateFilter('pl')}${tbl(['البند', `المبلغ (${esc(baseCode())})`], [r('صافي المبيعات (بعد الخصم والمرتجعات)', p.revenue), r('تكلفة البضاعة المباعة', -p.cogs), r('مجمل الربح', p.gross, 1), r('المصاريف', -p.expenses), r('صافي الربح', p.net, 1)])}<p class=mu>عدد الفواتير: ${p.invoices} — ضريبة المبيعات: ${fm(p.taxOut)} — ضريبة المشتريات: ${fm(p.taxIn)} — إجمالي المبيعات شاملًا الضريبة: ${fm(p.salesTotal)}</p></div>`;
}
function repStmt() {
  const s = S(), f = FLT.st, list = f.k === 'cust' ? s.cust : s.sup;
  let body = '<p class=mu>اختر عميلًا أو موردًا.</p>';
  if (f.id && list.some(x => x.id === f.id)) {
    const r = Engine.statement(s, f.k, f.id);
    body = tbl(['التاريخ', 'البيان', 'المرجع', 'مدين', 'دائن', 'الرصيد'], r.rows.map(x => [x.date, x.type, esc(x.ref), x.d ? fm(x.d, x.cur) : '', x.c ? fm(x.c, x.cur) : '', fm(x.bal, x.cur)])) + `<p>الرصيد الحالي: ${fmBal(r.balances)}</p><button class=btn data-a=stmtPrint data-k="${f.k}" data-id="${esc(f.id)}">🖨 طباعة</button>`;
  }
  return `<div class=cd><div class=tb><label>النوع<select data-c=stk><option value=cust${f.k === 'cust' ? ' selected' : ''}>عميل</option><option value=sup${f.k === 'sup' ? ' selected' : ''}>مورد</option></select></label><label>الاسم<select data-c=stid><option value="">—</option>${list.map(x => `<option value="${esc(x.id)}"${f.id === x.id ? ' selected' : ''}>${esc(x.n)}</option>`).join('')}</select></label></div>${body}</div>`;
}
CHG.stk = v => { FLT.st.k = v; FLT.st.id = ''; render(); }; CHG.stid = v => { FLT.st.id = v; render(); };
function repRec() {
  const s = S(), list = Engine.reconcileList(s), p = Engine.profitLoss(s, {});
  const extra = [
    { name: 'صافي المبيعات + الضريبة = إجمالي المبيعات', expected: p.salesTotal, actual: p.revenue + p.taxOut },
    { name: 'صافي الربح = المبيعات − التكلفة − المصاريف', expected: p.revenue - p.cogs - p.expenses, actual: p.net }
  ].map(c => Object.assign(c, { money: true, ok: c.expected === c.actual }));
  const all = list.concat(extra), okAll = all.every(c => c.ok);
  const show = (v, c) => (typeof v === 'number' ? (c.money || c.name.indexOf('رصيد الصندوق') === 0 ? Money.fmt(v, decOf(baseCode())) : String(v)) : typeof v === 'boolean' ? (v ? 'نعم' : 'لا') : esc(String(v)));
  return `<div class=cd><h3>نتيجة المطابقة ${okAll ? chip('كل الفحوص ناجحة ✓', 'ok') : chip('يوجد اختلاف — لا تعتمد الأرقام قبل مراجعته', 'bd')}</h3><p class=mu style="margin-top:0">تُقارَن فيها الأرصدة والإجماليات مع الحركات التفصيلية المسجلة. لا يُعدّ أي رقم صحيحًا إلا إذا نجح الفحص.</p>${tbl(['الفحص', 'المتوقع', 'الفعلي', 'النتيجة'], all.map(c => [esc(c.name) + (c.detail ? `<br><small class=mu>${esc(c.detail)}</small>` : ''), `<span class=num>${show(c.expected, c)}</span>`, `<span class=num>${show(c.actual, c)}</span>`, c.ok ? chip('✓ مطابق', 'ok') : chip('✗ اختلاف', 'bd')]))}</div>
  ${s.mig ? `<div class=cd><h3>تقرير الترحيل من النسخة القديمة</h3><p>تاريخ الترحيل: ${fdt(s.mig.at)} — ${s.mig.report.inv} فاتورة، ${s.mig.report.products} منتج، ${s.mig.report.customers} عميل. فواتير تغيّر إجماليها: <b>${s.mig.report.changed.length}</b></p>${s.mig.report.changed.length ? tbl(['الفاتورة', 'القديم', 'الجديد'], s.mig.report.changed.slice(0, 100).map(c => [esc(c.no), fm(c.old), fm(c.now)])) : ''}</div>` : ''}`;
}
function repAudit() {
  const s = S(), a = s.audit.slice().reverse(), ok = Engine.auditOk(s);
  return `<div class=cd><h3>سجل التدقيق ${ok ? chip('السلسلة سليمة ✓', 'ok') : chip('تم العبث بالسجل!', 'bd')}</h3><p class=mu style="margin-top:0">يُسجَّل كل تغيير مالي أو إداري ولا يُحذف. كل سطر مرتبط بالذي قبله بتجزئة للكشف عن أي تعديل.</p>${tbl(['#', 'الوقت', 'المستخدم', 'العملية', 'التفاصيل'], lim(a, 300).map(r => [r.n, fdt(r.ts), userName(r.by), esc(r.a), esc(r.s)]))}${notice(300, a.length)}</div>`;
}

/* ================= المستخدمون ================= */
PAGES.users = () => {
  const s = S();
  return `<h2 class=pt>إدارة المستخدمين</h2><div class=cd><div class=tb style="justify-content:flex-end">${newBtn('userAdd', '+ مستخدم', 'users')}</div>${tbl(['الاسم', 'اسم الدخول', 'الدور', 'أقصى خصم', 'الحالة', ''], s.users.map(u => [esc(u.name), `<bdi>${esc(u.user)}</bdi>`, esc((Engine.ROLES[u.role] || {}).name || u.role), Money.fmtPct(u.maxDisc) + '%', u.active ? chip('فعّال', 'ok') : chip('معطّل', 'mu'), btn('userEdit', 'تعديل', { id: u.id }) + btn('userPw', 'كلمة السر', { id: u.id })]))}<p class=mu style="font-size:12px">الكاشير: بيع وتحصيل فقط بخصم محدود. المحاسب: كل شيء عدا المستخدمين والإعدادات. المدير: كل الصلاحيات.</p></div>`;
};
const permFields = perms => Object.entries(Engine.PERMS).map(([k, l]) => ({ k: 'p_' + k, l, t: 'check' }));
const readPerms = o => Object.keys(Engine.PERMS).filter(k => o['p_' + k]);
function roleSync() { const r = $('#f_role'); if (!r) return; r.onchange = () => { const ps = Engine.ROLES[r.value].perms; Object.keys(Engine.PERMS).forEach(k => { const c = $('#f_p_' + k); if (c) c.checked = ps.includes(k); }); const md = $('#f_maxd'); if (md) md.value = Money.fmtPct(Engine.ROLES[r.value].maxDisc); }; }
const roleOpts = () => Object.entries(Engine.ROLES).map(([k, v]) => [k, v.name]);
ACT.userAdd = () => {
  form({ title: 'إضافة مستخدم', size: 'mid', fields: [{ k: 'name', l: 'الاسم', req: 1 }, { k: 'user', l: 'اسم الدخول (إنجليزي)', req: 1 }, { k: 'pw', l: 'كلمة السر', t: 'password', req: 1 }, { k: 'role', l: 'الدور', t: 'select', opts: roleOpts() }, { k: 'maxd', l: 'أقصى خصم مسموح %', t: 'pct' }, ...permFields()],
    values: Object.assign({ role: 'cashier', maxd: Money.fmtPct(Engine.ROLES.cashier.maxDisc) }, Object.fromEntries(Engine.ROLES.cashier.perms.map(p => ['p_' + p, true]))),
    submit: async o => { await AQ.en.addUser({ user: o.user, pw: o.pw, name: o.name, role: o.role, perms: readPerms(o), maxDisc: o.maxd, by: AQ.me }); toast('تمت إضافة المستخدم', 'ok'); render(); } });
  roleSync();
};
ACT.userEdit = d => {
  const u = S().users.find(x => x.id === d.id);
  form({ title: 'تعديل المستخدم ' + esc(u.user), size: 'mid', fields: [{ k: 'name', l: 'الاسم', req: 1 }, { k: 'role', l: 'الدور', t: 'select', opts: roleOpts() }, { k: 'maxd', l: 'أقصى خصم مسموح %', t: 'pct' }, { k: 'active', l: 'الحساب فعّال', t: 'check' }, ...permFields()],
    values: Object.assign({ name: u.name, role: u.role, maxd: Money.fmtPct(u.maxDisc), active: u.active }, Object.fromEntries(u.perms.map(p => ['p_' + p, true]))),
    submit: async o => { AQ.en.updateUser(u.id, { name: o.name, role: o.role, perms: readPerms(o), maxDisc: o.maxd, active: o.active, by: AQ.me }); toast('تم الحفظ', 'ok'); render(); } });
  roleSync();
};
ACT.userPw = d => form({ title: 'تعيين كلمة سر جديدة', fields: [{ k: 'pw', l: 'كلمة السر الجديدة', t: 'password', req: 1, full: 1 }], submit: async o => { await AQ.en.resetPassword(d.id, o.pw, AQ.me); toast('تم تغيير كلمة السر', 'ok'); } });

/* ================= الإعدادات ================= */
PAGES.settings = () => {
  const s = S(), co = s.co, st = s.set, yn = v => (v ? 'نعم' : 'لا');
  return `<h2 class=pt>الإعدادات</h2>
  ${can('set') ? `<div class=cd><h3>بيانات الشركة</h3>${tbl(['البند', 'القيمة'], [['الاسم', esc(co.n)], ['الهاتف', esc(co.ph)], ['العنوان', esc(co.ad)], ['الرقم الضريبي', esc(co.tx)]])}<div class=ac><button class=btn data-a=setCo>تعديل</button></div></div>
  <div class=cd><h3>خيارات النظام</h3>${tbl(['البند', 'القيمة'], [['نسبة الضريبة الافتراضية للمبيعات', Money.fmtPct(st.taxBp) + '%'], ['السماح بالبيع بما يتجاوز المخزون', yn(st.negStock)], ['السماح بالبيع الآجل لعميل نقدي', yn(st.cashDebt)], ['مقاس طباعة الفاتورة', 'A5'], ['نص أسفل الإيصال', esc(st.rfoot)], ['العملة الأساسية', esc(st.base)]])}<div class=ac><button class=btn data-a=setOpt>تعديل</button></div></div>` : ''}
  <div class=cd><h3>حسابي</h3><button class=g2 data-a=chpw>تغيير كلمة السر</button></div>
  ${importCard()}
  ${backupCard()}
  <div class=cd><h3>عن البرنامج</h3><p class=mu style="margin:0">العقرب الحسابي — النظام المحاسبي المتكامل. كل المبالغ تُحسب بأعداد صحيحة بأصغر وحدة للعملة (بدون أعداد عشرية عائمة).</p></div>`;
};

/* ---- استيراد من برنامج آخر (البرهان) ---- */
function importCard() {
  if (!can('set')) return '';
  const done = (S().imports || []).map(x => `<li>${esc(x.source)} — ${x.counts.inv} فاتورة، ${x.counts.cust} عميل، ${x.counts.prod} منتج (${esc(String(x.at).slice(0, 10))})</li>`).join('');
  return `<div class=cd><h3>استيراد بيانات من برنامج آخر</h3>
<p class=mu style="margin-top:0">لنقل قاعدة بيانات «البرهان»: حوّل نسخة .db إلى ملف حزمة (brhan-import.json) ثم اخترها هنا. تظهر معاينة بالأعداد والمجاميع قبل الاعتماد، وتُحفظ نسخة أمان تلقائيًا، ولا يُحذف أي شيء من بياناتك الحالية.</p>
${done ? `<ul class=mu>${done}</ul>` : ''}<div class=ac><button class=btn data-a=impPick>📥 اختيار ملف الحزمة…</button></div></div>`;
}
ACT.impPick = async () => {
  if (!window.aq || !aq.importPick) { toast('الاستيراد متاح في نسخة سطح المكتب فقط', 'er'); return; }
  const r = await aq.importPick(); if (r.canceled) return; if (!r.ok) { toast(r.error, 'er'); return; }
  if (r.pkg.kind === 'barcodes') {
    return ask('استيراد الباركودات من ' + esc(r.pkg.source || ''), `سيتم تعيين ${r.pkg.items.length} باركود (بحروفها وأرقامها كما هي) لمنتجات مستوردة لا باركود لها. لا يُستبدل أي باركود موجود. (الملف: ${esc(r.file)})`, async () => {
      const b = await aq.backup('pre-import'); if (!b.ok && !b.empty) throw new Error('لم يتم الاستيراد لأن نسخة الأمان فشلت: ' + b.error);
      const rep = AQ.en.importBarcodes(r.pkg, { user: AQ.me }); toast('تم تعيين ' + rep.n + ' باركود', 'ok'); render();
    }, 'اعتماد');
  }
  const pkg = r.pkg, ex = pkg.expect || {}, s = S(), dec = Engine_dec();
  const f = v => Money.fmt(v, dec);
  const warn = (s.inv.length || s.prod.length || s.cust.length) ? `<p class=bd>تنبيه: يوجد بيانات حالية (${s.inv.length} فاتورة، ${s.prod.length} منتج، ${s.cust.length} عميل). ستُضاف بيانات الحزمة إلى الموجود ولن تُستبدل.</p>` : '';
  form({ title: 'معاينة الاستيراد من ' + esc(pkg.source || ''), size: 'mid', ok: 'اعتماد الاستيراد', fields: [],
    html: `${tbl(['البند', 'العدد / القيمة'], [['الفواتير', pkg.inv.length], ['العملاء', pkg.cust.length], ['المنتجات', pkg.prod.length], ['القيود النقدية', pkg.cash.length], ['صافي المبيعات', f(ex.net_total || 0) + ' ' + pkg.base], ['المدفوع', f(ex.paid_total || 0) + ' ' + pkg.base]])}${warn}<p class=mu>الملف: ${esc(r.file)}</p>`,
    submit: async () => {
      const b = await aq.backup('pre-import'); if (!b.ok && !b.empty) return 'لم يتم الاستيراد لأن نسخة الأمان فشلت: ' + b.error;
      const rep = AQ.en.importPackage(pkg, { user: AQ.me });
      setTimeout(() => info('تم الاستيراد', `<p>تم استيراد ${rep.inv} فاتورة و${rep.cust} عميل و${rep.prod} منتج و${rep.cash} قيد نقدي، وطابقت الأرقام الأرقام المتوقعة في الحزمة.</p>${rep.bcBlanked.length ? `<p class=mu>باركودات تُركت فارغة: ${rep.bcBlanked.length}</p>` : ''}<p class=mu>نسخة الأمان قبل الاستيراد محفوظة في قائمة النسخ.</p>`), 50);
      render();
    } });
};
const Engine_dec = () => { try { return Engine.decOf(S(), S().set.base); } catch (e) { return 2; } };
ACT.chpw = () => changePw();
ACT.setCo = () => form({ title: 'بيانات الشركة', fields: [{ k: 'n', l: 'الاسم', req: 1, full: 1 }, { k: 'ph', l: 'الهاتف' }, { k: 'tx', l: 'الرقم الضريبي' }, { k: 'ad', l: 'العنوان', full: 1 }], values: S().co, submit: async o => { AQ.en.setCompany(Object.assign({ user: AQ.me }, o)); render(); } });
ACT.setOpt = () => form({ title: 'خيارات النظام', fields: [{ k: 'tax', l: 'نسبة الضريبة الافتراضية % (للفواتير الجديدة)', t: 'pct', full: 1 }, { k: 'neg', l: 'السماح بالبيع بما يتجاوز المخزون', t: 'check', full: 1 }, { k: 'debt', l: 'السماح بالبيع الآجل لعميل نقدي (غير مسجَّل)', t: 'check', full: 1 }, { k: 'rcpt', l: 'نوع الطباعة الافتراضي', t: 'select', opts: [['80', 'إيصال 80 مم'], ['A4', 'فاتورة A4']], full: 1 }, { k: 'foot', l: 'نص أسفل الإيصال والفاتورة', full: 1 }, { k: 'logo', l: 'شعار المتجر لفاتورة A4 (صورة PNG أو JPG — اختياري)', t: 'file', max: 300, full: 1 }, { k: 'nologo', l: 'حذف الشعار الحالي', t: 'check', full: 1 }, { k: 'terms', l: 'ملاحظات وشروط أسفل فاتورة A4 (مثال: البضاعة المباعة لا تُسترد بعد 7 أيام)', t: 'textarea', rows: 3, full: 1 }],
  values: { tax: Money.fmtPct(S().set.taxBp), neg: S().set.negStock, debt: S().set.cashDebt, rcpt: S().set.rcpt, foot: S().set.rfoot, terms: S().set.terms || '' },
  submit: async o => { AQ.en.setOptions({ taxBp: o.tax, negStock: o.neg, cashDebt: o.debt, rcpt: o.rcpt, rfoot: o.foot, terms: o.terms, logo: o.nologo ? '' : (o.logo || undefined), user: AQ.me }); render(); } });
