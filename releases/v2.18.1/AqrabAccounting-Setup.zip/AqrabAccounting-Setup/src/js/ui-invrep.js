/* ui-invrep.js — تقرير الفواتير (كل فاتورة بسطر مستقل) + نافذة تفاصيل الفاتورة. عرض فقط، لا يغيّر أي بيانات. */
'use strict';
FLT.ri = { q: '', from: '', to: '', st: '', c: '' };
const riDigits = v => String(v || '').replace(/\D/g, '');
/* مطابقة رقم الفاتورة: نص جزئي (inv-0012) أو رقم فقط (12 أو 0012) */
/* بحث برقم فقط (مثل 12): إن وُجدت فاتورة بهذا الرقم تمامًا تُعرض وحدها، وإلا تُعرض المطابقات الجزئية */
function exactNo(arr, q, noOf) {
  q = String(q || '').trim(); if (!/^\d+$/.test(q)) return arr;
  const n = parseInt(q, 10), ex = arr.filter(x => parseInt(String(noOf(x)).replace(/\D/g, ''), 10) === n && /^\D*\d+$/.test(String(noOf(x))));
  return ex.length ? ex : arr;
}
function riMatch(i, q) {
  q = q.trim().toLowerCase(); if (!q) return true;
  const no = i.no.toLowerCase(), d = riDigits(q);
  if (no.includes(q)) return true;
  if (nrm(i.cn).includes(nrm(q))) return true; // اسم العميل
  return /^\d+$/.test(q) && parseInt(riDigits(i.no), 10) === parseInt(d, 10); // أرقام فقط: تطابق الرقم مع أي بادئة
}
function riList() {
  const s = S(), f = FLT.ri, pm = Engine.paidMap(s);
  const res = s.inv.slice().reverse().filter(i => riMatch(i, f.q) && (!f.from || i.date >= f.from) && (!f.to || i.date <= f.to) && (!f.c || i.c === f.c || (f.c === '_cash' && !i.c)))
    .map(i => ({ i, v: Engine.invView(s, i, pm) }))
    .filter(x => !f.st || (f.st === 'void' ? x.i.void : f.st === 'open' ? !x.i.void && x.v.due > 0 : f.st === 'paid' ? !x.i.void && x.v.due <= 0 : f.st === 'ret' ? !x.i.void && (x.i.rt || []).some(r => !r.void) : f.st === 'edited' ? (x.i.rev || []).length > 0 : true));
  return exactNo(res, f.q, x => x.i.no);
}
function repInv() {
  const s = S(), f = FLT.ri, all = riList(), pmCnt = all.filter(x => !x.i.void).length;
  const base = baseCode();
  const tot = all.filter(x => !x.i.void).reduce((a, x) => a + toB(x.v.c.totEff, x.i.cur, x.i.fx), 0);
  const rows = lim(all, 300).map(({ i, v }) => [`<b>${esc(i.no)}</b>${(i.rev || []).length ? ' ' + chip('معدّلة', 'mu') : ''}${(i.ex || []).length ? ' ' + chip('رسوم إضافية', 'mu') : ''}`, i.date, esc(i.cn), esc(i.cur), fm(v.c.totEff, i.cur), fm(v.paid, i.cur),
    v.due ? `<span class="${v.due > 0 ? 'bd' : 'ok'}">${fm(v.due, i.cur)}</span>` : fm(0, i.cur), invStatus(i, v),
    btn('invDetail', 'تفاصيل', { id: i.id }) + btn('print', 'طباعة A5', { id: i.id })]);
  return `<div class=cd><div class=tb>
  <label>بحث برقم الفاتورة<input data-c=riq value="${esc(f.q)}" placeholder="مثال: INV-0012 أو 12" style="direction:ltr;text-align:right"></label>
  <label>من<input type=date data-c=rifrom value="${esc(f.from)}"></label><label>إلى<input type=date data-c=rito value="${esc(f.to)}"></label>
  <label>العميل<select data-c=ric>${optsHTML([['_cash', 'عميل نقدي']].concat(s.cust.map(c => [c.id, c.n])), f.c, 'الكل')}</select></label>
  <label>الحالة<select data-c=rist><option value="">الكل</option>${[['open', 'غير مسددة'], ['paid', 'مسددة'], ['ret', 'لها مرتجعات'], ['edited', 'معدّلة'], ['void', 'ملغاة']].map(([k, l]) => `<option value=${k}${f.st === k ? ' selected' : ''}>${l}</option>`).join('')}</select></label>
  <button class=g2 data-a=riClear>مسح الفلاتر</button><button class=g2 data-a=xlInv>📥 تصدير Excel</button></div>
  <p class=mu style="margin-top:0">${all.length} فاتورة — الفواتير غير الملغاة: ${pmCnt} بإجمالي صافٍ ${fm(tot, base)} (${esc(base)}). اضغط «تفاصيل» لعرض كل فاتورة لوحدها.</p>
  ${tbl(['رقم الفاتورة', 'التاريخ', 'العميل', 'العملة', 'الإجمالي (بعد المرتجع)', 'المدفوع', 'المتبقي', 'الحالة', ''], rows)}${notice(300, all.length)}</div>`;
}
CHG.riq = v => { FLT.ri.q = v; render(); }; CHG.rifrom = v => { FLT.ri.from = v; render(); }; CHG.rito = v => { FLT.ri.to = v; render(); };
CHG.ric = v => { FLT.ri.c = v; render(); }; CHG.rist = v => { FLT.ri.st = v; render(); };
ACT.riClear = () => { FLT.ri = { q: '', from: '', to: '', st: '', c: '' }; render(); };

ACT.invDetail = d => {
  const s = S(), i = s.inv.find(x => x.id === d.id); if (!i) return toast('الفاتورة غير موجودة', 'err');
  const v = Engine.invView(s, i), c = v.c, cu = s.cust.find(x => x.id === i.c), cur = i.cur;
  const items = i.items.map((x, k) => [k + 1, esc(x.n), fq(x.q), fm(x.pr, cur), fm(c.lines[k].total, cur), c.lines[k].rq ? `<span class=bd>${fq(c.lines[k].rq)}</span>` : '']);
  const pays = s.cash.filter(e => e.ref && e.ref.t === 'inv' && e.ref.id === i.id).map(e => [e.date, KINDL[e.kind] || esc(e.kind), METHOD_L[e.method] || esc(e.method || ''), `<span class="num ${e.amt < 0 ? 'bd' : 'ok'}">${fm(e.amt, e.cur)}</span>`, esc(e.note || '') + (e.kind === 'collect' || e.kind === 'sale' ? ' ' + btn('vchEntry', '🖨 سند', { id: e.id }) : '')]);
  const rets = (i.rt || []).map(r => [esc(r.no), r.date, r.lines.map(l => esc(i.items[l.k] ? i.items[l.k].n : '?') + ' × ' + fq(l.q)).join('، '), r.void ? chip('ملغى', 'mu') : chip('ساري', 'ok')]);
  const ex = i.ex || [], exSum = ex.reduce((a, e) => a + e.a, 0);
  const row = (l, val, cls) => `<tr class="${cls || ''}"><td>${l}</td><td class=num>${val}</td></tr>`;
  const state = i.void ? chip('ملغاة', 'mu') : invStatus(i, v);
  $('#md').innerHTML = `<div class=ov><div class="bx wide"><h3>${esc(i.no)} ${state}${(i.rev || []).length ? ' ' + chip('معدّلة ' + i.rev.length + ' مرة', 'mu') : ''}</h3>
  <div class=tb style="gap:6px 24px;flex-wrap:wrap"><span>التاريخ: <b>${esc(i.date)}</b></span><span>العميل: <b>${esc(i.cn)}</b>${cu && cu.ph ? ' — ' + esc(cu.ph) : ''}</span>${i.rn ? `<span>المندوب: <b>${esc(i.rn)}</b></span>` : ''}<span>العملة: <b>${esc(cur)}</b></span><span>بواسطة: <b>${userName(i.by)}</b></span></div>
  ${i.note ? `<p class=mu>ملاحظة: ${esc(i.note)}</p>` : ''}
  ${tbl(['#', 'البند', 'الكمية', 'السعر', 'الإجمالي', 'مرتجع'], items)}
  <table class=a4s style="max-width:380px;margin:10px 0 0 auto">${row('المجموع', fm(c.sub, cur))}${c.disc ? row('الخصم', fm(c.disc, cur)) : ''}${c.tax ? row('الضريبة (' + Money.fmtPct(i.rate) + '%)', fm(c.tax, cur)) : ''}${c.retGross ? row('المرتجعات', fm(c.retGross, cur)) : ''}${row('<b>الإجمالي</b>', '<b>' + fm(c.totEff, cur) + '</b>')}${row('المدفوع', fm(v.paid, cur))}${v.due ? row(v.due > 0 ? 'المتبقي' : 'رصيد للعميل', `<b class="${v.due > 0 ? 'bd' : 'ok'}">${fm(Math.abs(v.due), cur)}</b>`) : ''}</table>
  ${ex.length ? `<div class=cd style="margin-top:10px"><h4 style="margin:0 0 4px">رسوم إضافية (للطباعة فقط — غير داخلة في الإجمالي والأرباح)</h4>${tbl(['البيان', 'المبلغ'], ex.map(e => [esc(e.l), fm(e.a, cur)]).concat([['<b>المجموع</b>', '<b>' + fm(exSum, cur) + '</b>']]))}</div>` : ''}
  <h4 style="margin:12px 0 4px">الدفعات والتحصيل</h4>${pays.length ? tbl(['التاريخ', 'النوع', 'الطريقة', 'المبلغ', 'ملاحظة'], pays) : '<p class=mu style="margin:0">لا توجد دفعات مسجلة.</p>'}
  ${rets.length ? `<h4 style="margin:12px 0 4px">المرتجعات</h4>${tbl(['رقم المرتجع', 'التاريخ', 'البنود', 'الحالة'], rets)}` : ''}
  ${(i.rev || []).length ? `<h4 style="margin:12px 0 4px">سجل التعديلات</h4>${tbl(['الوقت', 'بواسطة', 'السبب', 'الإجمالي قبل ← بعد'], i.rev.map(r => [fdt(r.ts), userName(r.by), esc(r.reason || ''), fm(r.before.tot, cur) + ' ← ' + fm(r.after.tot, cur)]))}` : ''}
  <div class=ac><button class=btn data-a=print data-id="${esc(i.id)}">🖨 طباعة A5</button>${!i.void && can('invedit') ? `<button class=g2 data-a=invEdit data-id="${esc(i.id)}">تعديل</button>` : ''}<button class=g2 data-a=close>إغلاق</button></div></div></div>`;
};
