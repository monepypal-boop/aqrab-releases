/* ui-xlsx.js — تصدير إلى Excel (.xlsx حقيقي) بدون أي مكتبة خارجية ودون اتصال بالإنترنت.
 * يكتب ملف OOXML داخل حاوية ZIP (بلا ضغط) مع اتجاه يمين-لشمال، ورؤوس منسّقة، وأرقام حقيقية (وليست نصوصًا) قابلة للجمع. عرض فقط: لا يغيّر أي بيانات. */
'use strict';
const XL = (() => {
  const enc = new TextEncoder();
  const crcT = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = crcT[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
  const xe = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  function colName(i) { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; }
  /* خلية: نص | رقم | { v:number, f:'n2'|'n3'|'i' } ; f يحدد تنسيق العرض */
  const FMT = { n2: 2, n3: 3, i: 4 }; // فهارس cellXfs
  function cellXml(c, r, ci, head) {
    const ref = colName(ci) + r;
    if (c === null || c === undefined || c === '') return '';
    if (head) return `<c r="${ref}" s="1" t="inlineStr"><is><t xml:space="preserve">${xe(c)}</t></is></c>`;
    if (typeof c === 'number' && Number.isFinite(c)) return `<c r="${ref}" s="${FMT.n2}"><v>${c}</v></c>`;
    if (c && typeof c === 'object' && Number.isFinite(c.v)) return `<c r="${ref}" s="${FMT[c.f] || 2}"><v>${c.v}</v></c>`;
    return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${xe(c && typeof c === 'object' ? (c.t || '') : c)}</t></is></c>`;
  }
  const len = c => (c && typeof c === 'object' ? String(c.v ?? c.t ?? '') : String(c ?? '')).length;
  function sheetXml(sh) {
    const rows = [sh.head].concat(sh.rows), widths = sh.head.map((h, i) => Math.min(48, Math.max(8, ...rows.map(r => len(r[i]) + 2))));
    const data = rows.map((r, ri) => `<row r="${ri + 1}">${r.map((c, ci) => cellXml(c, ri + 1, ci, ri === 0)).join('')}</row>`).join('');
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="16"/><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${data}</sheetData>${rows.length > 1 ? `<autoFilter ref="A1:${colName(sh.head.length - 1)}${rows.length}"/>` : ''}</worksheet>`;
  }
  const STYLES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0.00"/><numFmt numFmtId="165" formatCode="#,##0.000"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF0F1F3D"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="1" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  // FMT: n2→index 2 (#,##0.00)، n3→3، i→4
  FMT.n2 = 2; FMT.n3 = 3; FMT.i = 4;
  function zip(files) { // ZIP بطريقة التخزين (بدون ضغط)
    const parts = [], cen = []; let off = 0;
    const u16 = v => [v & 255, (v >> 8) & 255], u32 = v => [v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255];
    files.forEach(f => {
      const nm = enc.encode(f.name), data = enc.encode(f.text), crc = crc32(data);
      const lh = new Uint8Array([0x50, 0x4b, 3, 4, ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nm.length), ...u16(0)]);
      parts.push(lh, nm, data);
      cen.push(new Uint8Array([0x50, 0x4b, 1, 2, ...u16(20), ...u16(20), ...u16(0x0800), ...u16(0), ...u16(0), ...u16(0x21), ...u32(crc), ...u32(data.length), ...u32(data.length), ...u16(nm.length), ...u16(0), ...u16(0), ...u16(0), ...u16(0), ...u32(0), ...u32(off)]), nm);
      off += lh.length + nm.length + data.length;
    });
    const cdSize = cen.reduce((a, b) => a + b.length, 0);
    const end = new Uint8Array([0x50, 0x4b, 5, 6, ...u16(0), ...u16(0), ...u16(files.length), ...u16(files.length), ...u32(cdSize), ...u32(off), ...u16(0)]);
    const all = [...parts, ...cen, end], out = new Uint8Array(all.reduce((a, b) => a + b.length, 0)); let p = 0; all.forEach(b => { out.set(b, p); p += b.length; });
    return out;
  }
  const safeName = (n, i) => (String(n).replace(/[\[\]:*?\/\\]/g, ' ').trim().slice(0, 31) || 'ورقة' + (i + 1));
  function build(sheets) {
    const names = sheets.map((s, i) => safeName(s.name, i));
    const files = [
      { name: '[Content_Types].xml', text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((s, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>` },
      { name: '_rels/.rels', text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
      { name: 'xl/workbook.xml', text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>${names.map((n, i) => `<sheet name="${xe(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>` },
      { name: 'xl/_rels/workbook.xml.rels', text: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((s, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
      { name: 'xl/styles.xml', text: STYLES }
    ].concat(sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, text: sheetXml(s) })));
    return zip(files);
  }
  function download(filename, sheets) {
    const bytes = build(sheets), blob = new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename; document.body.appendChild(a); a.click();
    setTimeout(() => { a.remove(); URL.revokeObjectURL(a.href); }, 3000);
    return bytes.length;
  }
  return { build, download, crc32 };
})();

/* ---- أدوات تحويل الأرقام المالية إلى أرقام حقيقية (بالمنازل العشرية الصحيحة، بدون أخطاء الفاصلة العائمة) ---- */
const xN = (v, dec) => ({ v: Number(Money.fmt(v, dec == null ? decOf(baseCode()) : dec, { nogroup: true })), f: dec === 3 ? 'n3' : 'n2' });
const xQ = q => ({ v: Number(Money.fmt(q, 3, { nogroup: true })), f: 'n3' });
const xName = base => base + '_' + AQ.en.today() + '.xlsx';
function xlDo(name, sheets) {
  try { XL.download(xName(name), sheets); toast('تم إنشاء ملف Excel — اختر مكان الحفظ إن طُلب منك', 'ok'); } catch (e) { toast('تعذّر إنشاء الملف: ' + e.message, 'err'); }
}
const xlBtn = a => `<button class=g2 data-a=${a}>📥 تصدير Excel</button>`;

ACT.xlInv = () => {
  const s = S(), all = riList(), base = baseCode();
  const st = (i, v) => (i.void ? 'ملغاة' : v.due < 0 ? 'رصيد للعميل' : v.due === 0 ? 'مدفوعة' : v.paid > 0 ? 'جزئي' : 'غير مدفوعة');
  const head = ['رقم الفاتورة', 'التاريخ', 'العميل', 'العملة', 'الإجمالي (بعد المرتجع)', 'المدفوع', 'المتبقي', 'الحالة', 'عدد التعديلات', 'رسوم إضافية (للطباعة فقط)'];
  const rows = all.map(({ i, v }) => [i.no, i.date, i.cn, i.cur, xN(v.c.totEff, decOf(i.cur)), xN(v.paid, decOf(i.cur)), xN(v.due, decOf(i.cur)), st(i, v), (i.rev || []).length || '', (i.ex || []).length ? (i.ex || []).map(e => e.l + ' ' + Money.fmt(e.a, decOf(i.cur), { nogroup: true })).join('، ') : '']);
  const lines = []; all.forEach(({ i, v }) => i.items.forEach((x, k) => lines.push([i.no, i.date, i.cn, x.n, xQ(x.q), xN(x.pr, decOf(i.cur)), xN(v.c.lines[k].total, decOf(i.cur)), i.cur, v.c.lines[k].rq ? xQ(v.c.lines[k].rq) : ''])));
  xlDo('فواتير', [{ name: 'الفواتير', head, rows }, { name: 'بنود الفواتير', head: ['رقم الفاتورة', 'التاريخ', 'العميل', 'البند', 'الكمية', 'السعر', 'إجمالي البند', 'العملة', 'الكمية المرتجعة'], rows: lines }]);
};
ACT.xlPeriod = () => {
  const f = FLT.rp, rows = Engine.periodReport(S(), { from: f.from, to: f.to }, f.by), b = baseCode();
  const t = rows.reduce((a, r) => ({ invoices: a.invoices + r.invoices, sales: a.sales + r.sales, cost: a.cost + r.cost, profit: a.profit + r.profit, expenses: a.expenses + r.expenses, net: a.net + r.net, collected: a.collected + r.collected }), { invoices: 0, sales: 0, cost: 0, profit: 0, expenses: 0, net: 0, collected: 0 });
  const line = (k, r) => [k, r.invoices, xN(r.sales), xN(r.cost), xN(r.profit), xN(r.expenses), xN(r.net), xN(r.collected)];
  xlDo(f.by === 'month' ? 'تقرير_شهري' : 'تقرير_يومي', [{ name: 'التقرير (' + b + ')', head: ['الفترة', 'الفواتير', 'المبيعات', 'تكلفة البضاعة', 'مجمل الربح', 'المصاريف', 'الصافي', 'المحصّل'], rows: rows.map(r => line(r.k, r)).concat(rows.length ? [line('الإجمالي', t)] : []) }]);
};
ACT.xlStock = () => {
  const r = Engine.stockReport(S());
  xlDo('تقرير_المخزون', [{ name: 'المخزون', head: ['المنتج', 'الباركود', 'الكمية', 'التكلفة', 'سعر البيع', 'قيمة المخزون', 'الحالة'], rows: r.map(x => [x.n, x.bc || '', xQ(x.q), xN(x.co), xN(x.pr), xN(x.value), x.low ? 'منخفض' : '']).concat([['الإجمالي', '', '', '', '', xN(r.reduce((a, x) => a + x.value, 0)), '']]) }]);
};
ACT.xlProd = () => {
  const s = S(), q = FLT.prod.q.trim().toLowerCase();
  const list = s.prod.filter(p => !p.arch && (!q || [p.n, p.bc, p.model, p.brand, p.cat].some(x => String(x || '').toLowerCase().includes(q))));
  xlDo('المنتجات', [{ name: 'المنتجات', head: ['المنتج', 'الصنف', 'الماركة', 'الموديل', 'الباركود', 'سعر البيع', 'التكلفة', 'الكمية', 'حد التنبيه'], rows: list.map(p => [p.n, p.cat || '', p.brand || '', p.model || '', p.bc || '', xN(p.pr), xN(p.co), xQ(p.q), xQ(p.mn || 0)]) }]);
};
