/* ai-mascot.js — شخصية «العقرب الذكي»: رسم متجه (SVG) مع حالات حركة بـ CSS (بدون محرك ثلاثي الأبعاد) */
'use strict';
(function (root) {
  const STATES = { idle: 'جاهز', listening: 'أستمع إليك', thinking: 'أفكّر…', speaking: 'أتحدث', success: 'تم', warning: 'تنبيه', error: 'تعذّر التنفيذ' };
  let n = 0;
  function svg() {
    const id = 'm' + (++n);
    return `<svg class=aim viewBox="0 0 200 200" role=img aria-label="العقرب الذكي" xmlns="http://www.w3.org/2000/svg">
<defs>
<linearGradient id=${id}a x1=0 y1=0 x2=0 y2=1><stop offset=0 stop-color="#eef3fb"/><stop offset=.45 stop-color="#aeb9cc"/><stop offset=1 stop-color="#3a4357"/></linearGradient>
<linearGradient id=${id}b x1=0 y1=0 x2=1 y2=1><stop offset=0 stop-color="#6b7790"/><stop offset=1 stop-color="#171d2b"/></linearGradient>
<radialGradient id=${id}c cx=.35 cy=.3 r=.8><stop offset=0 stop-color="#f4f7fd"/><stop offset=.5 stop-color="#b9c3d6"/><stop offset=1 stop-color="#424b60"/></radialGradient>
<radialGradient id=${id}d cx=.5 cy=.5 r=.5><stop offset=0 stop-color="#7fd0ff"/><stop offset=1 stop-color="#1b6fe0"/></radialGradient>
<filter id=${id}g x=-50% y=-50% width=200% height=200%><feGaussianBlur stdDeviation=3 result=b /><feMerge><feMergeNode in=b /><feMergeNode in=SourceGraphic /></feMerge></filter>
</defs>
<ellipse class=sh cx=100 cy=186 rx=58 ry=7 fill="#000" opacity=.18 />
<g class=tail>
<path d="M118 142 C170 140 178 92 150 66 C140 56 128 52 122 44" fill=none stroke="url(#${id}b)" stroke-width=15 stroke-linecap=round />
<path d="M118 142 C170 140 178 92 150 66 C140 56 128 52 122 44" fill=none stroke="url(#${id}a)" stroke-width=9 stroke-linecap=round stroke-dasharray="14 4" />
<path class=sting d="M122 46 C112 40 108 28 114 20 C122 28 130 36 128 48 Z" fill="url(#${id}d)" filter="url(#${id}g)" />
</g>
<g class=legs stroke="#2b3347" stroke-width=5 stroke-linecap=round fill=none>
<path d="M72 150 L46 162 L38 176" /><path d="M78 160 L56 178 L50 190" /><path d="M128 150 L154 162 L162 176" /><path d="M122 160 L144 178 L150 190" />
</g>
<g class="claw cl">
<path d="M70 118 C48 112 34 98 34 84" fill=none stroke="url(#${id}b)" stroke-width=13 stroke-linecap=round />
<path d="M34 86 C14 80 14 54 30 48 C28 62 34 70 44 72 Z" fill="url(#${id}c)" stroke="#2b3347" stroke-width=2.5 />
<path d="M36 88 C20 96 18 112 30 118 C32 108 40 102 48 100 Z" fill="url(#${id}c)" stroke="#2b3347" stroke-width=2.5 />
</g>
<g class="claw cr">
<path d="M130 118 C152 112 166 98 166 84" fill=none stroke="url(#${id}b)" stroke-width=13 stroke-linecap=round />
<path d="M166 86 C186 80 186 54 170 48 C172 62 166 70 156 72 Z" fill="url(#${id}c)" stroke="#2b3347" stroke-width=2.5 />
<path d="M164 88 C180 96 182 112 170 118 C168 108 160 102 152 100 Z" fill="url(#${id}c)" stroke="#2b3347" stroke-width=2.5 />
</g>
<g class=body>
<ellipse cx=100 cy=138 rx=42 ry=34 fill="url(#${id}c)" stroke="#2b3347" stroke-width=3 />
<path d="M64 132 Q100 148 136 132 M68 148 Q100 162 132 148" fill=none stroke="#56617a" stroke-width=3 stroke-linecap=round />
<circle class=core cx=100 cy=140 r=7 fill="url(#${id}d)" filter="url(#${id}g)" />
<ellipse cx=100 cy=88 rx=40 ry=36 fill="url(#${id}c)" stroke="#2b3347" stroke-width=3 />
<path d="M70 72 Q100 52 130 72" fill=none stroke="#fff" stroke-width=4 opacity=.55 stroke-linecap=round />
<g class=eyes>
<ellipse cx=84 cy=88 rx=11 ry=13 fill="#fff" stroke="#2b3347" stroke-width=2 /><ellipse cx=116 cy=88 rx=11 ry=13 fill="#fff" stroke="#2b3347" stroke-width=2 />
<g class=pupils><circle cx=86 cy=90 r=6.5 fill="url(#${id}d)" /><circle cx=114 cy=90 r=6.5 fill="url(#${id}d)" /><circle cx=88 cy=87 r=2 fill="#fff" /><circle cx=116 cy=87 r=2 fill="#fff" /></g>
<g class=lids><rect x=72 y=74 width=24 height=0 fill="url(#${id}a)" /><rect x=104 y=74 width=24 height=0 fill="url(#${id}a)" /></g>
<g class=xeyes stroke="#e0352b" stroke-width=3 stroke-linecap=round><path d="M78 82 L90 94 M90 82 L78 94 M110 82 L122 94 M122 82 L110 94" /></g>
</g>
<path class=mouth d="M88 106 Q100 116 112 106" fill=none stroke="#2b3347" stroke-width=3.5 stroke-linecap=round />
<ellipse class=mouth2 cx=100 cy=110 rx=9 ry=0 fill="#2b3347" />
<g class=head-set>
<path d="M60 88 C58 54 82 40 100 40 C118 40 142 54 140 88" fill=none stroke="#1f2638" stroke-width=7 stroke-linecap=round />
<rect x=52 y=80 width=14 height=26 rx=7 fill="#1f2638" stroke="#3b82f6" stroke-width=2.5 /><rect x=134 y=80 width=14 height=26 rx=7 fill="#1f2638" stroke="#3b82f6" stroke-width=2.5 />
<path d="M59 106 C60 120 76 118 84 114" fill=none stroke="#1f2638" stroke-width=4 stroke-linecap=round /><circle class=mic cx=86 cy=114 r=5 fill="#3b82f6" filter="url(#${id}g)" />
</g>
</g>
<g class=zz><circle cx=60 cy=40 r=3 /><circle cx=72 cy=34 r=3 /><circle cx=84 cy=30 r=3 /></g>
</svg>`;
  }
  root.AIM = { svg, STATES };
})(window);
