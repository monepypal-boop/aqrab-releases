/* ui-lic.js — شاشة الترخيص (تفعيل بمفتاح، فترة تجريبية، قفل بعد الانتهاء) وبطاقة الإعدادات.
 * النسخة الشخصية (بدون aqrabLicense في package.json) لا تُقفل أبدًا. بيانات العميل لا تُحتجز: التصدير متاح دائمًا. */
AQ.lic = { status: 'off' };
async function licLoad() {
  if (!window.aq || !aq.licStatus) return;
  try { AQ.lic = await aq.licStatus(); } catch (e) { AQ.lic = { status: 'off' }; }
}
function licLocked() { return AQ.lic && AQ.lic.status === 'locked'; }
function licScreen() {
  const l = AQ.lic, lg = $('#lg'); lg.style.display = 'flex';
  lg.innerHTML = `<div class=bx><img src="icon.png" alt=""><h2>العقرب الحسابي</h2><p class=bd>${esc(l.reason || 'البرنامج غير مفعّل')}</p>
  <label>مفتاح الترخيص<input id=lkey type=password dir=ltr autocomplete=off spellcheck=false placeholder="الصق المفتاح هنا (لا يظهر)"></label>
  <p id=le class=bd></p><button class=btn style="width:100%" id=lact>تفعيل</button>
  <p class=mu style="font-size:12px;margin:10px 0 4px">بياناتك محفوظة وآمنة. يمكنك تصدير نسخة منها في أي وقت:</p>
  <button class=g2 style="width:100%" id=lexp>📤 تصدير نسخة احتياطية من بياناتي</button></div>`;
  $('#lexp').onclick = async () => { try { const r = await aq.exportTo(); if (r && r.ok) toast('تم تصدير النسخة', 'ok'); else if (r && !r.canceled) $('#le').textContent = r.error || 'تعذّر التصدير'; } catch (e) { $('#le').textContent = e.message; } };
  $('#lact').onclick = async () => {
    $('#le').textContent = '';
    const r = await aq.licActivate($('#lkey').value);
    if (!r.ok) { $('#le').textContent = r.error; return; }
    AQ.lic = r.status; lg.style.display = 'none'; toast('تم تفعيل الترخيص — شكرًا لك', 'ok'); gate();
  };
}
function licLine(l) {
  if (l.status === 'off') return 'نسخة غير مقيّدة (لا تحتاج ترخيصًا).';
  if (l.status === 'trial') return `<b>ترخيص تجريبي</b> (${l.days} يومًا) — متبقي ${l.daysLeft} يومًا.`;
  if (l.status === 'ok') return `<b>ترخيص دائم</b> — مُفعّل${l.name ? ' (' + esc(l.name) + ')' : ''}.`;
  return 'غير مفعّلة.';
}
function licCard() {
  const l = AQ.lic || { status: 'off' }; if (l.status === 'off') return '';
  return `<div class=cd><h3 style="margin:0 0 6px">الترخيص</h3><p style="margin:4px 0">${licLine(l)}</p><button class=g2 data-a=licChange>${l.status === 'ok' ? 'تغيير المفتاح' : 'إدخال المفتاح الدائم'}</button></div>`;
}
ACT.licChange = () => form({ title: 'مفتاح الترخيص', fields: [{ k: 'key', l: 'المفتاح', t: 'password', req: 1, full: 1 }], ok: 'تفعيل', submit: async v => {
  const r = await aq.licActivate(v.key); if (!r.ok) throw new Error(r.error);
  AQ.lic = r.status; toast('تم تفعيل الترخيص', 'ok'); render(); } });
if (typeof PAGES !== 'undefined' && PAGES.settings) { const _st = PAGES.settings; PAGES.settings = () => _st() + licCard(); }
if (typeof enter === 'function') { const _enter = enter; enter = function () { const r = _enter.apply(this, arguments); const l = AQ.lic || {}; if (l.status === 'trial' && !AQ.licSaid) { AQ.licSaid = 1; setTimeout(() => toast('نسخة تجريبية — متبقي ' + l.daysLeft + ' يومًا. فعّل الترخيص من الإعدادات.', 'ok'), 600); } return r; }; }
