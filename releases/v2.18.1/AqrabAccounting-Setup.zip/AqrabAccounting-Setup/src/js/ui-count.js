/* ui-count.js — جرد المخزون: أدخل الكمية المعدودة فعليًا، فتُسوّى الفروقات بحركة «جرد» ويُحفظ محضر CNT-xxxx. */
'use strict';
const CNT = { q: '', cat: '', only: false, vals: {}, sys: {}, note: '', err: '' };
const cntParse = v => { const s = String(v).trim(); if (s === '') return null; const n = Money.parseQty(s); return n === null || n < 0 ? NaN : n; };
function cntRows() {
  const s = S(), q = CNT.q.trim().toLowerCase();
  return s.prod.filter(p => !p.arch && (!CNT.cat || p.cat === CNT.cat) && (!q || [p.n, p.bc, p.model, p.brand].some(x => String(x || '').toLowerCase().includes(q))) && (!CNT.only || (p.id in CNT.vals)));
}
function cntSummary() {
  const s = S(); let counted = 0, diffs = 0, bad = 0, val = 0, stale = 0;
  Object.keys(CNT.vals).forEach(id => {
    const p = s.prod.find(x => x.id === id); if (!p) return; const c = cntParse(CNT.vals[id]);
    if (c === null) return; if (Number.isNaN(c)) { bad++; return; }
    counted++; if (c !== p.q) { diffs++; val += (c < p.q ? -1 : 1) * Money.lineTotal(p.co, Math.abs(c - p.q)); }
    if (CNT.sys[id] !== undefined && CNT.sys[id] !== p.q) stale++;
  });
  return { counted, diffs, bad, val, stale };
}
function cntSumHTML() {
  const k = cntSummary(), total = S().prod.filter(p => !p.arch).length;
  return `<div class=g><div class=k><small>تم عدّه</small><b>${k.counted} / ${total}</b></div><div class=k><small>منتجات فيها فرق</small><b class="${k.diffs ? 'bd' : 'ok'}">${k.diffs}</b></div><div class=k><small>قيمة الفروقات (بسعر التكلفة)</small><b class="${k.val < 0 ? 'bd' : k.val > 0 ? 'ok' : ''}">${fm(k.val)}</b></div></div>
  ${k.bad ? `<p class=bd>${k.bad} خانة فيها كمية غير صحيحة — صحّحها قبل الاعتماد.</p>` : ''}${k.stale ? `<p class=bd>تغيّرت كمية ${k.stale} منتج في النظام منذ بدأت عدّها (بيع/شراء). اضغط «تحديث أرقام النظام» بعد التأكد من عدّك.</p>` : ''}${CNT.err ? `<p class=bd>${esc(CNT.err)}</p>` : ''}`;
}
function cntPage() {
  const s = S(), list = cntRows(), cats = [...new Set(s.prod.filter(p => !p.arch && p.cat).map(p => p.cat))].sort();
  const rows = list.slice(0, 600).map(p => {
    const v = CNT.vals[p.id] === undefined ? '' : CNT.vals[p.id], c = cntParse(v), d = c === null || Number.isNaN(c) ? null : c - p.q;
    return `<tr><td>${esc(p.n)}</td><td class=num style="direction:ltr">${esc(p.bc || '')}</td><td class=num>${fq(p.q)}</td><td><input class=pi data-i=cntv data-p="${esc(p.id)}" value="${esc(v)}" inputmode=decimal placeholder="—" style="width:110px"></td><td class=num id="cd_${esc(p.id)}">${cntDiff(d)}</td></tr>`;
  }).join('');
  const past = (s.cnt || []).slice().reverse().slice(0, 30).map(r => [esc(r.no), r.date, userName(r.by), r.lines.length, r.lines.filter(l => l.diff !== 0).length, `<span class="${r.valDiff < 0 ? 'bd' : r.valDiff > 0 ? 'ok' : ''}">${fm(r.valDiff)}</span>`, esc(r.note || ''), btn('cntDetail', 'تفاصيل', { id: r.id })]);
  return `<div class=cd><p class=mu style="margin-top:0">اكتب الكمية التي عددتها فعليًا في المخزن لكل منتج (يمكنك جرد جزئي: المنتجات التي تتركها فارغة لا تتأثر). لا يتغير شيء قبل الضغط على «اعتماد الجرد».</p>
  <div class=tb><label>بحث<input data-c=cntq value="${esc(CNT.q)}" placeholder="اسم / باركود / موديل"></label><label>الصنف<select data-c=cntcat>${optsHTML(cats.map(c => [c, c]), CNT.cat, 'الكل')}</select></label>
  <label>ملاحظة على الجرد<input data-i=cntnote value="${esc(CNT.note)}" placeholder="مثال: جرد نهاية الشهر" maxlength=200></label>
  <label style="flex:0 0 auto;display:flex;gap:6px;align-items:center"><input type=checkbox data-c=cntonly ${CNT.only ? 'checked' : ''}> أظهر ما أدخلتُ له كمية فقط</label></div>
  <div id=cntsum>${cntSumHTML()}</div>
  <div class=tw><table><thead><tr><th>المنتج</th><th>الباركود</th><th>كمية النظام</th><th>الكمية المعدودة</th><th>الفرق</th></tr></thead><tbody>${rows || '<tr><td colspan=5 class=mu>لا منتجات مطابقة.</td></tr>'}</tbody></table></div>
  ${list.length > 600 ? `<p class=mu style="font-size:12px">يُعرض أول 600 منتج، استخدم البحث لتضييق القائمة.</p>` : ''}
  <div class=ac>${can('stock') ? '<button class=btn data-a=cntSave>✔ اعتماد الجرد</button>' : '<span class=mu>لا تملك صلاحية تسوية المخزون.</span>'}<button class=g2 data-a=cntRefresh>تحديث أرقام النظام</button><button class=g2 data-a=cntClear>مسح المُدخَل</button></div></div>
  <div class=cd><h3>محاضر الجرد السابقة</h3>${past.length ? tbl(['الرقم', 'التاريخ', 'بواسطة', 'منتجات معدودة', 'فروقات', 'قيمة الفروقات', 'ملاحظة', ''], past) : '<p class=mu style="margin:0">لا توجد محاضر جرد بعد.</p>'}</div>`;
}
const cntDiff = d => (d === null ? '' : d === 0 ? '<span class=ok>مطابق</span>' : `<b class="${d < 0 ? 'bd' : 'ok'}">${d > 0 ? '+' : ''}${LTR(Money.fmtQty(d))}</b>`);
INP.cntv = (v, t) => {
  const id = t.dataset.p, p = S().prod.find(x => x.id === id); if (!p) return;
  if (v.trim() === '') { delete CNT.vals[id]; delete CNT.sys[id]; } else { CNT.vals[id] = v; if (CNT.sys[id] === undefined) CNT.sys[id] = p.q; }
  const c = cntParse(v), cell = document.getElementById('cd_' + id); if (cell) cell.innerHTML = cntDiff(c === null || Number.isNaN(c) ? null : c - p.q);
  t.style.outline = Number.isNaN(c) ? '2px solid #dc2626' : '';
  $('#cntsum').innerHTML = cntSumHTML();
};
INP.cntnote = v => { CNT.note = v; };
CHG.cntq = v => { CNT.q = v; render(); }; CHG.cntcat = v => { CNT.cat = v; render(); }; CHG.cntonly = (v, t) => { CNT.only = t.checked; render(); };
ACT.cntClear = () => ask('مسح المُدخَل', 'مسح كل الكميات التي أدخلتها في هذا الجرد؟ (لن يتأثر المخزون)', () => { CNT.vals = {}; CNT.sys = {}; CNT.err = ''; render(); });
ACT.cntRefresh = () => { Object.keys(CNT.vals).forEach(id => { const p = S().prod.find(x => x.id === id); if (p) CNT.sys[id] = p.q; }); CNT.err = ''; render(); toast('تم تحديث أرقام النظام', 'ok'); };
ACT.cntSave = () => {
  const k = cntSummary();
  if (k.bad) return toast('صحّح الكميات غير الصحيحة أولًا', 'err');
  if (!k.counted) return toast('لم تُدخل أي كمية معدودة', 'err');
  ask('اعتماد الجرد', `سيُعتمد جرد <b>${k.counted}</b> منتج، منها <b>${k.diffs}</b> فيها فرق بقيمة <b>${fm(k.val)}</b> (${esc(baseCode())}). ستُسوّى الفروقات في المخزون ويُحفظ محضر دائم لا يُحذف. متابعة؟`, async () => {
    const items = Object.keys(CNT.vals).map(id => ({ p: id, counted: cntParse(CNT.vals[id]), sys: CNT.sys[id] })).filter(x => x.counted !== null);
    try {
      const r = AQ.en.stocktake({ items, note: CNT.note, user: AQ.me });
      CNT.vals = {}; CNT.sys = {}; CNT.note = ''; CNT.err = ''; render();
      setTimeout(() => info('تم اعتماد الجرد بنجاح', `<p>رقم المحضر: <b>${esc(r.no)}</b><br>المنتجات المعدودة: ${r.counted} — فيها فرق: ${r.changed}<br>قيمة الفروقات: <b>${fm(r.valDiff)}</b> (${esc(baseCode())})</p>`), 60);
    } catch (e) { CNT.err = e.message; render(); }
  }, 'اعتماد');
};
ACT.cntDetail = d => {
  const r = (S().cnt || []).find(x => x.id === d.id); if (!r) return;
  const ls = r.lines.slice().sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff));
  $('#md').innerHTML = `<div class=ov><div class="bx wide"><h3>${esc(r.no)} — ${esc(r.date)}</h3><p class=mu>بواسطة ${userName(r.by)}${r.note ? ' — ' + esc(r.note) : ''} | قيمة الفروقات: <b>${fm(r.valDiff)}</b></p>
  ${tbl(['المنتج', 'كمية النظام', 'المعدودة', 'الفرق', 'قيمة الفرق'], ls.map(l => [esc(l.n), fq(l.sys), fq(l.cnt), cntDiff(l.diff), l.diff ? `<span class="${l.diff < 0 ? 'bd' : 'ok'}">${fm((l.diff < 0 ? -1 : 1) * Money.lineTotal(l.co, Math.abs(l.diff)))}</span>` : '']))}
  <div class=ac><button class=g2 data-a=close>إغلاق</button></div></div></div>`;
};
