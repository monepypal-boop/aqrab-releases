/* ai-local.js — العقرب الذكي بدون إنترنت وبدون مفتاح: يربط الأسئلة العربية الشائعة بأدوات القراءة مباشرة.
 * لا يحسب شيئًا بنفسه: كل رقم يأتي من نتيجة أداة في ai-tools.js، ويُعرض مع فترته. إن لم يفهم السؤال يقول ذلك صراحة. */
'use strict';
(function (root) {
  const norm = root.AIT.norm;
  const has = (t, words) => words.some(w => t.includes(norm(w)));
  const pad = n => String(n).padStart(2, '0');
  const ymd = d => d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate());
  const D = s => new Date(s + 'T12:00:00Z');
  const add = (s, n) => { const d = D(s); d.setUTCDate(d.getUTCDate() + n); return ymd(d); };
  const eom = (y, m) => ymd(new Date(Date.UTC(y, m, 0, 12)));
  const MONTHS = [['كانون الثاني', 1], ['يناير', 1], ['شباط', 2], ['فبراير', 2], ['اذار', 3], ['مارس', 3], ['نيسان', 4], ['ابريل', 4], ['ايار', 5], ['مايو', 5], ['حزيران', 6], ['يونيو', 6], ['تموز', 7], ['يوليو', 7], ['اب', 8], ['اغسطس', 8], ['ايلول', 9], ['سبتمبر', 9],
    ['تشرين الاول', 10], ['اكتوبر', 10], ['تشرين الثاني', 11], ['نوفمبر', 11], ['كانون الاول', 12], ['ديسمبر', 12]].map(([n, m]) => [norm(n), m]);

  /* يعيد {from,to} أو null إن لم تُذكر فترة؛ أو {err} إن كانت الصياغة غامضة */
  function period(t, today) {
    let m = t.match(/(\d{4}-\d{2}-\d{2}).{0,12}?(\d{4}-\d{2}-\d{2})/);
    if (m) return { from: m[1], to: m[2] };
    m = t.match(/(\d{4}-\d{2}-\d{2})/); if (m) return { from: m[1], to: m[1] };
    const y = +today.slice(0, 4), mo = +today.slice(5, 7);
    if (has(t, ['الشهر الماضي', 'الشهر السابق', 'الشهر اللي فات'])) { const e = add(today.slice(0, 7) + '-01', -1); return { from: e.slice(0, 7) + '-01', to: e }; }
    if (has(t, ['هذا الشهر', 'هالشهر', 'الشهر الحالي', 'هذا الشهر'])) return { from: today.slice(0, 7) + '-01', to: today };
    if (has(t, ['امس', 'البارحه'])) { const d = add(today, -1); return { from: d, to: d }; }
    if (has(t, ['اليوم', 'هاليوم'])) return { from: today, to: today };
    if (has(t, ['الاسبوع الماضي', 'الاسبوع السابق'])) { const w = (D(today).getUTCDay() + 1) % 7, s = add(today, -w - 7); return { from: s, to: add(s, 6) }; }
    if (has(t, ['هذا الاسبوع', 'هالاسبوع', 'الاسبوع الحالي'])) { const w = (D(today).getUTCDay() + 1) % 7; return { from: add(today, -w), to: today }; }
    if (has(t, ['هذه السنه', 'هذا العام', 'السنه الحاليه', 'هالسنه'])) return { from: y + '-01-01', to: today };
    if (has(t, ['السنه الماضيه', 'العام الماضي'])) return { from: (y - 1) + '-01-01', to: (y - 1) + '-12-31' };
    m = t.match(/اخر (\d{1,3}) (يوم|ايام|اسبوع|اسابيع|شهر|اشهر)/);
    if (m) { const n = +m[1], k = /يوم|ايام/.test(m[2]) ? 1 : /اسبوع|اسابيع/.test(m[2]) ? 7 : 30; return { from: add(today, -(n * k - 1)), to: today }; }
    for (const [name, num] of MONTHS.slice().sort((a, b) => b[0].length - a[0].length)) {
      if (new RegExp('(^| )' + name + '( |$)').test(t)) { const yy = num > mo ? y - 1 : y; return { from: yy + '-' + pad(num) + '-01', to: eom(yy, num), note: 'اعتمدتُ شهر ' + num + ' من سنة ' + yy }; }
    }
    m = t.match(/شهر (\d{1,2})( |$)/); if (m && +m[1] >= 1 && +m[1] <= 12) { const num = +m[1], yy = num > mo ? y - 1 : y; return { from: yy + '-' + pad(num) + '-01', to: eom(yy, num), note: 'اعتمدتُ شهر ' + num + ' من سنة ' + yy }; }
    if (has(t, ['كل الفترات', 'من البدايه', 'الاجمالي الكلي', 'منذ البدايه', 'كل المبيعات'])) return { from: '2000-01-01', to: today, all: true };
    return null;
  }

  function fmtVal(v, ind) {
    if (Array.isArray(v)) return v.length ? '\n' + v.map((x, i) => ind + (i + 1) + '. ' + (x && typeof x === 'object' ? Object.entries(x).map(([k, y]) => k.replace(/_/g, ' ') + ': ' + y).join(' — ') : x)).join('\n') : ' لا يوجد';
    if (v && typeof v === 'object') return '\n' + Object.entries(v).map(([k, y]) => ind + '• ' + k.replace(/_/g, ' ') + ': ' + (typeof y === 'object' ? fmtVal(y, ind + '  ') : y)).join('\n');
    return ' ' + v;
  }
  function fmt(res) {
    if (res.خطأ) return res.خطأ;
    const src = res['المصدر']; const lines = Object.entries(res).filter(([k]) => k !== 'المصدر' && k !== 'ملاحظة').map(([k, v]) => '• ' + k.replace(/_/g, ' ') + ':' + fmtVal(v, '   '));
    if (res['ملاحظة']) lines.push('ملاحظة: ' + res['ملاحظة']);
    if (src) lines.push('المصدر: ' + src);
    return lines.join('\n');
  }

  /* يعيد {tool,args,pre} أو null */
  function route(raw, ctx) {
    const t = norm(raw), S = ctx.S, today = ctx.today;
    if (!t) return null;
    if (has(t, ['مساعده', 'ماذا تستطيع', 'شو بتعمل', 'ماذا تعرف', 'شو بتقدر'])) return { help: true };
    const per = period(t, today);
    const inv = raw.match(/[A-Za-z]{1,6}-\d{3,8}/);
    if (inv) return { tool: 'find_invoice', args: { query: inv[0] } };
    if (has(t, ['قارن', 'مقارنه', 'مقارنة'])) return { tool: 'compare_months', args: {} };
    if (has(t, ['راس مال', 'رأس مال', 'قيمه المخزون', 'قيمه البضاعه', 'راس المال']) ) return { tool: 'stock_capital', args: {} };
    if (has(t, ['اعاده الطلب', 'اعاده طلب', 'ماذا اشتري', 'شو اشتري', 'كميات الطلب', 'اقتراح شراء', 'اطلب'])) return { tool: 'reorder_suggestions', args: {} };
    if (has(t, ['الاكثر مبيعا', 'الاكثر بيعا', 'اكثر منتج', 'افضل المنتجات', 'اكثر المنتجات', 'الاكثر طلبا', 'الاكثر رواجا', 'اكثر ما نبيع'])) {
      const p = per || { from: today.slice(0, 7) + '-01', to: today, def: 'لم تحدد فترة فاعتمدتُ هذا الشهر' };
      return { tool: 'top_products', args: { from: p.from, to: p.to }, pre: p.def || p.note };
    }
    if (has(t, ['نفاد', 'نفذ', 'ناقص', 'نواقص', 'قارب', 'منخفض', 'حد الطلب', 'قليله', 'خلص', 'خالص'])) return { tool: 'low_stock', args: {} };
    if (has(t, ['غير مسدد', 'غير المسدد', 'غير مدفوع', 'غير المدفوع', 'غير مسدده', 'متبقي', 'الديون', 'ديون', 'مستحقات']) && !has(t, ['موردين', 'مورد'])) return { tool: 'unpaid_invoices', args: {} };
    if (has(t, ['صندوق', 'الصندوق', 'كاش'])) return { ask: 'رصيد الصندوق غير متاح في هذا الوضع بعد. تجده في صفحة «المصاريف والصندوق» أو في الرئيسية.' };
    const wantsBal = has(t, ['رصيد', 'ارصده', 'مديونيه', 'ذمم', 'مدين', 'ديونه', 'ديونها', 'كم عليه']);
    if (wantsBal) {
      if (has(t, ['موردين', 'الموردين', 'مورد'])) return { tool: 'balances', args: { kind: 'sup' } };
      const nm = S.cust.filter(c => !c.arch && norm(c.n).length >= 3 && t.includes(norm(c.n)));
      if (nm.length === 1) return { cust: nm[0] };
      if (nm.length > 1) return { ask: 'وجدتُ أكثر من عميل بهذا الاسم: ' + nm.slice(0, 6).map(c => c.n).join('، ') + '. اكتب الاسم كاملًا.' };
      return { tool: 'balances', args: { kind: 'cust' } };
    }
    if (has(t, ['فاتوره', 'فاتورة', 'فواتير'])) {
      const m = raw.match(/(?:فاتور[ةه]|فواتير)\s+(?:رقم\s+)?(?:العميل\s+|الزبون\s+)?(.+?)\s*[؟?]?$/);
      if (m && m[1].trim()) return { tool: 'find_invoice', args: { query: m[1].trim() } };
    }
    if (has(t, ['مبيعات', 'بعنا', 'بيع', 'ربح', 'ارباح', 'صافي', 'ايراد', 'مبيع', 'مصاريف'])) {
      const cn = S.cust.filter(c => !c.arch && norm(c.n).length >= 3 && t.includes(norm(c.n)));
      if (cn.length) return { ask: 'لا أدعم المبيعات لعميل محدد في هذا الوضع. اكتب «رصيد ' + cn[0].n + '» أو «فاتورة ' + cn[0].n + '».' };
      const p = per || { from: today, to: today, def: 'لم تحدد فترة فاعتمدتُ اليوم' };
      return { tool: 'sales_summary', args: { from: p.from, to: p.to }, pre: p.def || p.note };
    }
    if (has(t, ['سعر', 'كمية', 'كميه', 'مخزون', 'بكم', 'كم باقي', 'عندنا', 'موجود', 'باركود'])) {
      const STOP = new Set(['كم', 'كميه', 'سعر', 'مخزون', 'بكم', 'باقي', 'عندنا', 'موجود', 'من', 'هل', 'ما', 'هو', 'هي', 'الباركود', 'باركود', 'المنتج', 'منتج', 'في', 'لدينا', 'الكميه', 'السعر', 'المخزون', 'لل']);
      const q = t.split(' ').filter(w => w && !STOP.has(w)).join(' ');
      if (q.length >= 2) return { tool: 'find_product', args: { query: q } };
    }
    return null;
  }

  const EXAMPLES = ['كم مبيعات اليوم؟', 'ما صافي الربح هذا الشهر؟', 'مبيعات الشهر الماضي', 'ما المنتجات الأكثر مبيعًا هذا الشهر؟', 'ما المنتجات التي قاربت على النفاد؟', 'ما رأس مال المخزون؟', 'الفواتير غير المسددة', 'أرصدة العملاء', 'رصيد <اسم العميل>', 'أرصدة الموردين', 'ابحث عن فاتورة BR-0051', 'كم كمية <اسم المنتج>؟', 'قارن مبيعات هذا الشهر بالسابق', 'اقترح كميات إعادة الطلب'];

  function answer(text, ctx) {
    const r = route(text, ctx);
    if (!r) return { ok: false, text: 'لم أفهم سؤالك. في هذا الوضع أفهم صيغًا محددة، ولا أخمّن. جرّب مثلًا:\n' + EXAMPLES.map(e => '- ' + e).join('\n') };
    if (r.help) return { ok: true, text: 'أجيب بدون إنترنت عن أسئلة مثل:\n' + EXAMPLES.map(e => '- ' + e).join('\n') + '\nأنا للقراءة فقط ولا أعدّل شيئًا.' };
    if (r.ask) return { ok: true, text: r.ask };
    if (r.cust) {
      if (!root.Engine.can(ctx.S, ctx.uid, 'party') && !root.Engine.can(ctx.S, ctx.uid, 'rep')) return { ok: true, text: 'ليست لدى المستخدم الحالي صلاحية لهذه المعلومات' };
      const b = (root.Engine.balances(ctx.S, 'cust')[r.cust.id]) || {}, ents = Object.entries(b);
      const body = ents.length ? ents.map(([cur, v]) => '• الرصيد: ' + root.Money.fmt(v, root.Engine.decOf(ctx.S, cur)) + ' ' + cur + (v > 0 ? ' (مستحق لنا على العميل)' : v < 0 ? ' (رصيد دائن للعميل)' : '')).join('\n') : '• الرصيد: 0 (لا فواتير آجلة)';
      return { ok: true, text: 'العميل: ' + r.cust.n + '\n' + body + '\nالمصدر: أرصدة الفواتير والدفعات' };
    }
    const res = JSON.parse(root.AIT.run(r.tool, r.args, ctx));
    return { ok: true, tool: r.tool, text: (r.pre ? '(' + r.pre + ')\n' : '') + fmt(res) };
  }
  root.AIL = { answer, route, norm, period, EXAMPLES };
  if (typeof module === 'object' && module.exports) module.exports = root.AIL;
})(typeof window !== 'undefined' ? window : globalThis);
