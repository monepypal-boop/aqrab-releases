/* ui-boot.js — تحميل البيانات، الترحيل من النسخة القديمة، وشاشة الدخول */
'use strict';
const KV2 = 'aqrab_v2';

function mkEngine(state) {
  return new Engine.Engine(state, { persist: json => { AQS.setItem(KV2, json); saved(); } });
}
function parseJson(t) { try { return JSON.parse(t); } catch (e) { return undefined; } }

async function bootstrap() {
  await licLoad();
  let raw2 = null, raw1 = null, legacyPw = null;
  try { raw2 = AQS.getItem(KV2); raw1 = AQS.getItem(K); legacyPw = AQS.getItem(KPW); } catch (e) { /* يبقى فارغًا */ }
  if (raw2) {
    const st = parseJson(raw2);
    if (!st || st.ver !== 2 || !Array.isArray(st.inv) || !Array.isArray(st.users)) {
      // لا نكتب شيئًا فوق بيانات لا نفهمها: نعرض خيار الاستعادة فقط
      AQ.en = new Engine.Engine(Engine.newState(), { persist() { throw new Error('ملف البيانات غير صالح — لا يمكن الحفظ قبل الاستعادة'); } });
      AQ.fatal = 'تعذّرت قراءة ملف البيانات (قد يكون تالفًا). لم يتم تعديل أي شيء. استعد من نسخة احتياطية:';
      return gate();
    }
    AQ.en = mkEngine(st);
  } else if (raw1) {
    const v1 = parseJson(raw1);
    if (!v1 || !v1.co || !Array.isArray(v1.inv)) {
      AQ.en = new Engine.Engine(Engine.newState(), { persist() { throw new Error('بيانات النسخة القديمة غير صالحة — لا يمكن الحفظ قبل الاستعادة'); } });
      AQ.fatal = 'تعذّرت قراءة بيانات النسخة القديمة. لم يتم تعديل أي شيء. استعد من نسخة احتياطية:';
      return gate();
    }
    const { state, report } = Engine.migrate(v1, legacyPw);
    // نسخة احتياطية كاملة قبل الترحيل، وبيانات النسخة القديمة تبقى كما هي دون تعديل
    if (window.aq) { try { await aq.backup('pre-migrate'); } catch (e) { /* النسخة الاحتياطية اختيارية هنا؛ بيانات v1 لا تُمَس */ } }
    AQ.en = mkEngine(state);
    try { AQ.en.persist(JSON.stringify(state)); } catch (e) { AQ.fatal = 'تعذّر حفظ البيانات المرحّلة: ' + e.message; return gate(); }
    AQ.mig = report;
  } else {
    AQ.en = mkEngine(Engine.newState());
  }
  gate();
}

function gate() {
  if (licLocked()) return licScreen();
  const lg = $('#lg'); lg.style.display = 'flex';
  const s = S();
  // استئناف الجلسة بعد إعادة تحميل الواجهة
  let sid = null; try { sid = sessionStorage.getItem('aq_uid'); } catch (e) { /* لا شيء */ }
  if (!AQ.fatal && sid && s.users.some(u => u.id === sid && u.active)) return enter(sid);
  const setup = !s.users.length && !AQ.fatal;
  const legacyHint = s.users.length === 1 && s.users[0].legacy;
  lg.innerHTML = `<div class=bx><img src="icon.png" alt=""><h2>العقرب الحسابي</h2><p class=mu style="margin-top:0">النظام المحاسبي المتكامل</p>
  ${AQ.fatal ? `<p class=bd>${esc(AQ.fatal)}</p>` : setup
    ? `<p>أول تشغيل: أنشئ حساب المدير</p><label>الاسم<input id=gn value="المدير"></label><label>اسم الدخول (إنجليزي)<input id=gu value=admin dir=ltr></label><label>كلمة السر (4 أحرف على الأقل)<input id=gp type=password></label><label>تأكيد كلمة السر<input id=gp2 type=password></label>`
    : `<p>تسجيل الدخول</p><label>اسم المستخدم<input id=gu value="${esc(s.users.length === 1 ? s.users[0].user : '')}" dir=ltr autocomplete=username></label><label>كلمة السر<input id=gp type=password autocomplete=current-password></label>${legacyHint ? '<p class=mu style="font-size:12px">تم تحديث البرنامج: اسم المستخدم <b>admin</b> وكلمة السر هي نفسها التي كنت تستخدمها.</p>' : ''}`}
  <p id=le class=bd></p>${AQ.fatal ? '' : `<button class=btn style="width:100%" id=lb>${setup ? 'إنشاء ودخول' : 'دخول'}</button>`}<div id=lrs></div></div>`;
  if (!AQ.fatal) {
    const go = async () => {
      const b = $('#lb'); if (b.disabled) return; b.disabled = true; $('#le').textContent = '';
      try {
        if (setup) {
          const p = $('#gp').value; if (p !== $('#gp2').value) throw new Error('التأكيد لا يطابق');
          const id = await AQ.en.setupAdmin({ name: $('#gn').value.trim(), user: $('#gu').value, pw: p });
          enter(id);
        } else {
          const id = await AQ.en.login($('#gu').value, $('#gp').value);
          if (!id) throw new Error('اسم المستخدم أو كلمة السر غير صحيحة');
          enter(id);
        }
      } catch (e) { $('#le').textContent = e.message; b.disabled = false; }
    };
    $('#lb').onclick = go;
    lg.querySelectorAll('input').forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') go(); }));
    const f = $('#gp') && !$('#gu').value ? $('#gu') : $('#gp'); if (f) f.focus();
  }
  lgRestore();
}

function enter(uid) {
  AQ.me = uid; try { sessionStorage.setItem('aq_uid', uid); } catch (e) { /* لا شيء */ }
  $('#lg').style.display = 'none'; $('#lg').innerHTML = '';
  shell(); render();
  try { if (window.AI) AI.onEnter(); } catch (e) { console.error(e); }
  if (AQ.mig) {
    const r = AQ.mig; AQ.mig = null;
    info('✅ تم تحديث بياناتك إلى النظام الجديد', `<p>جميع بياناتك محفوظة: ${r.inv} فاتورة، ${r.products} منتج، ${r.customers} عميل.<br>قبل الترحيل حُفظت نسخة احتياطية كاملة، وبيانات النسخة القديمة لم تُعدَّل.</p>
    ${r.changed.length ? `<p class=bd>تغيّر إجمالي ${r.changed.length} فاتورة بفرق تقريب (أو بسبب تصحيح خطأ المرتجعات في الحساب القديم):</p>${tbl(['الفاتورة', 'الإجمالي القديم', 'الإجمالي الجديد'], r.changed.slice(0, 50).map(c => [esc(c.no), fm(c.old), fm(c.now)]))}` : '<p class=ok>إجماليات كل الفواتير تطابقت تمامًا مع الحساب القديم.</p>'}`);
  }
}
/* تحديث تلقائي للرئيسية عند تغيّر اليوم (بعد منتصف الليل أو بعد عودة الجهاز من السكون) */
setInterval(() => {
  try { if (AQ.me && AQ.en && AQ.tab === 'home' && AQ.homeDay && AQ.homeDay !== AQ.en.today() && !$('#md').innerHTML) render(); } catch (e) { /* لا شيء */ }
}, 20000);
if (window.aq && aq.onNav) aq.onNav(t => { if (AQ.me) go(t === 't' ? 'settings' : t); });

window.addEventListener('error', e => { try { toast('خطأ غير متوقع: ' + e.message, 'err'); } catch (x) { /* لا شيء */ } });
bootstrap().catch(e => { console.error(e); document.body.insertAdjacentHTML('afterbegin', '<pre style="color:red;padding:20px">' + esc(e.stack || e.message) + '</pre>'); });
