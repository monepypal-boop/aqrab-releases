/* engine.js — المحرك المحاسبي لـ «العقرب الحسابي» (بدون أي اعتماد على الواجهة)
 *
 * المبادئ:
 *  1) كل المبالغ أعداد صحيحة بأصغر وحدة (انظر money.js). لا float في أي حساب مالي.
 *  2) مصدر واحد للحقيقة: المدفوعات والنقد في دفتر `cash` فقط (المدفوع في الفاتورة = مجموع قيودها).
 *     حركة المخزون في `mv` فقط (كمية المنتج = مجموع حركاته).
 *  3) كل عملية داخل معاملة (tx): تُنفَّذ على نسخة، يُفحص اتساقها، ثم تُكتب دفعة واحدة؛
 *     إن فشل أي جزء (بما في ذلك الكتابة) تبقى الحالة كما كانت تمامًا.
 *  4) لا حذف للمستندات المرحّلة: إلغاء/مرتجع مع قيود عكسية، وسجل تدقيق متسلسل لا يُعدَّل.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./money.js'));
  else root.Engine = factory(root.Money);
})(typeof self !== 'undefined' ? self : this, function (M) {
  'use strict';

  /* ---------------- أدوات عامة ---------------- */
  const err = (m, code) => { const e = new Error(m); e.code = code || 'err'; return e; };
  /* رسوم إضافية اختيارية على الفاتورة (توصيل، تركيب…): تُسجَّل وتُطبع فقط، ولا تدخل في الإجمالي ولا الربح ولا الضريبة ولا الذمم ولا الصندوق */
  const MAX_EX = 5;
  function normEx(ex) {
    if (ex == null) return [];
    if (!Array.isArray(ex)) throw err('الرسوم الإضافية غير صحيحة');
    const out = [];
    ex.forEach(e => {
      const l = String((e && e.l) || '').trim().replace(/\s+/g, ' '), a = e ? e.a : 0;
      if (!l && (a === 0 || a == null)) return; // سطر فارغ يُتجاهل
      if (!l) throw err('اكتب بيان الرسم الإضافي (مثال: أجور توصيل)');
      if (l.length > 60) throw err('بيان الرسم الإضافي طويل (الحد 60 حرفًا)');
      if (!isInt(a) || a <= 0) throw err('مبلغ الرسم الإضافي غير صحيح: ' + l);
      out.push({ l, a });
    });
    if (out.length > MAX_EX) throw err('الحد الأقصى ' + MAX_EX + ' رسوم إضافية للفاتورة');
    return out;
  }
  const sum = a => { const r = a.reduce((s, x) => s + x, 0); if (!Number.isSafeInteger(r)) throw new RangeError('المبلغ أكبر من الحد المسموح'); return r; };
  const pad = (n, w) => String(n).padStart(w || 2, '0');
  const localDate = (d) => { d = d || new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
  const isInt = x => Number.isSafeInteger(x);
  const defaultUid = () => (globalThis.crypto && crypto.randomUUID ? crypto.randomUUID().replace(/-/g, '').slice(0, 16) : Date.now().toString(36) + Math.random().toString(36).slice(2, 8));
  function hash53(str, seed) { // ليس تشفيريًا: للكشف عن العبث العرضي في سجل التدقيق
    let h1 = 0xdeadbeef ^ (seed || 0), h2 = 0x41c6ce57 ^ (seed || 0);
    for (let i = 0; i < str.length; i++) { const ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
  }

  /* ---------------- الصلاحيات ---------------- */
  const PERMS = {
    sell: 'إجراء مبيعات', price: 'تعديل أسعار البيع', disc: 'منح خصم', negstock: 'البيع بما يتجاوز المخزون',
    invedit: 'تعديل الفواتير', void: 'إلغاء الفواتير', ret: 'تسجيل المرتجعات', collect: 'التحصيل والسداد',
    buy: 'المشتريات', prod: 'إدارة المنتجات', stock: 'تسوية المخزون', party: 'العملاء والموردون',
    exp: 'المصاريف', cash: 'حركات الصندوق', rep: 'التقارير', fx: 'العملات وأسعار الصرف',
    users: 'المستخدمون والصلاحيات', set: 'الإعدادات', backup: 'النسخ الاحتياطي والاستعادة'
  };
  const ALL = Object.keys(PERMS);
  const ROLES = {
    admin: { name: 'مدير', perms: ALL, maxDisc: 10000 },
    acct: { name: 'محاسب', perms: ALL.filter(p => !['users', 'set', 'negstock'].includes(p)), maxDisc: 10000 },
    cashier: { name: 'كاشير', perms: ['sell', 'disc', 'collect', 'party'], maxDisc: 500 }
  };
  const findUser = (S, id) => S.users.find(u => u.id === id);
  const can = (S, uid, perm) => { if (uid == null) return true; const u = findUser(S, uid); return !!(u && u.active && u.perms.includes(perm)); };
  /* تجاوز سياسة المخزون يتطلب مستخدمًا حقيقيًا بصلاحية، ولا يُمنح لعملية بلا هوية */
  const canOverride = (S, uid, perm) => uid != null && can(S, uid, perm);
  const need = (S, uid, perm) => { if (!can(S, uid, perm)) throw err('ليست لديك صلاحية: ' + PERMS[perm], 'perm'); };

  /* ---------------- الحالة الابتدائية ---------------- */
  function newState() {
    return {
      ver: 2,
      co: { n: 'العقرب الحسابي', ph: '', ad: '', tx: '' },
      set: {
        base: 'USD', taxBp: 0, negStock: false, cashDebt: false, rcpt: '80', rfoot: 'شكرًا لتعاملكم معنا', logo: '', terms: '',
        cur: [{ code: 'USD', sym: '$', dec: 2, rate: 1000000, name: 'دولار أمريكي' }]
      },
      cust: [], sup: [], rep: [], prod: [], inv: [], pur: [], exp: [], cash: [], mv: [], users: [], audit: [], cnt: [], qt: [],
      seq: { inv: 1, pur: 1, ret: 1, pret: 1, cnt: 1, qt: 1 }, mig: null
    };
  }

  /* ---------------- العملات ---------------- */
  const curDef = (S, code) => { const c = S.set.cur.find(x => x.code === code); if (!c) throw err('عملة غير معروفة: ' + code); return c; };
  const decOf = (S, code) => curDef(S, code).dec;
  const toBase = (S, amt, code, fx) => M.toBase(amt, decOf(S, code), decOf(S, S.set.base), fx);
  const fmtMoney = (S, amt, code) => { const c = curDef(S, code || S.set.base); return M.fmt(amt, c.dec); };
  const fxFor = (S, code, fx) => {
    if (code === S.set.base) return 1000000;
    const r = fx != null ? fx : curDef(S, code).rate;
    if (!isInt(r) || r <= 0) throw err('سعر الصرف غير صالح', 'fx');
    return r;
  };

  /* ---------------- حساب المستند (فاتورة بيع/شراء) — الحساب الوحيد في النظام ----------------
   * الترتيب: مجموع البنود → الخصم (يوزَّع على البنود بأكبر باقي) → الضريبة على الصافي (توزَّع) →
   * الإجمالي. المرتجع لبند = حصته من الصافي والضريبة بالتناسب (تراكميًا) فمجموع المرتجعات = البند كاملًا.
   */
  function calcDoc(doc, key) {
    const items = doc.items, n = items.length;
    const totals = items.map(x => M.lineTotal(x[key], x.q));
    const sub = sum(totals);
    const disc = doc.disc || 0;
    const lineDisc = M.allocate(disc, totals);
    const nets = totals.map((t, i) => t - lineDisc[i]);
    const net = sub - disc;
    const tax = M.pct(net, doc.rate || 0);
    const lineTax = M.allocate(tax, nets);
    const gross = nets.map((x, i) => x + lineTax[i]);
    const costTot = items.map(x => (key === 'pr' ? M.lineTotal(x.co || 0, x.q) : 0));
    const live = (doc.rt || []).filter(r => !r.void);
    const rq = new Array(n).fill(0);
    live.forEach(r => r.lines.forEach(l => { rq[l.k] += l.q; }));
    const R = (v, q, r) => (r ? M.mulDiv(v, r, q) : 0);
    const per = (arr, r) => arr.map((v, k) => R(v, items[k].q, r[k]));
    const retTotals = per(totals, rq), retDisc = per(lineDisc, rq), retNet = per(nets, rq), retTax = per(lineTax, rq), retGross = per(gross, rq), retCost = per(costTot, rq);
    // مبالغ كل مرتجع على حدة (فروق تراكمية)
    const cum = new Array(n).fill(0), returns = {};
    live.forEach(r => {
      const before = cum.slice();
      r.lines.forEach(l => { cum[l.k] += l.q; });
      const g = sum(items.map((x, k) => R(gross[k], x.q, cum[k]) - R(gross[k], x.q, before[k])));
      const nn = sum(items.map((x, k) => R(nets[k], x.q, cum[k]) - R(nets[k], x.q, before[k])));
      const cc = sum(items.map((x, k) => R(costTot[k], x.q, cum[k]) - R(costTot[k], x.q, before[k])));
      returns[r.id] = { gross: g, net: nn, tax: g - nn, cost: cc };
    });
    const out = {
      lines: items.map((x, k) => ({ total: totals[k], disc: lineDisc[k], net: nets[k], tax: lineTax[k], gross: gross[k], rq: rq[k], left: x.q - rq[k] })),
      sub, disc, net, tax, tot: net + tax, cost: sum(costTot),
      retGross: sum(retGross), retNet: sum(retNet), retTax: sum(retTax), retCost: sum(retCost), retSub: sum(retTotals), retDisc: sum(retDisc), returns
    };
    out.lines.forEach((l, k) => { l.retTotal = retTotals[k]; l.retNet = retNet[k]; l.retGross = retGross[k]; });
    out.subEff = out.sub - out.retSub; out.discEff = out.disc - out.retDisc; out.netEff = out.net - out.retNet;
    out.taxEff = out.tax - out.retTax; out.totEff = out.tot - out.retGross; out.costEff = out.cost - out.retCost;
    return out;
  }
  const calcInv = inv => calcDoc(inv, 'pr');
  const calcPur = p => calcDoc(p, 'co');

  /* ---------------- مؤشرات القراءة ---------------- */
  function paidMap(S) { // المدفوع الصافي لكل فاتورة بيع (من الدفتر فقط)
    const m = {};
    S.cash.forEach(c => { if (c.ref && c.ref.t === 'inv') m[c.ref.id] = (m[c.ref.id] || 0) + c.amt; });
    return m;
  }
  function purPaidMap(S) { // المدفوع الصافي للمورد (موجب = خرج من الصندوق)
    const m = {};
    S.cash.forEach(c => { if (c.ref && c.ref.t === 'pur') m[c.ref.id] = (m[c.ref.id] || 0) - c.amt; });
    return m;
  }
  function invView(S, inv, pm) {
    const c = calcInv(inv), paid = (pm || paidMap(S))[inv.id] || 0;
    return { c, paid, due: inv.void ? 0 : c.totEff - paid, void: !!inv.void };
  }
  function purView(S, p, pm) {
    const c = calcPur(p), paid = (pm || purPaidMap(S))[p.id] || 0;
    return { c, paid, due: p.void ? 0 : c.totEff - paid, void: !!p.void };
  }
  /* أرصدة العملاء/الموردين لكل عملة: موجب = مستحق على العميل / للمورد */
  function balances(S, kind) {
    const out = {};
    if (kind === 'cust') {
      const pm = paidMap(S);
      S.inv.forEach(i => { if (i.void || !i.c) return; const v = invView(S, i, pm); const o = out[i.c] = out[i.c] || {}; o[i.cur] = (o[i.cur] || 0) + v.due; });
    } else {
      const pm = purPaidMap(S);
      S.pur.forEach(p => { if (p.void || !p.s) return; const v = purView(S, p, pm); const o = out[p.s] = out[p.s] || {}; o[p.cur] = (o[p.cur] || 0) + v.due; });
    }
    return out;
  }
  /* أعمار الديون: لكل عميل (أو مورد) ولكل عملة، المتبقي على الفواتير غير المسددة موزّعًا بحسب عمر الفاتورة (من تاريخها حتى asOf).
   * الشرائح: 0–30 | 31–60 | 61–90 | أكثر من 90 يومًا. المتبقي السالب (رصيد دائن للعميل) لا يُخصم من الشرائح بل يظهر في عمود «رصيد دائن».
   * للقراءة فقط: لا يغيّر أي بيانات. */
  function agingReport(S, kind, asOf) {
    const day = d => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(d || ''); return m ? Date.UTC(+m[1], +m[2] - 1, +m[3]) / 864e5 : NaN; };
    const now = day(asOf), isC = kind === 'cust', rows = {};
    const pm = isC ? paidMap(S) : purPaidMap(S), docs = isC ? S.inv : S.pur, names = isC ? S.cust : S.sup;
    docs.forEach(d => {
      const pid = isC ? d.c : d.s; if (d.void || !pid) return;
      const v = isC ? invView(S, d, pm) : purView(S, d, pm); if (v.due === 0) return;
      const age = Math.max(0, now - day(d.date)), key = pid + '|' + d.cur;
      const r = rows[key] = rows[key] || { id: pid, n: (names.find(x => x.id === pid) || {}).n || '—', cur: d.cur, b0: 0, b30: 0, b60: 0, b90: 0, credit: 0, total: 0, count: 0, oldest: 0 };
      if (v.due < 0) { r.credit += -v.due; r.total += v.due; return; }
      const b = age <= 30 ? 'b0' : age <= 60 ? 'b30' : age <= 90 ? 'b60' : 'b90';
      r[b] += v.due; r.total += v.due; r.count++; r.oldest = Math.max(r.oldest, age);
    });
    return Object.values(rows).filter(r => r.total !== 0 || r.credit !== 0).sort((a, b) => (b.b90 - a.b90) || (b.total - a.total));
  }
  function cashBalances(S) { // {cur:{method:amt}}
    const o = {};
    S.cash.forEach(c => { const a = o[c.cur] = o[c.cur] || {}; a[c.method] = (a[c.method] || 0) + c.amt; });
    return o;
  }

  /* ---------------- فحص الاتساق ---------------- */
  function reconcileList(S) { // يعيد قائمة فحوص {name, expected, actual, ok}
    const checks = [];
    const mvSum = {}; S.mv.forEach(m => { mvSum[m.p] = (mvSum[m.p] || 0) + m.dq; });
    let badStock = [];
    S.prod.forEach(p => { if ((mvSum[p.id] || 0) !== p.q) badStock.push(p.n); });
    checks.push({ name: 'كمية كل منتج = مجموع حركات المخزون', expected: 0, actual: badStock.length, detail: badStock.slice(0, 5).join('، '), ok: !badStock.length });
    const prodIds = new Set(S.prod.map(p => p.id));
    const orphanMv = S.mv.filter(m => !prodIds.has(m.p)).length;
    checks.push({ name: 'لا حركات مخزون لمنتجات غير موجودة', expected: 0, actual: orphanMv, ok: !orphanMv });
    const invIds = new Set(S.inv.map(i => i.id)), purIds = new Set(S.pur.map(i => i.id)), expIds = new Set(S.exp.map(i => i.id));
    const orphanCash = S.cash.filter(c => c.ref && ((c.ref.t === 'inv' && !invIds.has(c.ref.id)) || (c.ref.t === 'pur' && !purIds.has(c.ref.id)) || (c.ref.t === 'exp' && !expIds.has(c.ref.id)))).length;
    checks.push({ name: 'كل قيد نقدي مرتبط بمستند موجود', expected: 0, actual: orphanCash, ok: !orphanCash });
    let badExp = 0;
    S.exp.forEach(e => { const s = sum(S.cash.filter(c => c.ref && c.ref.t === 'exp' && c.ref.id === e.id).map(c => c.amt)); if (s !== (e.void ? 0 : -e.a)) badExp++; });
    checks.push({ name: 'كل مصروف له قيد نقدي مطابق لقيمته', expected: 0, actual: badExp, ok: !badExp });
    let badRet = 0;
    [S.inv, S.pur].forEach(list => list.forEach(d => { const rq = {}; (d.rt || []).filter(r => !r.void).forEach(r => r.lines.forEach(l => { rq[l.k] = (rq[l.k] || 0) + l.q; })); d.items.forEach((x, k) => { if ((rq[k] || 0) > x.q) badRet++; }); }));
    checks.push({ name: 'لا مرتجع يتجاوز الكمية المباعة/المشتراة', expected: 0, actual: badRet, ok: !badRet });
    // إجماليات متقاطعة: رصيد الصندوق = مجموع قيوده بحسب النوع
    const cashTotal = sum(S.cash.map(c => c.amt));
    const byKind = {}; S.cash.forEach(c => { byKind[c.kind] = (byKind[c.kind] || 0) + c.amt; });
    checks.push({ name: 'رصيد الصندوق = مجموع الحركات حسب النوع', expected: cashTotal, actual: sum(Object.values(byKind)), ok: cashTotal === sum(Object.values(byKind)) });
    // مجموع أرصدة العملاء = مجموع المستحق في الفواتير النشطة
    const pm = paidMap(S);
    const dueAll = {}; S.inv.forEach(i => { if (i.void) return; const v = invView(S, i, pm); dueAll[i.cur] = (dueAll[i.cur] || 0) + v.due; });
    const dueCust = {}; Object.values(balances(S, 'cust')).forEach(o => Object.entries(o).forEach(([k, v]) => { dueCust[k] = (dueCust[k] || 0) + v; }));
    const dueCash = {}; S.inv.forEach(i => { if (!i.void && !i.c) { const v = invView(S, i, pm); dueCash[i.cur] = (dueCash[i.cur] || 0) + v.due; } });
    const cmp = {}; Object.keys(dueAll).forEach(k => { cmp[k] = dueAll[k] - ((dueCust[k] || 0) + (dueCash[k] || 0)); });
    const cmpBad = Object.values(cmp).filter(v => v !== 0).length;
    checks.push({ name: 'مجموع أرصدة العملاء = مجموع المستحق في الفواتير', expected: 0, actual: cmpBad, ok: !cmpBad });
    // سلسلة التدقيق
    checks.push({ name: 'سجل التدقيق سليم (لم يُعدَّل)', expected: true, actual: auditOk(S), ok: auditOk(S) });
    return checks;
  }
  function reconcileQuick(S) { // للمعاملات: يرجع رسائل الأخطاء فقط
    return reconcileList(S).filter(c => !c.ok && c.name.indexOf('التدقيق') < 0).map(c => c.name + (c.detail ? ' (' + c.detail + ')' : ''));
  }

  function auditRec(S, by, action, ref, summary, ts) {
    const prev = S.audit.length ? S.audit[S.audit.length - 1].h : '0';
    const rec = { n: S.audit.length + 1, ts, by: by == null ? null : by, a: action, ref: ref || null, s: summary || '' };
    rec.h = hash53(prev + '|' + rec.n + '|' + rec.ts + '|' + rec.by + '|' + rec.a + '|' + JSON.stringify(rec.ref) + '|' + rec.s);
    S.audit.push(rec);
  }
  function auditOk(S) {
    let prev = '0';
    for (const r of S.audit) {
      const h = hash53(prev + '|' + r.n + '|' + r.ts + '|' + r.by + '|' + r.a + '|' + JSON.stringify(r.ref) + '|' + r.s);
      if (h !== r.h) return false; prev = r.h;
    }
    return true;
  }

  /* ---------------- كلمات السر ---------------- */
  const subtle = () => (globalThis.crypto && globalThis.crypto.subtle) || null;
  const b64 = u8 => { let s = ''; u8.forEach(b => { s += String.fromCharCode(b); }); return btoa(s); };
  const unb64 = s => Uint8Array.from(atob(s), c => c.charCodeAt(0));
  const ITER = 210000;
  async function hashPw(pw, saltB64, iter) {
    if (!subtle()) throw err('التشفير غير متاح في هذه البيئة');
    const salt = saltB64 ? unb64(saltB64) : crypto.getRandomValues(new Uint8Array(16));
    const key = await subtle().importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveBits']);
    const bits = await subtle().deriveBits({ name: 'PBKDF2', hash: 'SHA-512', salt, iterations: iter || ITER }, key, 512);
    return { algo: 'pbkdf2-sha512', iter: iter || ITER, salt: b64(salt), hash: b64(new Uint8Array(bits)) };
  }
  async function legacyHash(p) { // نفس دالة النسخة القديمة (للتوافق مع كلمات السر الحالية)
    try { const b = await subtle().digest('SHA-256', new TextEncoder().encode('aq:' + p)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join(''); }
    catch (e) { let h = 5381; for (const c of 'aq:' + p) h = (h * 33 ^ c.charCodeAt(0)) >>> 0; return 'x' + h; }
  }
  const sameHash = (a, b) => a.length === b.length && [...a].every((c, i) => c === b[i]);

  /* ---------------- المحرك ---------------- */
  class Engine {
    constructor(state, opt) {
      opt = opt || {};
      this.S = state;
      this.persist = opt.persist || function () {};
      this._now = opt.now || (() => new Date());
      this._uid = opt.uid || defaultUid;
    }
    now() { return this._now(); }
    ts() { return this.now().toISOString(); }
    today() { return localDate(this.now()); }
    uid() { return this._uid(); }

    /* المعاملة الذرية: نسخة → تنفيذ → فحص اتساق → كتابة → اعتماد */
    tx(fn) {
      const D = JSON.parse(JSON.stringify(this.S));
      const res = fn(D);
      const bad = reconcileQuick(D);
      if (bad.length) throw err('أُلغيت العملية لأن فحص الاتساق فشل: ' + bad[0], 'reconcile');
      this.persist(JSON.stringify(D));
      this.S = D;
      return res;
    }
    log(D, by, action, ref, summary) { auditRec(D, by, action, ref, summary, this.ts()); }
    stampDate(d) { d = d || this.today(); if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) throw err('تاريخ غير صالح'); return d; }

    /* ======== المنتجات ======== */
    _checkBc(D, bc, selfId) {
      if (bc === '' || bc == null) return '';
      const cur = selfId && D.prod.find(p => p.id === selfId);
      if (cur && cur.bc === String(bc)) return cur.bc; // باركود مستورد يبقى كما هو عند التعديل
      if (!/^[A-Za-z0-9+\-._\/$%]{1,32}$/.test(String(bc))) throw err('الباركود: أرقام وحروف إنجليزية فقط (ويسمح بـ - . + / $ %) حتى 32 خانة', 'bc');
      if (D.prod.some(p => p.bc.toLowerCase() === String(bc).toLowerCase() && p.id !== selfId)) throw err('الباركود مستخدم لمنتج آخر', 'bc');
      return String(bc);
    }
    addProduct(o) {
      return this.tx(D => {
        need(D, o.user, 'prod');
        if (!o.n || !String(o.n).trim()) throw err('اسم المنتج مطلوب');
        const pr = o.pr || 0, co = o.co || 0, q = o.q || 0, mn = o.mn || 0;
        if (![pr, co, q, mn].every(isInt) || pr < 0 || co < 0 || q < 0 || mn < 0) throw err('قيمة غير صحيحة في بيانات المنتج');
        const p = { id: this.uid(), n: String(o.n).trim(), bc: this._checkBc(D, o.bc), pr, co, q, mn, brand: o.brand || '', model: o.model || '', cat: o.cat || '', img: o.img || '' };
        D.prod.push(p);
        if (q) D.mv.push({ id: this.uid(), ts: this.ts(), p: p.id, dq: q, kind: 'open', ref: null, by: o.user || null });
        this.log(D, o.user, 'prod.add', { t: 'prod', id: p.id }, p.n);
        return p.id;
      });
    }
    updateProduct(id, o) {
      return this.tx(D => {
        need(D, o.user, 'prod');
        const p = D.prod.find(x => x.id === id); if (!p) throw err('المنتج غير موجود');
        const ch = [];
        ['n', 'brand', 'model', 'cat', 'img'].forEach(k => { if (o[k] !== undefined && o[k] !== p[k]) { ch.push(k); p[k] = o[k]; } });
        if (!p.n.trim()) throw err('اسم المنتج مطلوب');
        if (o.bc !== undefined) { const bc = this._checkBc(D, o.bc, id); if (bc !== p.bc) { ch.push('bc'); p.bc = bc; } }
        ['pr', 'co', 'mn'].forEach(k => { if (o[k] !== undefined && o[k] !== p[k]) { if (!isInt(o[k]) || o[k] < 0) throw err('قيمة غير صحيحة'); ch.push(k + ':' + p[k] + '→' + o[k]); p[k] = o[k]; } });
        if (o.q !== undefined && o.q !== p.q) {
          need(D, o.user, 'stock');
          if (!isInt(o.q) || o.q < 0) throw err('الكمية غير صحيحة');
          D.mv.push({ id: this.uid(), ts: this.ts(), p: p.id, dq: o.q - p.q, kind: 'adjust', ref: null, by: o.user || null, note: o.note || '' });
          ch.push('q:' + p.q + '→' + o.q); p.q = o.q;
        }
        if (ch.length) this.log(D, o.user, 'prod.edit', { t: 'prod', id }, p.n + ' [' + ch.join(', ') + ']');
        return id;
      });
    }
    /* جرد المخزون: يُدخل المستخدم الكمية المعدودة فعليًا لكل منتج، فتُسوّى الفروقات بحركة مخزون من نوع «جرد» (لا تعديل مباشر للأرصدة) مع محضر جرد دائم CNT-xxxx.
     * o: { items:[{p, counted, sys?}], date?, note?, user } — sys = الكمية التي رآها المستخدم؛ إن تغيّرت (بيع أثناء الجرد) يُرفض الحفظ بدل تسوية خاطئة. */
    stocktake(o) {
      return this.tx(D => {
        need(D, o.user, 'stock');
        if (!Array.isArray(o.items) || !o.items.length) throw err('لم تُدخل أي كمية مجرودة');
        D.cnt = D.cnt || []; D.seq.cnt = D.seq.cnt || (D.cnt.length + 1);
        const seen = new Set(), lines = [];
        o.items.forEach(it => {
          const p = D.prod.find(x => x.id === it.p); if (!p) throw err('منتج غير موجود في الجرد');
          if (seen.has(p.id)) throw err('المنتج مكرر في الجرد: ' + p.n); seen.add(p.id);
          if (!isInt(it.counted) || it.counted < 0) throw err('كمية الجرد غير صحيحة: ' + p.n);
          if (it.sys !== undefined && it.sys !== p.q) throw err('تغيّر مخزون «' + p.n + '» أثناء الجرد (بيع أو شراء). أعد تحميل الجرد ثم اعتمده.', 'stale');
          lines.push({ p: p.id, n: p.n, bc: p.bc || '', sys: p.q, cnt: it.counted, diff: it.counted - p.q, co: p.co });
        });
        const valDiff = sum(lines.filter(l => l.diff !== 0).map(l => (l.diff < 0 ? -1 : 1) * M.lineTotal(l.co, Math.abs(l.diff))));
        const rec = { id: this.uid(), no: 'CNT-' + pad(D.seq.cnt++, 4), date: this.stampDate(o.date), ts: this.ts(), by: o.user || null, note: String(o.note || '').trim().slice(0, 200), lines, valDiff };
        lines.filter(l => l.diff !== 0).forEach(l => {
          D.mv.push({ id: this.uid(), ts: this.ts(), p: l.p, dq: l.diff, kind: 'count', ref: { t: 'cnt', id: rec.id }, by: o.user || null, note: rec.no });
          D.prod.find(x => x.id === l.p).q = l.cnt;
        });
        D.cnt.push(rec);
        const ch = lines.filter(l => l.diff !== 0).length;
        this.log(D, o.user, 'stock.count', { t: 'cnt', id: rec.id }, rec.no + ' — ' + lines.length + ' منتج، ' + ch + ' فرق، قيمة الفروقات ' + M.fmt(valDiff, decOf(D, D.set.base)) + ' ' + D.set.base);
        return { id: rec.id, no: rec.no, counted: lines.length, changed: ch, valDiff };
      });
    }
    /* حذف آمن: يُحذف فعليًا فقط ما لم يُستخدم، وإلا يُؤرشف */
    removeEntity(kind, id, user) {
      return this.tx(D => {
        const perm = kind === 'prod' ? 'prod' : 'party';
        need(D, user, perm);
        const list = D[kind]; const e = list.find(x => x.id === id); if (!e) throw err('العنصر غير موجود');
        let used = false;
        if (kind === 'prod') used = D.inv.some(i => i.items.some(x => x.p === id)) || D.pur.some(i => i.items.some(x => x.p === id)) || D.mv.some(m => m.p === id && m.kind !== 'open');
        if (kind === 'cust') used = D.inv.some(i => i.c === id);
        if (kind === 'rep') used = D.inv.some(i => i.r === id);
        if (kind === 'sup') used = D.pur.some(i => i.s === id);
        if (used) { e.arch = true; this.log(D, user, kind + '.archive', { t: kind, id }, e.n); return 'archived'; }
        if (kind === 'prod') D.mv = D.mv.filter(m => m.p !== id);
        D[kind] = list.filter(x => x.id !== id);
        this.log(D, user, kind + '.delete', { t: kind, id }, e.n);
        return 'deleted';
      });
    }
    addParty(kind, o) {
      return this.tx(D => {
        need(D, o.user, 'party');
        if (!o.n || !String(o.n).trim()) throw err('الاسم مطلوب');
        const e = { id: this.uid(), n: String(o.n).trim(), ph: o.ph || '', ad: o.ad || '' };
        if (kind === 'rep') { e.r = o.r || 0; if (!isInt(e.r) || e.r < 0 || e.r > 10000) throw err('النسبة بين 0 و 100'); delete e.ph; delete e.ad; }
        D[kind].push(e); this.log(D, o.user, kind + '.add', { t: kind, id: e.id }, e.n); return e.id;
      });
    }
    updateParty(kind, id, o) {
      return this.tx(D => {
        need(D, o.user, 'party');
        const e = D[kind].find(x => x.id === id); if (!e) throw err('العنصر غير موجود');
        ['n', 'ph', 'ad'].forEach(k => { if (o[k] !== undefined) e[k] = o[k]; });
        if (kind === 'rep' && o.r !== undefined) { if (!isInt(o.r) || o.r < 0 || o.r > 10000) throw err('النسبة بين 0 و 100'); e.r = o.r; }
        if (!String(e.n).trim()) throw err('الاسم مطلوب');
        this.log(D, o.user, kind + '.edit', { t: kind, id }, e.n); return id;
      });
    }

    /* ======== مساعد: تجهيز بنود مستند ======== */
    _items(D, o, key, isSale) {
      if (!Array.isArray(o.items) || !o.items.length) throw err('أضف بندًا واحدًا على الأقل');
      const base = D.set.base, dB = decOf(D, base), dC = decOf(D, o.cur);
      return o.items.map(x => {
        const p = D.prod.find(z => z.id === x.p); if (!p) throw err('منتج غير موجود في أحد البنود');
        if (p.arch && !o.allowArch) throw err('المنتج مؤرشف: ' + p.n);
        if (!isInt(x.q) || x.q <= 0) throw err('الكمية يجب أن تكون أكبر من صفر: ' + p.n);
        if (!isInt(x[key]) || x[key] < 0) throw err('السعر غير صحيح: ' + p.n);
        const it = { p: p.id, n: p.n, q: x.q, [key]: x[key] };
        if (isSale) {
          it.co = x.co != null ? x.co : p.co;
          const def = o.cur === base ? p.pr : M.fromBase(p.pr, dB, dC, o.fx);
          if (x.pr !== def) need(D, o.user, 'price');
        }
        return it;
      });
    }
    _stockCheck(D, items, user, restore) {
      const need_ = {}; items.forEach(x => { need_[x.p] = (need_[x.p] || 0) + x.q; });
      Object.keys(need_).forEach(id => {
        const p = D.prod.find(z => z.id === id);
        const avail = p.q + ((restore && restore[id]) || 0);
        if (need_[id] > avail && !D.set.negStock && !canOverride(D, user, 'negstock'))
          throw err('الكمية غير كافية في المخزون: ' + p.n + ' (المتاح ' + M.fmtQty(avail) + ')', 'stock');
      });
    }
    _discCheck(D, o, sub) {
      const d = o.disc || 0;
      if (!isInt(d) || d < 0) throw err('الخصم غير صحيح');
      if (d > sub) throw err('الخصم أكبر من مجموع الفاتورة');
      if (d > 0) {
        need(D, o.user, 'disc');
        const u = o.user != null ? findUser(D, o.user) : null;
        const maxD = u ? (u.maxDisc != null ? u.maxDisc : 10000) : 10000;
        if (sub > 0 && BigInt(d) * 10000n > BigInt(sub) * BigInt(maxD)) throw err('الخصم أكبر من الحد المسموح لك (' + M.fmtPct(maxD) + '%)', 'disc');
      }
      return d;
    }
    _mv(D, p, dq, kind, ref, by) { D.mv.push({ id: this.uid(), ts: this.ts(), p, dq, kind, ref, by: by || null }); }
    _cashEntry(D, o) {
      if (!isInt(o.amt) || o.amt === 0) throw err('مبلغ غير صحيح');
      D.cash.push({ id: this.uid(), ts: this.ts(), date: o.date, cur: o.cur, amt: o.amt, fx: o.fx, kind: o.kind, ref: o.ref || null, method: o.method || 'cash', by: o.by || null, note: o.note || '' });
    }

    /* ======== البيع ======== */
    createSale(o) {
      if (!o.req) throw err('معرّف الطلب مطلوب لمنع التكرار', 'req');
      const dup = this.S.inv.find(x => x.req === o.req);
      if (dup) return { dup: true, id: dup.id, no: dup.no };
      return this.tx(D => this._saleD(D, o));
    }
    _saleD(D, o) { // منطق إصدار فاتورة بيع داخل معاملة قائمة (يُستخدم من createSale ومن تحويل عرض السعر ذريًا)
        need(D, o.user, 'sell');
        const date = this.stampDate(o.date);
        const cur = o.cur || D.set.base; o = Object.assign({}, o, { cur });
        const fx = fxFor(D, cur, o.fx); o.fx = fx;
        const items = this._items(D, o, 'pr', true);
        const cust = o.c ? D.cust.find(x => x.id === o.c) : null; if (o.c && (!cust || cust.arch)) throw err('العميل غير موجود');
        const rep = o.r ? D.rep.find(x => x.id === o.r) : null; if (o.r && (!rep || rep.arch)) throw err('المندوب غير موجود');
        const sub = sum(items.map(x => M.lineTotal(x.pr, x.q)));
        const disc = this._discCheck(D, o, sub);
        const inv = { id: this.uid(), no: 'INV-' + pad(D.seq.inv++, 4), req: o.req, date, ts: this.ts(), c: cust ? cust.id : '', cn: cust ? cust.n : 'عميل نقدي', r: rep ? rep.id : '', rn: rep ? rep.n : '', cur, fx, items, disc, rate: o.rate != null ? o.rate : D.set.taxBp, rt: [], by: o.user || null, note: o.note || '' };
        { const ex = normEx(o.ex); if (ex.length) inv.ex = ex; }
        const c = calcInv(inv);
        const pay = o.pay || { amt: 0 };
        if (!isInt(pay.amt) || pay.amt < 0) throw err('المبلغ المدفوع غير صحيح');
        if (pay.amt > c.tot) throw err('المدفوع أكبر من الإجمالي', 'pay');
        if (pay.amt < c.tot && !inv.c && !D.set.cashDebt) throw err('البيع بالآجل يتطلب اختيار عميل', 'debt');
        this._stockCheck(D, items, o.user);
        items.forEach(x => { D.prod.find(p => p.id === x.p).q -= x.q; this._mv(D, x.p, -x.q, 'sale', { t: 'inv', id: inv.id }, o.user); });
        D.inv.push(inv);
        if (pay.amt > 0) this._cashEntry(D, { date, cur, amt: pay.amt, fx, kind: 'sale', ref: { t: 'inv', id: inv.id }, method: pay.method, by: o.user });
        this.log(D, o.user, 'sale.create', { t: 'inv', id: inv.id }, inv.no + ' إجمالي ' + M.fmt(c.tot, decOf(D, cur)) + ' ' + cur);
        return { id: inv.id, no: inv.no, tot: c.tot, paid: pay.amt };
    }

    /* ======== عروض الأسعار ========
     * وثيقة تسعير فقط: لا تحجز مخزونًا ولا تدخل في المبيعات أو الأرباح أو الذمم حتى تُحوَّل إلى فاتورة.
     * الحالات: open (مفتوح) | converted (حُوِّل لفاتورة، ويُحفظ رقمها) | cancelled (ملغى مع السبب). لا حذف أبدًا. */
    _quoteFields(D, o, qt) {
      const cur = o.cur || (qt && qt.cur) || D.set.base, oo = Object.assign({}, o, { cur });
      const fx = fxFor(D, cur, o.fx != null ? o.fx : (qt && qt.cur === cur ? qt.fx : undefined)); oo.fx = fx;
      const items = this._items(D, oo, 'pr', true).map(x => ({ p: x.p, n: x.n, q: x.q, pr: x.pr }));
      const cid = o.c !== undefined ? o.c : (qt ? qt.c : '');
      const cust = cid ? D.cust.find(x => x.id === cid) : null; if (cid && (!cust || (cust.arch && !(qt && qt.c === cid)))) throw err('العميل غير موجود');
      const sub = sum(items.map(x => M.lineTotal(x.pr, x.q)));
      const disc = this._discCheck(D, oo, sub);
      const date = this.stampDate(o.date || (qt && qt.date));
      let valid = o.valid;
      if (!valid) { const d = new Date(date + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + (isInt(o.days) && o.days > 0 && o.days <= 365 ? o.days : 15)); valid = d.toISOString().slice(0, 10); }
      if (!/^\d{4}-\d{2}-\d{2}$/.test(valid) || valid < date) throw err('تاريخ صلاحية العرض يجب ألا يسبق تاريخ العرض');
      const f = { date, valid, c: cust ? cust.id : '', cn: cust ? cust.n : (o.cn ? String(o.cn).trim().slice(0, 80) : 'عميل نقدي'), cur, fx, items, disc, rate: o.rate != null ? o.rate : (qt ? qt.rate : D.set.taxBp), note: String(o.note || '').trim().slice(0, 300) };
      const ex = normEx(o.ex); f.ex = ex;
      return f;
    }
    createQuote(o) {
      if (!o.req) throw err('معرّف الطلب مطلوب لمنع التكرار', 'req');
      const dup = (this.S.qt || []).find(x => x.req === o.req); if (dup) return { dup: true, id: dup.id, no: dup.no };
      return this.tx(D => {
        need(D, o.user, 'sell'); D.qt = D.qt || []; D.seq.qt = D.seq.qt || (D.qt.length + 1);
        const f = this._quoteFields(D, o, null);
        const qt = Object.assign({ id: this.uid(), no: 'QT-' + pad(D.seq.qt++, 4), req: o.req, ts: this.ts(), by: o.user || null, status: 'open', edits: 0 }, f);
        D.qt.push(qt);
        this.log(D, o.user, 'quote.create', { t: 'qt', id: qt.id }, qt.no + ' — ' + qt.cn);
        return { id: qt.id, no: qt.no, tot: calcDoc(qt, 'pr').tot };
      });
    }
    updateQuote(id, o) {
      return this.tx(D => {
        need(D, o.user, 'sell');
        const qt = (D.qt || []).find(x => x.id === id); if (!qt) throw err('عرض السعر غير موجود');
        if (qt.status !== 'open') throw err('لا يمكن تعديل عرض ' + (qt.status === 'converted' ? 'حُوِّل إلى فاتورة' : 'ملغى'));
        const f = this._quoteFields(D, o, qt); Object.assign(qt, f); qt.edits = (qt.edits || 0) + 1; qt.mts = this.ts();
        this.log(D, o.user, 'quote.edit', { t: 'qt', id }, qt.no);
        return { id, no: qt.no, tot: calcDoc(qt, 'pr').tot };
      });
    }
    cancelQuote(id, o) {
      return this.tx(D => {
        need(D, o.user, 'sell');
        const qt = (D.qt || []).find(x => x.id === id); if (!qt) throw err('عرض السعر غير موجود');
        if (qt.status !== 'open') throw err('العرض ليس مفتوحًا');
        const reason = String(o.reason || '').trim(); if (!reason) throw err('سبب الإلغاء مطلوب');
        qt.status = 'cancelled'; qt.cancel = { ts: this.ts(), by: o.user || null, reason: reason.slice(0, 200) };
        this.log(D, o.user, 'quote.cancel', { t: 'qt', id }, qt.no + ' — ' + reason);
        return { id, no: qt.no };
      });
    }
    /* تحويل عرض مفتوح إلى فاتورة بيع في معاملة واحدة: إمّا تُصدر الفاتورة ويُغلق العرض معًا أو لا يحدث أيٌّ منهما.
     * s = معاملات البيع كما في createSale (البنود/الدفع/الخصم... قد يعدّلها المستخدم قبل الإصدار). req إلزامي. */
    convertQuote(id, s) {
      if (!s || !s.req) throw err('معرّف الطلب مطلوب لمنع التكرار', 'req');
      return this.tx(D => {
        const qt = (D.qt || []).find(x => x.id === id); if (!qt) throw err('عرض السعر غير موجود');
        if (qt.status === 'converted') { const iv = D.inv.find(x => x.id === qt.inv); if (iv && iv.req === s.req) return { dup: true, id: iv.id, no: iv.no, tot: calcInv(iv).tot, paid: 0 }; throw err('هذا العرض حُوِّل سابقًا إلى الفاتورة ' + qt.invNo); }
        if (qt.status !== 'open') throw err('العرض ملغى ولا يمكن تحويله');
        const r = this._saleD(D, Object.assign({}, s, { note: s.note != null ? s.note : ('من عرض سعر ' + qt.no + (qt.note ? ' — ' + qt.note : '')) }));
        qt.status = 'converted'; qt.inv = r.id; qt.invNo = r.no; qt.conv = { ts: this.ts(), by: s.user || null };
        this.log(D, s.user, 'quote.convert', { t: 'qt', id }, qt.no + ' ← ' + r.no);
        return r;
      });
    }
    /* تعديل شامل لفاتورة بيع بعد إصدارها (البنود، الأسعار، الخصم، العميل، المندوب، التاريخ، الملاحظة، المدفوع).
     * لا تُحذف الفاتورة ولا تتغير عملتها أو سعر صرفها أو رقمها. كل تعديل يُسجَّل في inv.rev (الحالة قبل التعديل) وفي سجل التدقيق.
     * o: { items:[{k?,p,q,pr}], disc, c, r, date, note, reason, paid?, method?, payDate?, user } — k = رقم البند الأصلي (للبنود الموجودة). */
    amendSale(id, o) {
      return this.tx(D => {
        need(D, o.user, 'invedit');
        const inv = D.inv.find(x => x.id === id); if (!inv) throw err('الفاتورة غير موجودة');
        if (inv.void) throw err('الفاتورة ملغاة ولا تُعدَّل');
        if (!Array.isArray(o.items) || !o.items.length) throw err('أضف بندًا واحدًا على الأقل');
        const cur = inv.cur, dec = decOf(D, cur), base = D.set.base, dB = decOf(D, base);
        const oldC = calcInv(inv), oldTot = oldC.totEff;
        const live = (inv.rt || []).filter(r => !r.void);
        const rq = inv.items.map(() => 0); live.forEach(r => r.lines.forEach(l => { rq[l.k] += l.q; }));
        const usedRet = inv.items.map(() => false); (inv.rt || []).forEach(r => r.lines.forEach(l => { usedRet[l.k] = true; }));
        const before = { items: inv.items.map(x => Object.assign({}, x)), disc: inv.disc, c: inv.c, cn: inv.cn, r: inv.r, rn: inv.rn, date: inv.date, note: inv.note || '', ex: (inv.ex || []).map(e => Object.assign({}, e)), tot: oldTot, paid: sum(D.cash.filter(e => e.ref && e.ref.t === 'inv' && e.ref.id === id).map(e => e.amt)) };
        // 1) البنود الجديدة
        const seenK = new Set(), items = [], map = {};
        o.items.forEach(x => {
          const p = D.prod.find(z => z.id === x.p); if (!p) throw err('منتج غير موجود في أحد البنود');
          if (!isInt(x.q) || x.q <= 0) throw err('الكمية يجب أن تكون أكبر من صفر: ' + p.n);
          if (!isInt(x.pr) || x.pr < 0) throw err('السعر غير صحيح: ' + p.n);
          const old = x.k != null ? inv.items[x.k] : null;
          if (x.k != null && !old) throw err('بند غير موجود في الفاتورة الأصلية');
          if (old) {
            if (seenK.has(x.k)) throw err('بند مكرر');
            seenK.add(x.k);
            if (old.p !== x.p && usedRet[x.k]) throw err('لا يمكن تغيير منتج بند له مرتجعات: ' + old.n);
            if (x.q < rq[x.k]) throw err('الكمية أقل من المرتجع المسجل لهذا البند (' + M.fmtQty(rq[x.k]) + '): ' + old.n);
          } else if (p.arch) throw err('المنتج مؤرشف: ' + p.n);
          const same = old && old.p === x.p && old.pr === x.pr;
          if (!same) { const def = cur === base ? p.pr : M.fromBase(p.pr, dB, dec, inv.fx); if (x.pr !== def) need(D, o.user, 'price'); }
          const it = { p: p.id, n: old && old.p === x.p ? old.n : p.n, q: x.q, pr: x.pr, co: old && old.p === x.p ? old.co : p.co };
          if (old) map[x.k] = items.length;
          items.push(it);
        });
        inv.items.forEach((x, k) => { if (!(k in map)) { if (usedRet[k]) throw err('لا يمكن حذف بند له مرتجعات: ' + x.n); } });
        // 2) المخزون (الفرق الصافي لكل منتج؛ المرتجعات سبق أن أعادت كمياتها)
        const restore = {}, diff = {};
        inv.items.forEach(x => { restore[x.p] = (restore[x.p] || 0) + x.q; diff[x.p] = (diff[x.p] || 0) + x.q; });
        items.forEach(x => { diff[x.p] = (diff[x.p] || 0) - x.q; });
        this._stockCheck(D, items, o.user, restore);
        Object.keys(diff).forEach(p => { if (diff[p]) { D.prod.find(z => z.id === p).q += diff[p]; this._mv(D, p, diff[p], 'sale-edit', { t: 'inv', id }, o.user); } });
        // 3) بقية الحقول
        const cid = o.c === undefined ? inv.c : o.c, rid = o.r === undefined ? inv.r : o.r;
        const cust = cid ? D.cust.find(x => x.id === cid) : null; if (cid && !cust) throw err('العميل غير موجود');
        if (cust && cust.arch && cust.id !== inv.c) throw err('العميل مؤرشف');
        const rep = rid ? D.rep.find(x => x.id === rid) : null; if (rid && !rep) throw err('المندوب غير موجود');
        const sub = sum(items.map(x => M.lineTotal(x.pr, x.q)));
        const dv = o.disc == null ? inv.disc : o.disc;
        if (!isInt(dv) || dv < 0) throw err('الخصم غير صحيح');
        if (dv > sub) throw err('الخصم أكبر من مجموع الفاتورة');
        if (dv !== inv.disc) { if (dv > 0) this._discCheck(D, { disc: dv, user: o.user }, sub); else need(D, o.user, 'disc'); }
        inv.rt = (inv.rt || []).map(r => Object.assign({}, r, { lines: r.lines.map(l => ({ k: map[l.k], q: l.q })) }));
        inv.items = items; inv.disc = dv;
        inv.c = cust ? cust.id : ''; inv.cn = cust ? cust.n : 'عميل نقدي'; inv.r = rep ? rep.id : ''; inv.rn = rep ? rep.n : '';
        if (o.date) {
          const nd = this.stampDate(o.date);
          if (nd !== inv.date) { // دفعة البيع الأصلية (عند إصدار الفاتورة) تتبع تاريخ الفاتورة المصحَّح كي لا يختل «المحصّل اليومي»؛ أصل التاريخ محفوظ في odate، والدفعات اللاحقة تبقى بتواريخها
            D.cash.forEach(e => { if (e.kind === 'sale' && e.ref && e.ref.t === 'inv' && e.ref.id === id && e.date === inv.date) { e.odate = e.odate || e.date; e.date = nd; } });
            inv.date = nd;
          }
        }
        if (o.note !== undefined) inv.note = String(o.note).slice(0, 500);
        if (o.ex !== undefined) { const ex = normEx(o.ex); if (ex.length) inv.ex = ex; else delete inv.ex; }
        const newC = calcInv(inv), newTot = newC.totEff;
        // 4) الدفعات: تسوية المدفوع الكلي بقيد تحصيل أو رد (لا يُعدَّل أي قيد سابق)
        let paid = before.paid;
        if (o.paid != null) {
          if (!isInt(o.paid) || o.paid < 0) throw err('المدفوع غير صحيح');
          if (o.paid > newTot) throw err('المدفوع أكبر من إجمالي الفاتورة بعد التعديل', 'pay');
          const d = o.paid - before.paid;
          if (d !== 0) {
            need(D, o.user, 'collect');
            this._cashEntry(D, { date: this.stampDate(o.payDate), cur, amt: d, fx: inv.fx, kind: d > 0 ? 'collect' : 'refund', ref: { t: 'inv', id }, method: o.method || 'cash', by: o.user, note: 'تسوية بعد تعديل ' + inv.no });
            paid = o.paid;
          }
        }
        if (!inv.c && paid > newTot) throw err('الإجمالي بعد التعديل أقل من المدفوع (' + M.fmt(paid, dec) + '). فاتورة بدون عميل مسجَّل: عدّل «المدفوع» ليساوي الإجمالي الجديد (يُسجَّل الفرق كرد نقدي).', 'pay');
        if (!inv.c && paid < newTot && !D.set.cashDebt) throw err('البيع بالآجل يتطلب اختيار عميل', 'debt');
        // 5) سجل التعديلات
        const f_ = v => M.fmt(v, dec);
        inv.rev = (inv.rev || []).concat([{ id: this.uid(), ts: this.ts(), by: o.user || null, reason: String(o.reason || '').trim().slice(0, 200), before, after: { tot: newTot, paid } }]);
        this.log(D, o.user, 'sale.edit', { t: 'inv', id }, inv.no + ' الإجمالي ' + f_(oldTot) + ' ← ' + f_(newTot) + ' ' + cur + (paid !== before.paid ? ' | المدفوع ' + f_(before.paid) + ' ← ' + f_(paid) : '') + (o.reason ? ' | ' + String(o.reason).trim().slice(0, 100) : ''));
        return { id, tot: newTot, paid, due: newTot - paid };
      });
    }
    editSale(id, o) { // للتوافق: يمرّر إلى amendSale (البنود بلا k تُعتبر جديدة، لذا نطابقها بالترتيب والمنتج)
      const inv = this.S.inv.find(x => x.id === id), taken = new Set();
      const items = (o.items || []).map(x => { if (x.k != null || !inv) return x; const k = inv.items.findIndex((y, j) => !taken.has(j) && y.p === x.p); if (k >= 0) taken.add(k); return k >= 0 ? Object.assign({}, x, { k }) : x; });
      return this.amendSale(id, Object.assign({}, o, { items }));
    }

    collect(id, amt, method, user, date) {
      return this.tx(D => {
        need(D, user, 'collect');
        const inv = D.inv.find(x => x.id === id); if (!inv || inv.void) throw err('الفاتورة غير متاحة');
        const v = invView(D, inv);
        if (!isInt(amt) || amt <= 0) throw err('مبلغ غير صحيح');
        if (amt > v.due) throw err('المبلغ أكبر من المتبقي (' + M.fmt(v.due, decOf(D, inv.cur)) + ')', 'pay');
        this._cashEntry(D, { date: this.stampDate(date), cur: inv.cur, amt, fx: inv.fx, kind: 'collect', ref: { t: 'inv', id }, method, by: user });
        this.log(D, user, 'sale.collect', { t: 'inv', id }, inv.no + ' ' + M.fmt(amt, decOf(D, inv.cur)));
        return true;
      });
    }
    refundCustomer(id, amt, method, user, date) { // رد رصيد دائن للعميل نقدًا
      return this.tx(D => {
        need(D, user, 'collect');
        const inv = D.inv.find(x => x.id === id); if (!inv || inv.void) throw err('الفاتورة غير متاحة');
        const v = invView(D, inv);
        if (!isInt(amt) || amt <= 0) throw err('مبلغ غير صحيح');
        if (amt > -v.due) throw err('المبلغ أكبر من الرصيد الدائن للعميل', 'pay');
        this._cashEntry(D, { date: this.stampDate(date), cur: inv.cur, amt: -amt, fx: inv.fx, kind: 'refund', ref: { t: 'inv', id }, method, by: user });
        this.log(D, user, 'sale.refund', { t: 'inv', id }, inv.no + ' ' + M.fmt(amt, decOf(D, inv.cur)));
        return true;
      });
    }
    /* تحصيل دفعة من عميل وتوزيعها على فواتيره الأقدم فالأحدث (معاملة واحدة، عملة واحدة) */
    collectParty(custId, cur, amt, method, user, date) {
      return this.tx(D => {
        need(D, user, 'collect');
        if (!D.cust.some(c => c.id === custId)) throw err('العميل غير موجود');
        if (!isInt(amt) || amt <= 0) throw err('مبلغ غير صحيح');
        const dt = this.stampDate(date), pm = paidMap(D);
        const open = D.inv.filter(i => i.c === custId && !i.void && i.cur === cur).sort((a, b) => (a.date + a.ts < b.date + b.ts ? -1 : 1))
          .map(i => ({ i, due: invView(D, i, pm).due })).filter(x => x.due > 0);
        const total = sum(open.map(x => x.due));
        if (amt > total) throw err('المبلغ أكبر من المستحق على العميل بهذه العملة (' + M.fmt(total, decOf(D, cur)) + ')', 'pay');
        let left = amt; const parts = [];
        open.forEach(x => {
          if (left <= 0) return; const a = Math.min(left, x.due); left -= a; parts.push({ no: x.i.no, a });
          this._cashEntry(D, { date: dt, cur, amt: a, fx: x.i.fx, kind: 'collect', ref: { t: 'inv', id: x.i.id }, method, by: user });
        });
        this.log(D, user, 'cust.collect', { t: 'cust', id: custId }, M.fmt(amt, decOf(D, cur)) + ' ' + cur);
        return { applied: amt, parts, date: dt };
      });
    }
    /* سداد دفعة لمورد وتوزيعها على فواتير الشراء الأقدم فالأحدث */
    payParty(supId, cur, amt, method, user, date) {
      return this.tx(D => {
        need(D, user, 'collect');
        if (!D.sup.some(c => c.id === supId)) throw err('المورد غير موجود');
        if (!isInt(amt) || amt <= 0) throw err('مبلغ غير صحيح');
        const dt = this.stampDate(date), pm = purPaidMap(D);
        const open = D.pur.filter(i => i.s === supId && !i.void && i.cur === cur).sort((a, b) => (a.date + a.ts < b.date + b.ts ? -1 : 1))
          .map(i => ({ i, due: purView(D, i, pm).due })).filter(x => x.due > 0);
        const total = sum(open.map(x => x.due));
        if (amt > total) throw err('المبلغ أكبر من المستحق للمورد بهذه العملة (' + M.fmt(total, decOf(D, cur)) + ')', 'pay');
        let left = amt; const parts = [];
        open.forEach(x => {
          if (left <= 0) return; const a = Math.min(left, x.due); left -= a; parts.push({ no: x.i.no, a });
          this._cashEntry(D, { date: dt, cur, amt: -a, fx: x.i.fx, kind: 'sup-pay', ref: { t: 'pur', id: x.i.id }, method, by: user });
        });
        this.log(D, user, 'sup.pay', { t: 'sup', id: supId }, M.fmt(amt, decOf(D, cur)) + ' ' + cur);
        return { applied: amt, parts, date: dt };
      });
    }
    returnItems(id, o) { // o: {lines:[{k,q}], date, refund:{amt,method}|null, user, req}
      return this.tx(D => {
        need(D, o.user, 'ret');
        const inv = D.inv.find(x => x.id === id); if (!inv) throw err('الفاتورة غير موجودة');
        if (inv.void) throw err('الفاتورة ملغاة');
        inv.rt = inv.rt || [];
        if (o.req && inv.rt.some(r => r.req === o.req)) return { dup: true };
        const lines = (o.lines || []).filter(l => l.q > 0);
        if (!lines.length) throw err('اختر كمية للإرجاع');
        const done = calcInv(inv).lines;
        const seen = {};
        lines.forEach(l => {
          const it = inv.items[l.k]; if (!it) throw err('بند غير موجود');
          if (!isInt(l.q) || l.q <= 0) throw err('كمية غير صحيحة');
          seen[l.k] = (seen[l.k] || 0) + l.q;
          if (seen[l.k] > done[l.k].left) throw err('كمية المرتجع أكبر من المتاح للإرجاع: ' + it.n, 'ret');
        });
        const r = { id: this.uid(), no: 'RET-' + pad(D.seq.ret++, 4), req: o.req || null, date: this.stampDate(o.date), ts: this.ts(), lines: lines.map(l => ({ k: l.k, q: l.q })), by: o.user || null };
        inv.rt.push(r);
        lines.forEach(l => { D.prod.find(p => p.id === inv.items[l.k].p).q += l.q; this._mv(D, inv.items[l.k].p, l.q, 'return', { t: 'inv', id }, o.user); });
        const v = invView(D, inv);
        const maxRefund = Math.max(0, v.paid - v.c.totEff);
        let ra = o.refund && o.refund.amt ? o.refund.amt : 0;
        if (!isInt(ra) || ra < 0) throw err('مبلغ الرد غير صحيح');
        // عميل نقدي (بلا حساب): لا يوجد رصيد يُحفظ فيه الفائض، فيُرَدّ كاملًا (تلقائيًا إن لم يُحدَّد)
        if (!inv.c && maxRefund > 0) {
          if (ra === 0) { ra = maxRefund; o = Object.assign({}, o, { refund: { amt: ra, method: (o.refund && o.refund.method) || 'cash' } }); }
          else if (ra < maxRefund) throw err('فاتورة بدون عميل مسجَّل: يجب رد المبلغ كاملًا (' + M.fmt(maxRefund, decOf(D, inv.cur)) + ') لأنه لا يوجد حساب يُحفظ فيه الرصيد', 'pay');
        }
        if (ra > maxRefund) throw err('مبلغ الرد أكبر من المبلغ القابل للرد (' + M.fmt(maxRefund, decOf(D, inv.cur)) + ')', 'pay');
        if (ra > 0) this._cashEntry(D, { date: r.date, cur: inv.cur, amt: -ra, fx: inv.fx, kind: 'refund', ref: { t: 'inv', id }, method: o.refund.method, by: o.user, note: r.no });
        this.log(D, o.user, 'sale.return', { t: 'inv', id }, inv.no + ' ' + r.no + ' قيمة ' + M.fmt(v.c.returns[r.id].gross, decOf(D, inv.cur)));
        return { no: r.no, id: r.id, gross: v.c.returns[r.id].gross, refunded: ra };
      });
    }
    voidReturn(invId, retId, user) {
      return this.tx(D => {
        need(D, user, 'ret');
        const inv = D.inv.find(x => x.id === invId); if (!inv || inv.void) throw err('الفاتورة غير متاحة');
        const r = (inv.rt || []).find(x => x.id === retId); if (!r || r.void) throw err('المرتجع غير متاح');
        const gross = calcInv(inv).returns[retId].gross;
        r.lines.forEach(l => {
          const p = D.prod.find(z => z.id === inv.items[l.k].p);
          if (p.q < l.q && !D.set.negStock && !canOverride(D, user, 'negstock')) throw err('المخزون الحالي لا يكفي لإلغاء المرتجع: ' + p.n, 'stock');
          p.q -= l.q; this._mv(D, p.id, -l.q, 'return-void', { t: 'inv', id: invId }, user);
        });
        r.void = { ts: this.ts(), by: user || null };
        this.log(D, user, 'sale.return.void', { t: 'inv', id: invId }, inv.no + ' ' + r.no + ' ' + M.fmt(gross, decOf(D, inv.cur)));
        return true;
      });
    }
    voidSale(id, o) { // o: {reason, method, user}
      return this.tx(D => {
        need(D, o.user, 'void');
        const inv = D.inv.find(x => x.id === id); if (!inv) throw err('الفاتورة غير موجودة');
        if (inv.void) throw err('الفاتورة ملغاة مسبقًا');
        if (!o.reason || !String(o.reason).trim()) throw err('سبب الإلغاء مطلوب');
        const c = calcInv(inv);
        inv.items.forEach((x, k) => { const left = c.lines[k].left; if (left > 0) { D.prod.find(p => p.id === x.p).q += left; this._mv(D, x.p, left, 'sale-void', { t: 'inv', id }, o.user); } });
        const paid = sum(D.cash.filter(e => e.ref && e.ref.t === 'inv' && e.ref.id === id).map(e => e.amt));
        if (paid > 0) this._cashEntry(D, { date: this.stampDate(o.date), cur: inv.cur, amt: -paid, fx: inv.fx, kind: 'refund', ref: { t: 'inv', id }, method: o.method || 'cash', by: o.user, note: 'إلغاء ' + inv.no });
        inv.void = { ts: this.ts(), by: o.user || null, reason: String(o.reason).trim() };
        this.log(D, o.user, 'sale.void', { t: 'inv', id }, inv.no + ' — ' + inv.void.reason);
        return { refunded: Math.max(0, paid) };
      });
    }

    /* ======== المشتريات ======== */
    createPurchase(o) { // items:[{p,q,co}] co = سعر الوحدة بعملة الفاتورة
      if (!o.req) throw err('معرّف الطلب مطلوب لمنع التكرار', 'req');
      const dup = this.S.pur.find(x => x.req === o.req);
      if (dup) return { dup: true, id: dup.id, no: dup.no };
      return this.tx(D => {
        need(D, o.user, 'buy');
        const date = this.stampDate(o.date);
        const cur = o.cur || D.set.base; o = Object.assign({}, o, { cur });
        const fx = fxFor(D, cur, o.fx);
        const items = this._items(D, o, 'co', false);
        const sup = o.s ? D.sup.find(x => x.id === o.s) : null; if (o.s && (!sup || sup.arch)) throw err('المورد غير موجود');
        const sub = sum(items.map(x => M.lineTotal(x.co, x.q)));
        const disc = o.disc || 0; if (!isInt(disc) || disc < 0 || disc > sub) throw err('الخصم غير صحيح');
        const pur = { id: this.uid(), no: 'PUR-' + pad(D.seq.pur++, 4), req: o.req, date, ts: this.ts(), s: sup ? sup.id : '', sn: sup ? sup.n : 'مورد نقدي', cur, fx, items, disc, rate: o.rate || 0, rt: [], by: o.user || null, note: o.note || '', ref: o.ref || '' };
        const c = calcPur(pur);
        const pay = o.pay || { amt: 0 };
        if (!isInt(pay.amt) || pay.amt < 0 || pay.amt > c.tot) throw err('المبلغ المدفوع غير صحيح');
        if (pay.amt < c.tot && !pur.s) throw err('الشراء بالآجل يتطلب اختيار مورد', 'debt');
        const dB = decOf(D, D.set.base), dC = decOf(D, cur);
        items.forEach((x, k) => { // تكلفة متوسطة مرجحة بالعملة الأساسية (الصافي بعد الخصم، بدون الضريبة)
          const p = D.prod.find(z => z.id === x.p);
          const lineNetBase = M.toBase(c.lines[k].net, dC, dB, fx);
          const oldQ = Math.max(p.q, 0), oldVal = M.mulDiv(p.co, oldQ, 1000);
          p.co = oldQ + x.q > 0 && oldQ > 0 ? M.mulDiv(oldVal + lineNetBase, 1000, oldQ + x.q) : M.mulDiv(lineNetBase, 1000, x.q);
          p.q += x.q; this._mv(D, x.p, x.q, 'purchase', { t: 'pur', id: pur.id }, o.user);
        });
        D.pur.push(pur);
        if (pay.amt > 0) this._cashEntry(D, { date, cur, amt: -pay.amt, fx, kind: 'sup-pay', ref: { t: 'pur', id: pur.id }, method: pay.method, by: o.user });
        this.log(D, o.user, 'pur.create', { t: 'pur', id: pur.id }, pur.no + ' إجمالي ' + M.fmt(c.tot, dC) + ' ' + cur);
        return { id: pur.id, no: pur.no, tot: c.tot, paid: pay.amt };
      });
    }
    payPurchase(id, amt, method, user, date) {
      return this.tx(D => {
        need(D, user, 'collect');
        const p = D.pur.find(x => x.id === id); if (!p || p.void) throw err('الفاتورة غير متاحة');
        const v = purView(D, p);
        if (!isInt(amt) || amt <= 0 || amt > v.due) throw err('المبلغ أكبر من المتبقي للمورد (' + M.fmt(v.due, decOf(D, p.cur)) + ')', 'pay');
        this._cashEntry(D, { date: this.stampDate(date), cur: p.cur, amt: -amt, fx: p.fx, kind: 'sup-pay', ref: { t: 'pur', id }, method, by: user });
        this.log(D, user, 'pur.pay', { t: 'pur', id }, p.no + ' ' + M.fmt(amt, decOf(D, p.cur)));
        return true;
      });
    }
    returnPurchase(id, o) {
      return this.tx(D => {
        need(D, o.user, 'buy');
        const p = D.pur.find(x => x.id === id); if (!p || p.void) throw err('الفاتورة غير متاحة');
        p.rt = p.rt || [];
        const lines = (o.lines || []).filter(l => l.q > 0); if (!lines.length) throw err('اختر كمية للإرجاع');
        const done = calcPur(p).lines, seen = {};
        lines.forEach(l => {
          const it = p.items[l.k]; if (!it || !isInt(l.q)) throw err('بند غير صحيح');
          seen[l.k] = (seen[l.k] || 0) + l.q;
          if (seen[l.k] > done[l.k].left) throw err('كمية المرتجع أكبر من المتاح: ' + it.n, 'ret');
          const pr = D.prod.find(z => z.id === it.p);
          if (pr.q < seen[l.k] && !D.set.negStock && !canOverride(D, o.user, 'negstock')) throw err('المخزون الحالي لا يكفي لإرجاعها للمورد: ' + pr.n, 'stock');
        });
        const r = { id: this.uid(), no: 'PRT-' + pad(D.seq.pret++, 4), date: this.stampDate(o.date), ts: this.ts(), lines: lines.map(l => ({ k: l.k, q: l.q })), by: o.user || null };
        p.rt.push(r);
        lines.forEach(l => { D.prod.find(z => z.id === p.items[l.k].p).q -= l.q; this._mv(D, p.items[l.k].p, -l.q, 'pur-return', { t: 'pur', id }, o.user); });
        const v = purView(D, p);
        const ra = o.refund && o.refund.amt ? o.refund.amt : 0, maxR = Math.max(0, v.paid - v.c.totEff);
        if (!isInt(ra) || ra < 0 || ra > maxR) throw err('مبلغ الاسترداد أكبر من القابل للاسترداد (' + M.fmt(maxR, decOf(D, p.cur)) + ')', 'pay');
        if (ra > 0) this._cashEntry(D, { date: r.date, cur: p.cur, amt: ra, fx: p.fx, kind: 'sup-refund', ref: { t: 'pur', id }, method: o.refund.method, by: o.user, note: r.no });
        this.log(D, o.user, 'pur.return', { t: 'pur', id }, p.no + ' ' + r.no);
        return { no: r.no, gross: v.c.returns[r.id].gross };
      });
    }
    voidPurchase(id, o) {
      return this.tx(D => {
        need(D, o.user, 'buy');
        const p = D.pur.find(x => x.id === id); if (!p) throw err('الفاتورة غير موجودة');
        if (p.void) throw err('الفاتورة ملغاة مسبقًا');
        if (!o.reason || !String(o.reason).trim()) throw err('سبب الإلغاء مطلوب');
        const c = calcPur(p);
        p.items.forEach((x, k) => {
          const left = c.lines[k].left, pr = D.prod.find(z => z.id === x.p);
          if (left > 0) {
            if (pr.q < left && !D.set.negStock && !canOverride(D, o.user, 'negstock')) throw err('لا يمكن الإلغاء: بيعت بعض كميات ' + pr.n, 'stock');
            pr.q -= left; this._mv(D, x.p, -left, 'pur-void', { t: 'pur', id }, o.user);
          }
        });
        const paid = sum(D.cash.filter(e => e.ref && e.ref.t === 'pur' && e.ref.id === id).map(e => -e.amt));
        if (paid > 0) this._cashEntry(D, { date: this.stampDate(o.date), cur: p.cur, amt: paid, fx: p.fx, kind: 'sup-refund', ref: { t: 'pur', id }, method: o.method || 'cash', by: o.user, note: 'إلغاء ' + p.no });
        p.void = { ts: this.ts(), by: o.user || null, reason: String(o.reason).trim() };
        this.log(D, o.user, 'pur.void', { t: 'pur', id }, p.no + ' — ' + p.void.reason);
        return true;
      });
    }

    /* ======== المصاريف والصندوق ======== */
    addExpense(o) {
      if (o.req && this.S.exp.some(e => e.req === o.req)) return { dup: true };
      return this.tx(D => {
        need(D, o.user, 'exp');
        if (!o.n || !String(o.n).trim()) throw err('البيان مطلوب');
        if (!isInt(o.a) || o.a <= 0) throw err('المبلغ مطلوب');
        const cur = o.cur || D.set.base, fx = fxFor(D, cur, o.fx), date = this.stampDate(o.date);
        const e = { id: this.uid(), req: o.req || null, date, ts: this.ts(), n: String(o.n).trim(), cat: o.cat || '', a: o.a, cur, fx, by: o.user || null };
        D.exp.push(e);
        this._cashEntry(D, { date, cur, amt: -o.a, fx, kind: 'expense', ref: { t: 'exp', id: e.id }, method: o.method || 'cash', by: o.user });
        this.log(D, o.user, 'exp.add', { t: 'exp', id: e.id }, e.n + ' ' + M.fmt(o.a, decOf(D, cur)));
        return e.id;
      });
    }
    voidExpense(id, o) {
      return this.tx(D => {
        need(D, o.user, 'exp');
        const e = D.exp.find(x => x.id === id); if (!e) throw err('المصروف غير موجود');
        if (e.void) throw err('المصروف ملغى مسبقًا');
        const orig = D.cash.find(c => c.ref && c.ref.t === 'exp' && c.ref.id === id);
        this._cashEntry(D, { date: this.stampDate(o.date), cur: e.cur, amt: e.a, fx: e.fx, kind: 'expense-void', ref: { t: 'exp', id }, method: orig ? orig.method : 'cash', by: o.user });
        e.void = { ts: this.ts(), by: o.user || null, reason: o.reason || '' };
        this.log(D, o.user, 'exp.void', { t: 'exp', id }, e.n);
        return true;
      });
    }
    cashMove(o) { // o: {cur, amt (موجب إيداع/سالب سحب), method, note, kind, user}
      return this.tx(D => {
        need(D, o.user, 'cash');
        const cur = o.cur || D.set.base; curDef(D, cur);
        if (!isInt(o.amt) || o.amt === 0) throw err('المبلغ مطلوب');
        if (!o.note || !String(o.note).trim()) throw err('البيان مطلوب');
        this._cashEntry(D, { date: this.stampDate(o.date), cur, amt: o.amt, fx: fxFor(D, cur, o.fx), kind: o.amt > 0 ? (o.kind || 'deposit') : 'withdraw', ref: null, method: o.method || 'cash', by: o.user, note: String(o.note).trim() });
        this.log(D, o.user, 'cash.move', null, (o.amt > 0 ? 'إيداع ' : 'سحب ') + M.fmt(Math.abs(o.amt), decOf(D, cur)) + ' ' + cur + ' — ' + o.note);
        return true;
      });
    }

    /* ======== استيراد حزمة من برنامج آخر (البرهان) — عملية ذرية واحدة ======== */
    importPackage(pkg, o) {
      o = o || {};
      return this.tx(D => {
        need(D, o.user, 'set');
        if (!pkg || pkg.app !== 'aqrab-import' || pkg.format !== 1) throw err('ملف الاستيراد غير صالح');
        if (pkg.base !== D.set.base) throw err('عملة الحزمة (' + pkg.base + ') تختلف عن عملة النظام الأساسية (' + D.set.base + ')');
        const key = 'imp:' + (pkg.source || '') + ':' + (pkg.created || '');
        D.imports = D.imports || [];
        if (D.imports.some(x => x.key === key)) throw err('هذه الحزمة سبق استيرادها');
        const ids = new Set([...D.cust, ...D.prod, ...D.inv].map(x => x.id)), cashIds = new Set(D.cash.map(x => x.id));
        const nos = new Set(D.inv.map(x => x.no)), reqs = new Set(D.inv.map(x => x.req).filter(Boolean));
        const rep = { cust: 0, prod: 0, inv: 0, cash: 0, bcBlanked: [], net: 0, paid: 0, units: 0 };
        const take = (arr, what) => arr.forEach(x => { if (ids.has(x.id)) throw err('تعارض معرّف موجود مسبقًا (' + what + '): ' + x.id); ids.add(x.id); });
        take(pkg.cust, 'عميل'); take(pkg.prod, 'منتج'); take(pkg.inv, 'فاتورة');
        pkg.cust.forEach(c => { D.cust.push(Object.assign({}, c)); rep.cust++; });
        pkg.prod.forEach(p => {
          if (![p.pr, p.co, p.q, p.mn || 0].every(isInt) || p.pr < 0 || p.co < 0 || p.q < 0) throw err('قيمة غير صحيحة في المنتج: ' + p.n);
          const e = Object.assign({ mn: 0, brand: '', model: '', cat: '', img: '' }, p);
          if (e.bc && (!/^\d{1,32}$/.test(e.bc) || D.prod.some(z => z.bc === e.bc))) { rep.bcBlanked.push({ n: e.n, bc: e.bc }); e.bc = ''; }
          if (!e.bc) e.bc = '';
          D.prod.push(e); rep.prod++;
          if (e.q) { D.mv.push({ id: this.uid(), ts: this.ts(), p: e.id, dq: e.q, kind: 'open', ref: { t: 'import', id: key }, by: o.user || null }); rep.units += e.q; }
        });
        pkg.inv.forEach(i => {
          if (nos.has(i.no)) throw err('رقم فاتورة موجود مسبقًا: ' + i.no);
          if (i.req && reqs.has(i.req)) throw err('فاتورة مكررة: ' + i.req);
          const inv = Object.assign({ rt: [] }, i);
          inv.rt = (inv.rt || []).map(r => Object.assign({}, r, { no: 'RET-' + String(D.seq.ret++).padStart(4, '0') }));
          const pids = new Set(D.prod.map(p => p.id));
          inv.items.forEach(x => { if (!pids.has(x.p)) throw err('فاتورة ' + inv.no + ' تشير لمنتج غير موجود'); });
          D.inv.push(inv); nos.add(inv.no); rep.inv++;
          const v = calcInv(inv); rep.net += v.totEff;
        });
        pkg.cash.forEach(c => {
          if (cashIds.has(c.id)) throw err('قيد نقدي مكرر: ' + c.id);
          cashIds.add(c.id); D.cash.push(Object.assign({}, c)); rep.cash++; rep.paid += c.amt;
        });
        if (pkg.expect) {
          const ex = pkg.expect;
          if (ex.inv !== rep.inv || ex.cust !== rep.cust || ex.prod !== rep.prod || ex.net_total !== rep.net || ex.paid_total !== rep.paid || ex.stock_units !== rep.units)
            throw err('أرقام الحزمة بعد الاستيراد لا تطابق الأرقام المتوقعة — أُلغي الاستيراد');
        }
        D.imports.push({ key, at: this.ts(), source: pkg.source || '', counts: { cust: rep.cust, prod: rep.prod, inv: rep.inv, cash: rep.cash } });
        this.log(D, o.user, 'import.package', { t: 'import', id: key }, (pkg.source || '') + ': ' + rep.inv + ' فاتورة، ' + rep.cust + ' عميل، ' + rep.prod + ' منتج، ' + rep.cash + ' قيد نقدي');
        return rep;
      });
    }

    /* ======== استيراد الباركودات كما هي (حروف وأرقام) للمنتجات المستوردة ======== */
    importBarcodes(pkg, o) {
      o = o || {};
      return this.tx(D => {
        need(D, o.user, 'set');
        if (!pkg || pkg.app !== 'aqrab-import' || pkg.kind !== 'barcodes' || !Array.isArray(pkg.items)) throw err('ملف الباركودات غير صالح');
        const key = 'bc:' + (pkg.source || '') + ':' + (pkg.created || '');
        D.imports = D.imports || [];
        if (D.imports.some(x => x.key === key)) throw err('هذه الباركودات سبق استيرادها');
        const seen = new Set();
        pkg.items.forEach(it => {
          const p = D.prod.find(z => z.id === it.id);
          if (!p) throw err('منتج غير موجود: ' + it.id + ' — استورد حزمة البيانات الأساسية أولًا');
          if (p.n !== it.n) throw err('اسم المنتج لا يطابق: ' + it.id);
          const bc = String(it.bc);
          if (!bc || bc.length > 32) throw err('باركود غير صالح للمنتج ' + p.n);
          if (p.bc && p.bc !== bc) throw err('المنتج ' + p.n + ' له باركود مختلف مسبقًا (' + p.bc + ') ولن يُستبدل');
          if (seen.has(bc) || D.prod.some(z => z.bc === bc && z.id !== p.id)) throw err('الباركود مكرر: ' + bc);
          seen.add(bc); p.bc = bc;
        });
        D.imports.push({ key, at: this.ts(), source: pkg.source || '', counts: { cust: 0, prod: pkg.items.length, inv: 0, cash: 0 } });
        this.log(D, o.user, 'import.barcodes', { t: 'import', id: key }, pkg.items.length + ' باركود');
        return { n: pkg.items.length };
      });
    }

    /* ======== العملات والإعدادات ======== */
    setCompany(o) { return this.tx(D => { need(D, o.user, 'set'); ['n', 'ph', 'ad', 'tx'].forEach(k => { if (o[k] !== undefined) D.co[k] = String(o[k]); }); this.log(D, o.user, 'set.company', null, D.co.n); return true; }); }
    setOptions(o) {
      return this.tx(D => {
        need(D, o.user, 'set');
        if (o.taxBp !== undefined) { if (!isInt(o.taxBp) || o.taxBp < 0 || o.taxBp > 100000) throw err('نسبة الضريبة غير صحيحة'); D.set.taxBp = o.taxBp; }
        ['negStock', 'cashDebt'].forEach(k => { if (o[k] !== undefined) D.set[k] = !!o[k]; });
        if (o.rcpt !== undefined) D.set.rcpt = o.rcpt === 'A4' ? 'A4' : '80';
        if (o.rfoot !== undefined) D.set.rfoot = String(o.rfoot);
        if (o.terms !== undefined) D.set.terms = String(o.terms).slice(0, 600);
        if (o.logo !== undefined) { const l = String(o.logo); if (l && (!/^data:image\/(png|jpeg);base64,/.test(l) || l.length > 400000)) throw err('صورة الشعار غير صالحة أو كبيرة'); D.set.logo = l; }
        this.log(D, o.user, 'set.options', null, JSON.stringify(Object.assign({}, o, { user: undefined })));
        return true;
      });
    }
    addCurrency(o) {
      return this.tx(D => {
        need(D, o.user, 'fx');
        const code = String(o.code || '').trim().toUpperCase();
        if (!/^[A-Z0-9]{2,5}$/.test(code)) throw err('رمز العملة 2-5 أحرف إنجليزية');
        if (D.set.cur.some(c => c.code === code)) throw err('العملة موجودة مسبقًا');
        if (![0, 1, 2, 3].includes(o.dec)) throw err('عدد المنازل العشرية بين 0 و3');
        if (!isInt(o.rate) || o.rate <= 0) throw err('سعر الصرف غير صحيح');
        D.set.cur.push({ code, sym: o.sym || code, dec: o.dec, rate: o.rate, name: o.name || code });
        this.log(D, o.user, 'fx.add', null, code + ' = ' + M.fmtRate(o.rate));
        return code;
      });
    }
    setRate(code, rate, user) { // لا يغيّر المعاملات القديمة: كل معاملة تحفظ سعرها
      return this.tx(D => {
        need(D, user, 'fx');
        const c = curDef(D, code); if (code === D.set.base) throw err('لا يمكن تغيير سعر العملة الأساسية');
        if (!isInt(rate) || rate <= 0) throw err('سعر الصرف غير صحيح');
        const old = c.rate; c.rate = rate;
        this.log(D, user, 'fx.rate', null, code + ' ' + M.fmtRate(old) + ' ← ' + M.fmtRate(rate));
        return true;
      });
    }

    /* ======== المستخدمون ======== */
    async setupAdmin(o) {
      if (this.S.users.length) throw err('تم إعداد المستخدمين مسبقًا');
      if (!o.user || !o.pw || o.pw.length < 4) throw err('اسم المستخدم وكلمة سر (4 أحرف على الأقل) مطلوبان');
      const rec = await hashPw(o.pw);
      return this.tx(D => {
        const u = { id: this.uid(), name: o.name || 'المدير', user: String(o.user).trim().toLowerCase(), pw: rec, role: 'admin', perms: ROLES.admin.perms.slice(), maxDisc: 10000, active: true };
        D.users.push(u); this.log(D, u.id, 'user.setup', { t: 'user', id: u.id }, u.user); return u.id;
      });
    }
    async addUser(o) {
      need(this.S, o.by, 'users');
      if (!o.user || !/^[a-z0-9._-]{3,32}$/i.test(o.user)) throw err('اسم الدخول: 3-32 حرفًا إنجليزيًا أو أرقامًا');
      if (!o.pw || o.pw.length < 4) throw err('كلمة السر 4 أحرف على الأقل');
      if (!ROLES[o.role]) throw err('دور غير معروف');
      const rec = await hashPw(o.pw);
      return this.tx(D => {
        if (D.users.some(u => u.user === o.user.toLowerCase())) throw err('اسم الدخول مستخدم');
        const perms = (o.perms || ROLES[o.role].perms).filter(p => PERMS[p]);
        const u = { id: this.uid(), name: o.name || o.user, user: o.user.toLowerCase(), pw: rec, role: o.role, perms, maxDisc: o.maxDisc != null ? o.maxDisc : ROLES[o.role].maxDisc, active: true };
        D.users.push(u); this.log(D, o.by, 'user.add', { t: 'user', id: u.id }, u.user + ' (' + o.role + ')'); return u.id;
      });
    }
    updateUser(id, o) { // o: {name, role, perms, maxDisc, active, by}
      return this.tx(D => {
        need(D, o.by, 'users');
        const u = findUser(D, id); if (!u) throw err('المستخدم غير موجود');
        if (o.name !== undefined) u.name = o.name;
        if (o.role !== undefined) { if (!ROLES[o.role]) throw err('دور غير معروف'); u.role = o.role; }
        if (o.perms !== undefined) u.perms = o.perms.filter(p => PERMS[p]);
        if (o.maxDisc !== undefined) { if (!isInt(o.maxDisc) || o.maxDisc < 0 || o.maxDisc > 10000) throw err('الحد الأقصى للخصم بين 0 و100'); u.maxDisc = o.maxDisc; }
        if (o.active !== undefined) u.active = !!o.active;
        if (!D.users.some(x => x.active && x.perms.includes('users'))) throw err('يجب أن يبقى مدير واحد فعّال على الأقل', 'lastadmin');
        this.log(D, o.by, 'user.edit', { t: 'user', id }, u.user);
        return id;
      });
    }
    async resetPassword(id, pw, by) {
      need(this.S, by, 'users'); if (!pw || pw.length < 4) throw err('كلمة السر 4 أحرف على الأقل');
      const rec = await hashPw(pw);
      return this.tx(D => { const u = findUser(D, id); if (!u) throw err('المستخدم غير موجود'); u.pw = rec; delete u.legacy; this.log(D, by, 'user.pw', { t: 'user', id }, u.user); return true; });
    }
    async changeOwnPassword(id, oldPw, newPw) {
      const u = findUser(this.S, id); if (!u) throw err('المستخدم غير موجود');
      if (!(await this._verify(u, oldPw))) throw err('كلمة السر الحالية خاطئة');
      if (!newPw || newPw.length < 4) throw err('كلمة السر الجديدة قصيرة');
      const rec = await hashPw(newPw);
      return this.tx(D => { const x = findUser(D, id); x.pw = rec; delete x.legacy; this.log(D, id, 'user.pw.self', { t: 'user', id }, x.user); return true; });
    }
    async _verify(u, pw) {
      if (u.pw) { const r = await hashPw(pw, u.pw.salt, u.pw.iter); return sameHash(r.hash, u.pw.hash); }
      if (u.legacy) return (await legacyHash(pw)) === u.legacy;
      return false;
    }
    async login(username, pw) {
      const u = this.S.users.find(x => x.user === String(username || '').trim().toLowerCase() && x.active);
      if (!u || !(await this._verify(u, pw))) return null;
      if (!u.pw && u.legacy) { // ترقية كلمة السر القديمة إلى تجزئة بملح
        const rec = await hashPw(pw);
        this.tx(D => { const x = findUser(D, u.id); x.pw = rec; delete x.legacy; this.log(D, u.id, 'user.pw.upgrade', { t: 'user', id: u.id }, x.user); });
      }
      return u.id;
    }
  }

  /* ---------------- التقارير ---------------- */
  const inRange = (d, f) => (!f.from || d >= f.from) && (!f.to || d <= f.to);
  function salesRows(S, f) {
    f = f || {}; const pm = paidMap(S);
    return S.inv.filter(i => !i.void && inRange(i.date, f) && (!f.c || i.c === f.c) && (!f.r || i.r === f.r)).map(i => {
      const v = invView(S, i, pm), fx = i.fx;
      return { id: i.id, no: i.no, date: i.date, cn: i.cn, cur: i.cur, tot: v.c.totEff, paid: v.paid, due: v.due, netBase: toBase(S, v.c.netEff, i.cur, fx), taxBase: toBase(S, v.c.taxEff, i.cur, fx), totBase: toBase(S, v.c.totEff, i.cur, fx), costBase: v.c.costEff, profitBase: toBase(S, v.c.netEff, i.cur, fx) - v.c.costEff, rep: i.r, repName: i.rn };
    });
  }
  function profitLoss(S, f) {
    f = f || {};
    const rows = salesRows(S, f);
    const exps = S.exp.filter(e => !e.void && inRange(e.date, f));
    const expBase = sum(exps.map(e => toBase(S, e.a, e.cur, e.fx)));
    const purTaxIn = sum(S.pur.filter(p => !p.void && inRange(p.date, f)).map(p => toBase(S, calcPur(p).taxEff, p.cur, p.fx)));
    const rev = sum(rows.map(r => r.netBase)), cogs = sum(rows.map(r => r.costBase));
    return { revenue: rev, cogs, gross: rev - cogs, expenses: expBase, net: rev - cogs - expBase, taxOut: sum(rows.map(r => r.taxBase)), taxIn: purTaxIn, invoices: rows.length, salesTotal: sum(rows.map(r => r.totBase)) };
  }
  function periodReport(S, f, by) { // by: 'day' | 'month'
    const key = d => (by === 'month' ? d.slice(0, 7) : d), out = {};
    const get = k => out[k] = out[k] || { k, invoices: 0, sales: 0, cost: 0, profit: 0, expenses: 0, collected: 0 };
    salesRows(S, f).forEach(r => { const o = get(key(r.date)); o.invoices++; o.sales += r.totBase; o.cost += r.costBase; o.profit += r.profitBase; });
    S.exp.filter(e => !e.void && inRange(e.date, f)).forEach(e => { get(key(e.date)).expenses += toBase(S, e.a, e.cur, e.fx); });
    S.cash.filter(c => inRange(c.date, f) && (c.kind === 'sale' || c.kind === 'collect')).forEach(c => { get(key(c.date)).collected += toBase(S, c.amt, c.cur, c.fx); });
    return Object.values(out).sort((a, b) => (a.k < b.k ? -1 : 1)).map(o => Object.assign(o, { net: o.profit - o.expenses }));
  }
  function stockReport(S) {
    return S.prod.filter(p => !p.arch).map(p => ({ id: p.id, n: p.n, bc: p.bc, q: p.q, co: p.co, pr: p.pr, value: M.mulDiv(p.co, Math.max(p.q, 0), 1000), low: p.q <= p.mn }));
  }
  function statement(S, kind, id) { // كشف حساب عميل/مورد، يعيد صفوفًا مرتبة مع رصيد متحرك لكل عملة
    const ev = [];
    if (kind === 'cust') {
      S.inv.filter(i => i.c === id && !i.void).forEach(i => {
        const c = calcInv(i);
        ev.push({ date: i.date, ts: i.ts, type: 'فاتورة', ref: i.no, cur: i.cur, d: c.tot, c: 0 });
        (i.rt || []).filter(r => !r.void).forEach(r => ev.push({ date: r.date, ts: r.ts, type: 'مرتجع', ref: r.no, cur: i.cur, d: 0, c: c.returns[r.id].gross }));
        S.cash.filter(e => e.ref && e.ref.t === 'inv' && e.ref.id === i.id).forEach(e => ev.push({ date: e.date, ts: e.ts, type: e.amt > 0 ? 'دفعة' : 'رد مبلغ', ref: i.no, cur: e.cur, d: e.amt < 0 ? -e.amt : 0, c: e.amt > 0 ? e.amt : 0 }));
      });
    } else {
      S.pur.filter(p => p.s === id && !p.void).forEach(p => {
        const c = calcPur(p);
        ev.push({ date: p.date, ts: p.ts, type: 'فاتورة شراء', ref: p.no, cur: p.cur, d: c.tot, c: 0 });
        (p.rt || []).filter(r => !r.void).forEach(r => ev.push({ date: r.date, ts: r.ts, type: 'مرتجع للمورد', ref: r.no, cur: p.cur, d: 0, c: c.returns[r.id].gross }));
        S.cash.filter(e => e.ref && e.ref.t === 'pur' && e.ref.id === p.id).forEach(e => ev.push({ date: e.date, ts: e.ts, type: e.amt < 0 ? 'سداد' : 'استرداد', ref: p.no, cur: e.cur, d: e.amt > 0 ? e.amt : 0, c: e.amt < 0 ? -e.amt : 0 }));
      });
    }
    ev.sort((a, b) => (a.date + a.ts < b.date + b.ts ? -1 : 1));
    const run = {};
    ev.forEach(e => { run[e.cur] = (run[e.cur] || 0) + e.d - e.c; e.bal = run[e.cur]; });
    return { rows: ev, balances: run };
  }

  /* ---------------- الترحيل من النسخة القديمة (v1) ---------------- */
  function migrate(v1, legacyPw, opt) {
    opt = opt || {};
    const ts = opt.ts || new Date().toISOString();
    const S = newState(), rep = { inv: 0, changed: [], products: 0, customers: 0 };
    const m2 = x => { const r = M.parse(typeof x === 'number' ? String(+x.toFixed(6)) : String(x == null ? 0 : x), 2); return r === null ? Math.round((+x || 0) * 100) : r; };
    const q3 = x => { const r = M.parse(typeof x === 'number' ? String(+x.toFixed(6)) : String(x == null ? 0 : x), 3); return r === null ? Math.round((+x || 0) * 1000) : r; };
    const sym = (v1.co && v1.co.cur) || '$';
    const base = sym === '$' ? 'USD' : 'MAIN';
    S.set.base = base; S.set.cur = [{ code: base, sym, dec: 2, rate: 1000000, name: sym === '$' ? 'دولار أمريكي' : 'العملة الأساسية' }];
    S.set.taxBp = Math.max(0, Math.round(((v1.co && +v1.co.rate) || 0) * 100));
    S.co = { n: (v1.co && v1.co.n) || 'العقرب الحسابي', ph: (v1.co && v1.co.ph) || '', ad: (v1.co && v1.co.ad) || '', tx: (v1.co && v1.co.tx) || '' };
    (v1.cust || []).forEach(c => S.cust.push({ id: c.id, n: c.n, ph: c.ph || '', ad: c.ad || '' }));
    (v1.rep || []).forEach(r => S.rep.push({ id: r.id, n: r.n, r: Math.round((+r.r || 0) * 100) }));
    (v1.prod || []).forEach(p => {
      const q = q3(p.q);
      S.prod.push({ id: p.id, n: p.n, bc: /^\d+$/.test(String(p.bc || '')) ? String(p.bc) : '', pr: m2(p.pr), co: m2(p.co), q, mn: q3(p.mn), brand: '', model: '', cat: '', img: '' });
      if (q) S.mv.push({ id: 'mv-open-' + p.id, ts, p: p.id, dq: q, kind: 'open', ref: null, by: null, note: 'رصيد افتتاحي عند الترحيل' });
    });
    // حساب النسخة القديمة (للمقارنة فقط في تقرير الترحيل)
    const r2 = n => Math.round((n + Number.EPSILON) * 100) / 100;
    const rk = (v, k) => (v.rt || []).filter(r => r.k == k).reduce((s, r) => s + r.q, 0);
    const oldTot = v => { const o = r2(v.items.reduce((s, x) => s + x.q * x.pr, 0)), sub = r2(v.items.reduce((s, x, k) => s + (x.q - rk(v, k)) * x.pr, 0)), d = o ? r2(v.disc * sub / o) : 0, net = r2(sub - d), tax = r2(net * v.rate / 100); return r2(net + tax); };
    (v1.inv || []).forEach(v => {
      const inv = {
        id: v.id, no: v.no, req: 'mig-' + v.id, date: v.date, ts: v.date + 'T12:00:00.000Z', c: v.c || '', cn: v.cn || 'عميل نقدي', r: v.r || '', rn: v.rn || '', cur: base, fx: 1000000,
        items: (v.items || []).map(x => ({ p: x.p, n: x.n, q: q3(x.q), pr: m2(x.pr), co: m2(x.co || 0) })), disc: m2(v.disc || 0), rate: Math.round((+v.rate || 0) * 100),
        rt: (v.rt || []).map((r, i) => ({ id: r.id, no: 'RET-' + pad(S.seq.ret++, 4), req: null, date: r.d, ts: r.d + 'T12:00:00.000Z', lines: [{ k: r.k, q: q3(r.q) }], by: null, mig: true })),
        by: null, note: '', mig: true
      };
      S.inv.push(inv);
      const paid = m2(v.paid || 0);
      if (paid !== 0) S.cash.push({ id: 'cash-mig-' + v.id, ts: inv.ts, date: v.date, cur: base, amt: paid, fx: 1000000, kind: 'sale', ref: { t: 'inv', id: v.id }, method: 'cash', by: null, note: 'مرحّل من النسخة القديمة' });
      rep.inv++;
      const nt = calcInv(inv).totEff, ot = m2(oldTot(v));
      if (nt !== ot) rep.changed.push({ no: v.no, old: ot, now: nt });
    });
    (v1.exp || []).forEach(e => {
      const a = m2(e.a); if (a <= 0) return;
      S.exp.push({ id: e.id, req: 'mig-' + e.id, date: e.d, ts: e.d + 'T12:00:00.000Z', n: e.n, cat: '', a, cur: base, fx: 1000000, by: null, mig: true });
      S.cash.push({ id: 'cash-mig-' + e.id, ts: e.d + 'T12:00:00.000Z', date: e.d, cur: base, amt: -a, fx: 1000000, kind: 'expense', ref: { t: 'exp', id: e.id }, method: 'cash', by: null, note: 'مرحّل من النسخة القديمة' });
    });
    S.seq.inv = Math.max(1, +v1.seq || 1);
    rep.products = S.prod.length; rep.customers = S.cust.length;
    if (legacyPw) S.users.push({ id: 'u-admin', name: 'المدير', user: 'admin', legacy: legacyPw, role: 'admin', perms: ROLES.admin.perms.slice(), maxDisc: 10000, active: true });
    S.mig = { from: 1, at: ts, report: rep };
    auditRec(S, null, 'migrate', null, 'ترحيل من النسخة القديمة: ' + rep.inv + ' فاتورة، ' + rep.products + ' منتج، ' + rep.customers + ' عميل، ' + rep.changed.length + ' فاتورة تغيّر إجماليها بفروق تقريب', ts);
    return { state: S, report: rep };
  }

  return {
    PERMS, ROLES, newState, Engine, migrate, calcDoc, calcInv, calcPur, paidMap, purPaidMap, invView, purView, balances, cashBalances,
    reconcileList, reconcileQuick, auditOk, agingReport, salesRows, profitLoss, periodReport, stockReport, statement, hashPw, legacyHash,
    can, curDef, decOf, toBase, localDate, fxFor
  };
});
