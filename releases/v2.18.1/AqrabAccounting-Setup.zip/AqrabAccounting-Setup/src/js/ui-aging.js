/* ui-aging.js — تقرير أعمار الديون (للقراءة فقط) */
'use strict';
FLT.ag = FLT.ag || { k: 'cust', cur: '', hide0: true };
function agRows() { const f = FLT.ag; return Engine.agingReport(S(), f.k, AQ.en.today()).filter(r => !f.cur || r.cur === f.cur); }
function repAging() {
  const f = FLT.ag, rows = agRows(), s = S();
  const sums = {}; rows.forEach(r => { const t = sums[r.cur] = sums[r.cur] || { b0: 0, b30: 0, b60: 0, b90: 0, credit: 0, total: 0 }; ['b0', 'b30', 'b60', 'b90', 'credit', 'total'].forEach(k => { t[k] += r[k]; }); });
  const cell = (v, c, bad) => (v ? `<span class="${bad ? 'bd' : ''}">${fm(v, c)}</span>` : '<span class=mu>—</span>');
  const body = rows.map(r => [esc(r.n), r.cur, cell(r.b0, r.cur), cell(r.b30, r.cur), cell(r.b60, r.cur, true), cell(r.b90, r.cur, true), cell(r.credit, r.cur), `<b>${fm(r.total, r.cur)}</b>`, r.count ? r.oldest + ' يوم' : '—', btn('agStmt', 'كشف الحساب', { id: r.id })]);
  const tot = Object.keys(sums).map(c => { const t = sums[c]; return ['<b>الإجمالي</b>', c, fm(t.b0, c), fm(t.b30, c), fm(t.b60, c), fm(t.b90, c), fm(t.credit, c), `<b>${fm(t.total, c)}</b>`, '', '']; });
  return `<div class=cd><div class=tb><label>النوع<select data-c=agk><option value=cust${f.k === 'cust' ? ' selected' : ''}>ديون العملاء (لنا)</option><option value=sup${f.k === 'sup' ? ' selected' : ''}>ديون الموردين (علينا)</option></select></label>
  <label>العملة<select data-c=agcur>${optsHTML(s.set.cur.map(c => [c.code, c.code]), f.cur, 'الكل')}</select></label><button class=g2 data-a=xlAging>📥 تصدير Excel</button></div>
  <p class=mu style="margin-top:0">عمر الدين = المدة من تاريخ الفاتورة حتى اليوم (${esc(AQ.en.today())}). الفواتير الملغاة لا تدخل، والرصيد الدائن (دفع زائد) يظهر منفصلًا ولا يُخصم من الشرائح.</p>
  ${tbl(['الاسم', 'العملة', '0–30 يوم', '31–60 يوم', '61–90 يوم', 'أكثر من 90', 'رصيد دائن', 'الإجمالي المستحق', 'أقدم فاتورة', ''], body.concat(rows.length ? tot : []), 'لا توجد ديون مستحقة 🎉')}</div>`;
}
CHG.agk = v => { FLT.ag.k = v; render(); }; CHG.agcur = v => { FLT.ag.cur = v; render(); };
ACT.agStmt = d => { FLT.st.k = FLT.ag.k; FLT.st.id = d.id; AQ.sub.reports = 'stmt'; render(); };
ACT.xlAging = () => {
  const rows = agRows(), f = FLT.ag;
  xlDo(f.k === 'cust' ? 'اعمار_ديون_العملاء' : 'اعمار_ديون_الموردين', [{ name: 'أعمار الديون', head: ['الاسم', 'العملة', '0–30 يوم', '31–60 يوم', '61–90 يوم', 'أكثر من 90', 'رصيد دائن', 'الإجمالي المستحق', 'عدد الفواتير غير المسددة', 'عمر أقدم فاتورة (يوم)'],
    rows: rows.map(r => { const d = decOf(r.cur); return [r.n, r.cur, xN(r.b0, d), xN(r.b30, d), xN(r.b60, d), xN(r.b90, d), xN(r.credit, d), xN(r.total, d), r.count, r.count ? r.oldest : '']; }) }]);
};
