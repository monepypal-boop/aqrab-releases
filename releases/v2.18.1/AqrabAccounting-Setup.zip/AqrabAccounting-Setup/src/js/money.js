/* money.js — حسابات مالية دقيقة بالأعداد الصحيحة (بدون float)
 * - المبلغ: عدد صحيح بأصغر وحدة للعملة (سنت/فلس)، عدد المنازل = dec لكل عملة.
 * - الكمية: عدد صحيح بالألف (milli): 1.5 قطعة = 1500.
 * - النسبة: نقاط أساس (bp): 15% = 1500. سعر الصرف: micro: 1.08 = 1080000.
 * سياسة التقريب الموحدة: النصف يُقرَّب بعيدًا عن الصفر (half away from zero).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Money = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  const MAXS = 9007199254740991n;
  const big = x => (typeof x === 'bigint' ? x : BigInt(x));
  const p10 = n => 10n ** BigInt(n);

  function toNum(b) {
    if (b > MAXS || b < -MAXS) throw new RangeError('المبلغ أكبر من الحد المسموح');
    return Number(b);
  }
  /* قسمة صحيحة مع تقريب النصف بعيدًا عن الصفر (BigInt) */
  function divR(n, d) {
    n = big(n); d = big(d);
    if (d === 0n) throw new RangeError('قسمة على صفر');
    if (d < 0n) { n = -n; d = -d; }
    const neg = n < 0n; if (neg) n = -n;
    let q = n / d; const r = n % d;
    if (r * 2n >= d) q += 1n;
    return neg ? -q : q;
  }
  const mulDiv = (a, b, c) => toNum(divR(big(a) * big(b), c));
  /* سطر = سعر × كمية(milli) */
  const lineTotal = (price, qtyMilli) => mulDiv(price, qtyMilli, 1000);
  /* نسبة بالنقاط الأساسية من مبلغ */
  const pct = (amount, bp) => mulDiv(amount, bp, 10000);

  /* توزيع total على weights بأكبر باقي: المجموع يساوي total تمامًا دائمًا */
  function allocate(total, weights) {
    const n = weights.length; if (!n) return [];
    total = big(total);
    const W = weights.reduce((s, w) => s + big(w), 0n);
    if (total === 0n || W === 0n) {
      const z = new Array(n).fill(0);
      if (total !== 0n) z[0] = toNum(total); // لا أوزان: كله على أول عنصر
      return z;
    }
    const neg = total < 0n, T = neg ? -total : total;
    const base = [], rem = [];
    let used = 0n;
    for (let i = 0; i < n; i++) {
      const num = T * big(weights[i]);
      const q = num / W; base.push(q); rem.push(num % W); used += q;
    }
    let left = T - used;
    const order = rem.map((r, i) => [r, i]).sort((a, b) => (a[0] === b[0] ? a[1] - b[1] : a[0] < b[0] ? 1 : -1));
    for (let k = 0; left > 0n && k < order.length; k++, left--) base[order[k][1]] += 1n;
    return base.map(q => toNum(neg ? -q : q));
  }

  /* تحويل نص إلى أعداد صحيحة بدون float. يقبل الأرقام العربية والهندية */
  const AR = { '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4', '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9', '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4', '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9' };
  function parse(str, dec) {
    if (typeof str === 'number') { if (!Number.isFinite(str)) return null; str = String(str); if (/e/i.test(str)) return null; }
    if (typeof str !== 'string') return null;
    let s = str.replace(/[٠-٩۰-۹]/g, c => AR[c]).replace(/[٫]/g, '.').replace(/[٬,\s‎‏⁦⁩]/g, '').trim();
    if (!/^[+-]?(\d+\.?\d*|\.\d+)$/.test(s)) return null;
    let neg = false;
    if (s[0] === '-' || s[0] === '+') { neg = s[0] === '-'; s = s.slice(1); }
    let [i, f = ''] = s.split('.');
    i = i || '0';
    let digits, extra = '';
    if (f.length > dec) { extra = f.slice(dec); f = f.slice(0, dec); }
    digits = BigInt(i + f.padEnd(dec, '0'));
    if (extra && extra.charCodeAt(0) >= 53) digits += 1n; // النصف يُقرَّب للأعلى (مطلقًا)
    return toNum(neg ? -digits : digits);
  }
  const parseQty = s => parse(s, 3);
  const parsePct = s => parse(s, 2);      // "15" → 1500 bp
  const parseRate = s => parse(s, 6);     // "1.08" → 1080000

  const group = i => i.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  function fmt(minor, dec, opt) {
    opt = opt || {};
    const neg = minor < 0, a = String(Math.abs(minor)).padStart(dec + 1, '0');
    const i = a.slice(0, a.length - dec), f = dec ? a.slice(-dec) : '';
    return (neg ? '-' : '') + (opt.nogroup ? i : group(i)) + (dec ? '.' + f : '');
  }
  function fmtScaled(v, dec, trim) {
    let s = fmt(v, dec, { nogroup: true });
    if (trim && s.includes('.')) s = s.replace(/0+$/, '').replace(/\.$/, '');
    return s;
  }
  const fmtQty = q => group2(fmtScaled(q, 3, true));
  const group2 = s => { const [i, f] = s.replace('-', '').split('.'); return (s[0] === '-' ? '-' : '') + group(i) + (f ? '.' + f : ''); };
  const fmtPct = bp => fmtScaled(bp, 2, true);
  const fmtRate = r => fmtScaled(r, 6, true);

  /* تحويل مبلغ من عملة إلى الأساس: rate = كم وحدة أساس لكل 1 من العملة (micro) */
  const toBase = (amt, decFrom, decBase, rate) => toNum(divR(big(amt) * p10(decBase) * big(rate), p10(decFrom) * 1000000n));
  const fromBase = (amt, decBase, decTo, rate) => toNum(divR(big(amt) * p10(decTo) * 1000000n, p10(decBase) * big(rate)));

  return { divR, mulDiv, lineTotal, pct, allocate, parse, parseQty, parsePct, parseRate, fmt, fmtQty, fmtPct, fmtRate, toBase, fromBase, toNum };
});
