/* ui-quote.js — عروض الأسعار: تُحفظ من نقطة البيع، وتُدار من «المبيعات ← عروض الأسعار»، وتُحوَّل إلى فاتورة بخطوة واحدة ذرّية. */
'use strict';
FLT.qt = FLT.qt || { q: '', st: '' };
const QTST = { open: ['مفتوح', 'wn'], converted: ['حُوِّل لفاتورة', 'ok'], cancelled: ['ملغى', 'bd'] };
const qtExpired = q => q.status === 'open' && q.valid < AQ.en.today();
const qtStatus = q => (qtExpired(q) ? chip('منتهي الصلاحية', 'bd') : chip(QTST[q.status][0], QTST[q.status][1]));
const qtTot = q => Engine.calcDoc(q, 'pr').tot;

/* ---- قائمة العروض ---- */
function salesQt() {
  const f = FLT.qt, q = f.q.trim().toLowerCase();
  let list = (S().qt || []).slice().reverse().filter(x => (!q || x.no.toLowerCase().includes(q) || nrm(x.cn).includes(nrm(q)) || (x.invNo || '').toLowerCase().includes(q)) && (!f.st || (f.st === 'expired' ? qtExpired(x) : x.status === f.st)));
  const rows = list.slice(0, 300).map(x => {
    const open = x.status === 'open', acts = [btn('qtPrint', '🖨 طباعة', { id: x.id })];
    if (open) acts.push(btn('qtConvert', 'تحويل لفاتورة', { id: x.id }, 'ok'), btn('qtEdit', 'تعديل', { id: x.id }), btn('qtCancel', 'إلغاء', { id: x.id }, 'dl'));
    return [`<b>${esc(x.no)}</b>${x.edits ? ' ' + chip('معدّل ' + x.edits, '') : ''}`, x.date, qtExpired(x) ? `<span class=bd>${x.valid}</span>` : x.valid, esc(x.cn), `<b>${fm(qtTot(x), x.cur)}</b>`, qtStatus(x) + (x.status === 'converted' ? ' <small class=mu>' + esc(x.invNo) + '</small>' : x.status === 'cancelled' ? ' <small class=mu>' + esc((x.cancel || {}).reason || '') + '</small>' : ''), acts.join(' ')];
  });
  return `<div class=cd><div class=tb><label>بحث برقم العرض أو العميل أو رقم الفاتورة<input data-c=qtq value="${esc(f.q)}" placeholder="مثال: QT-0003"></label>
  <label>الحالة<select data-c=qtst><option value="">الكل</option><option value=open${f.st === 'open' ? ' selected' : ''}>مفتوح</option><option value=expired${f.st === 'expired' ? ' selected' : ''}>منتهي الصلاحية</option><option value=converted${f.st === 'converted' ? ' selected' : ''}>حُوِّل لفاتورة</option><option value=cancelled${f.st === 'cancelled' ? ' selected' : ''}>ملغى</option></select></label>
  <button class=btn data-a=qtNew>📝 عرض سعر جديد</button></div>
  <p class=mu style="margin-top:0">عرض السعر لا يحجز مخزونًا ولا يدخل في المبيعات أو الأرباح أو الذمم إلا بعد تحويله إلى فاتورة. لإنشاء عرض: أضف المنتجات في نقطة البيع ثم اضغط «حفظ كعرض سعر».</p>
  ${tbl(['الرقم', 'التاريخ', 'صالح حتى', 'العميل', 'الإجمالي', 'الحالة', ''], rows, 'لا توجد عروض أسعار.')}${notice(300, list.length)}</div>`;
}
CHG.qtq = v => { FLT.qt.q = v; render(); }; CHG.qtst = v => { FLT.qt.st = v; render(); };
ACT.qtNew = () => { posReset(); POS.qm = null; AQ.tab = 'pos'; go('pos'); toast('أضف المنتجات ثم اضغط «حفظ كعرض سعر»', 'ok'); };

/* ---- حفظ عرض من السلة ---- */
function posQuoteBase() {
  const k = posCalc(); if (k.bad || k.exErr) { toast(k.bad || k.exErr, 'err'); return null; }
  if (!POS.lines.length) { toast('السلة فارغة', 'err'); return null; }
  return { k, o: { c: POS.c, cur: POS.cur, fx: posRate(), items: POS.lines.map(l => ({ p: l.p, q: l.q, pr: l.pr })), ex: k.ex, disc: k.disc, rate: S().set.taxBp, user: AQ.me } };
}
ACT.posQuote = () => {
  const b = posQuoteBase(); if (!b) return;
  const cust = POS.c ? S().cust.find(x => x.id === POS.c) : null;
  $('#md').innerHTML = `<div class=ov><div class=bx><h3>حفظ كعرض سعر</h3>
  ${cust ? `<p>العميل: <b>${esc(cust.n)}</b></p>` : '<label>اسم العميل / الجهة (اختياري)<input id=qcn maxlength=80 placeholder="يظهر على العرض المطبوع"></label>'}
  <label>صلاحية العرض (أيام)<input id=qdays value=15 inputmode=numeric></label>
  <label>ملاحظة تظهر على العرض (اختياري)<input id=qnote maxlength=300 placeholder="مثال: الأسعار شاملة التركيب"></label>
  <p class=mu>المجموع: <b>${fm(b.k.c.tot, POS.cur)}</b> — لن يتأثر المخزون ولا الحسابات.</p><p id=er class=bd></p>
  <div class=ac><button class=btn id=qok>حفظ العرض</button><button class=g2 data-a=close>إلغاء</button></div></div></div>`;
  $('#qok').onclick = () => {
    const days = parseInt($('#qdays').value, 10);
    if (!(days >= 1 && days <= 365)) { $('#er').textContent = 'صلاحية العرض بين 1 و365 يومًا'; return; }
    try {
      const r = AQ.en.createQuote(Object.assign({ req: AQ.en.uid(), date: AQ.en.today(), days, note: $('#qnote').value, cn: $('#qcn') ? $('#qcn').value : '' }, b.o));
      posReset(); POS.qm = null; closeModal(); render();
      setTimeout(() => info('تم حفظ عرض السعر', `<p>رقم العرض: <b>${esc(r.no)}</b> — الإجمالي: <b>${fm(r.tot, POS.cur || baseCode())}</b></p><div class=ac><button class=btn data-a=qtPrint data-id="${r.id}">🖨 طباعة العرض (A5)</button></div>`), 60);
    } catch (e) { $('#er').textContent = e.message; }
  };
};

/* ---- تعديل عرض: يُحمَّل في السلة ثم يُحفظ ---- */
function qtLoad(qt, mode) {
  posReset(); POS.c = qt.c; POS.cur = qt.cur; POS.disc = '';
  POS.lines = qt.items.map(x => ({ p: x.p, q: x.q, pr: x.pr }));
  POS.ex = qt.ex.map(e => ({ l: e.l, as: Money.fmt(e.a, decOf(qt.cur), { nogroup: true }) }));
  if (qt.disc) { POS.dmode = 'amt'; POS.disc = Money.fmt(qt.disc, decOf(qt.cur), { nogroup: true }); }
  POS.qm = { kind: mode, id: qt.id, no: qt.no, note: qt.note, valid: qt.valid, cn: qt.cn };
  AQ.tab = 'pos'; go('pos');
}
ACT.qtEdit = d => { const qt = (S().qt || []).find(x => x.id === d.id); if (qt && qt.status === 'open') qtLoad(qt, 'edit'); };
ACT.qtConvert = d => {
  const qt = (S().qt || []).find(x => x.id === d.id); if (!qt || qt.status !== 'open') return;
  const go2 = () => qtLoad(qt, 'convert');
  if (qtExpired(qt)) ask('عرض منتهي الصلاحية', `انتهت صلاحية العرض ${esc(qt.no)} بتاريخ ${qt.valid}. قد تكون الأسعار تغيّرت. هل تريد تحويله لفاتورة؟ (سيُحمَّل في نقطة البيع ويمكنك مراجعة الأسعار قبل الإتمام).`, go2, 'متابعة'); else go2();
};
ACT.posQuoteSave = () => {
  const b = posQuoteBase(); if (!b || !POS.qm) return;
  try {
    const r = AQ.en.updateQuote(POS.qm.id, Object.assign({ note: POS.qm.note, valid: POS.qm.valid, cn: POS.qm.cn }, b.o));
    const id = POS.qm.id; posReset(); POS.qm = null; render();
    setTimeout(() => info('تم حفظ تعديلات العرض', `<p>${esc(r.no)} — الإجمالي: <b>${fm(r.tot, baseCode())}</b></p><div class=ac><button class=btn data-a=qtPrint data-id="${id}">🖨 طباعة العرض (A5)</button></div>`), 60);
    AQ.sub.sales = 'qt'; AQ.tab = 'sales'; go('sales');
  } catch (e) { fail(e); }
};
ACT.posQuoteExit = () => ask('إنهاء الوضع', 'إلغاء ' + (POS.qm.kind === 'edit' ? 'تعديل' : 'تحويل') + ' العرض وتفريغ السلة؟ (العرض نفسه لا يتغير).', () => { posReset(); POS.qm = null; render(); }, 'نعم');
ACT.qtCancel = d => {
  const qt = (S().qt || []).find(x => x.id === d.id); if (!qt) return;
  form({ title: 'إلغاء عرض السعر ' + qt.no, msg: 'لا يُحذف العرض، بل يبقى في السجل بحالة «ملغى».', fields: [{ k: 'reason', l: 'سبب الإلغاء (إلزامي)', req: true }], ok: 'إلغاء العرض', submit: v => { AQ.en.cancelQuote(qt.id, { reason: v.reason, user: AQ.me }); render(); } });
};

/* ---- طباعة A5 ---- */
ACT.qtPrint = d => {
  const q = (S().qt || []).find(x => x.id === d.id); if (!q) return;
  const c = Engine.calcDoc(q, 'pr'), co = S().co, set = S().set, cu = (S().cust || []).find(x => x.id === q.c);
  const rows = q.items.map((x, k) => `<tr><td class=cen>${k + 1}</td><td>${esc(x.n)}</td><td class=num>${fq(x.q)}</td><td class=num>${fm(x.pr, q.cur)}</td><td class=num>${fm(c.lines[k].total, q.cur)}</td></tr>`).join('');
  const tr = (l, val, cls) => `<tr class="${cls || ''}"><td>${l}</td><td class=num>${val}</td></tr>`;
  const exSum = q.ex.reduce((a, e) => a + e.a, 0);
  const exRows = q.ex.length ? `<tr class=exh><td colspan=2>رسوم إضافية (غير مشمولة في الإجمالي أعلاه)</td></tr>` + q.ex.map(e => `<tr class=exr><td>${esc(e.l)}</td><td class=num>${fm(e.a, q.cur)}</td></tr>`).join('') + tr('الإجمالي مع الرسوم الإضافية', fm(c.tot + exSum, q.cur), 'exs') : '';
  const stt = q.status === 'cancelled' ? ['ملغى', 'vd'] : q.status === 'converted' ? ['حُوِّل إلى فاتورة ' + q.invNo, 'pd'] : qtExpired(q) ? ['منتهي الصلاحية', 'vd'] : ['ساري', 'pd'];
  printHTML(`<div class="a4 a5">
  <div class=a4h><div class=a4co>${set.logo ? `<img class=a4logo src="${esc(set.logo)}" alt="">` : ''}<div><h1>${esc(co.n)}</h1><div class=sm>${esc(co.ad)}${co.ph ? '<br>هاتف: ' + esc(co.ph) : ''}${co.tx ? '<br>الرقم الضريبي: ' + esc(co.tx) : ''}</div></div></div>
    <div class=a4ti><h2>عرض سعر</h2><table class=meta><tr><td>رقم العرض</td><td><b>${esc(q.no)}</b></td></tr><tr><td>التاريخ</td><td>${esc(q.date)}</td></tr><tr><td>صالح حتى</td><td><b>${esc(q.valid)}</b></td></tr><tr><td>الحالة</td><td><span class="stt ${stt[1]}">${esc(stt[0])}</span></td></tr></table></div></div>
  <div class=a4cu><div><span>السادة</span><b>${esc(q.cn)}</b></div>${cu && cu.ph ? `<div><span>الهاتف</span><b>${esc(cu.ph)}</b></div>` : ''}${cu && cu.ad ? `<div><span>العنوان</span><b>${esc(cu.ad)}</b></div>` : ''}</div>
  <table class=a4t><thead><tr><th style="width:26px">#</th><th>البيان</th><th style="width:52px">الكمية</th><th style="width:72px">السعر</th><th style="width:80px">الإجمالي</th></tr></thead><tbody>${rows}</tbody></table>
  <div class=a4b><div class=a4n>${q.note ? `<h5>ملاحظات العرض</h5><div>${esc(q.note)}</div>` : ''}<h5>شروط</h5><div>هذا العرض للتسعير فقط وليس فاتورة، والأسعار سارية حتى ${esc(q.valid)} وقابلة للتغيير بعده، والكميات حسب التوفر عند التنفيذ.${set.terms ? '<br>' + esc(set.terms).replace(/\n/g, '<br>') : ''}</div></div>
    <table class=a4s>${tr('المجموع', fm(c.sub, q.cur))}${c.disc ? tr('الخصم', fm(c.disc, q.cur)) : ''}${c.tax ? tr('الضريبة (' + Money.fmtPct(q.rate) + '%)', fm(c.tax, q.cur)) : ''}${tr('إجمالي العرض', fm(c.tot, q.cur), 'tot')}${exRows}</table></div>
  <div class=a4g><div>موافقة العميل</div><div>ختم وتوقيع المتجر</div></div><div class=a4f>${esc(set.rfoot)}</div></div>`, 'a5');
};
