/* ui-edit.js — محرر الفواتير الشامل بعد البيع (يستبدل ACT.invEdit القديم). المنطق كله في Engine.amendSale؛ هنا واجهة فقط. */
'use strict';
const IE = { id: '', rows: [], ex: [], cur: '', dec: 2 };
const ieInv = () => S().inv.find(x => x.id === IE.id);
const ieUser = id => { const u = S().users.find(x => x.id === id); return u ? u.name : '—'; };
const ieRetQ = (i, k) => (i.rt || []).filter(r => !r.void).reduce((a, r) => a + r.lines.filter(l => l.k === k).reduce((x, l) => x + l.q, 0), 0);
const ieUsed = (i, k) => (i.rt || []).some(r => r.lines.some(l => l.k === k));
function ieProdOpts(sel, locked) {
  const list = locked ? S().prod.filter(p => p.id === sel) : S().prod.filter(p => !p.arch || p.id === sel);
  return list.map(p => `<option value="${esc(p.id)}"${p.id === sel ? ' selected' : ''}>${esc(p.n)} (${Money.fmtQty(p.q)})</option>`).join('');
}
function ieRowsHTML() {
  const i = ieInv();
  return IE.rows.map((r, k) => {
    const rq = r.k != null ? ieRetQ(i, r.k) : 0, used = r.k != null && ieUsed(i, r.k);
    return `<div class=lerow><select data-c=iep data-k=${k}${used ? ' disabled' : ''}>${ieProdOpts(r.p, used)}</select>
<input data-i=ieq data-k=${k} value="${esc(r.qs)}" inputmode=decimal title="الكمية${rq ? ' (المرتجع المسجل ' + Money.fmtQty(rq) + ')' : ''}">
<input data-i=iepr data-k=${k} value="${esc(r.ps)}" inputmode=decimal title="السعر"><span class=lt id=iet_${k}></span>
<button class=s data-a=ieDel data-k=${k} ${used ? 'disabled title="لا يمكن حذف بند له مرتجعات"' : ''}>✕</button></div>${rq ? `<div class=mu style="font-size:12px;margin:-4px 0 6px">⮌ مرتجع مسجل: ${Money.fmtQty(rq)} — لا يمكن أن تقل الكمية عنه</div>` : ''}`;
  }).join('');
}
function ieExHTML() {
  return IE.ex.map((r, k) => `<div class=exrow><input list=exsug data-i=iexl data-k=${k} value="${esc(r.l)}" placeholder="البيان (مثال: أجور توصيل)" maxlength=60><input data-i=iexa data-k=${k} value="${esc(r.as)}" placeholder="المبلغ" inputmode=decimal style="direction:ltr;text-align:center"><button class="s dl" data-a=ieExDel data-k=${k} title="حذف">🗑</button></div>`).join('');
}
ACT.ieExAdd = () => { if (IE.ex.length >= 5) return; IE.ex.push({ l: '', as: '' }); $('#ieex').innerHTML = ieExHTML(); };
ACT.ieExDel = d => { IE.ex.splice(+d.k, 1); $('#ieex').innerHTML = ieExHTML(); };
INP.iexl = (v, t) => { IE.ex[+t.dataset.k].l = v; }; INP.iexa = (v, t) => { IE.ex[+t.dataset.k].as = v; };
function ieParse() {
  const dec = IE.dec;
  const items = IE.rows.map(r => ({ k: r.k, p: r.p, q: Money.parse(r.qs, 3), pr: Money.parse(r.ps, dec) }));
  const bad = items.some(x => x.q === null || x.q <= 0 || x.pr === null || x.pr < 0);
  let disc = 0, derr = ''; const ds = ($('#ied') || {}).value || '';
  if (ds.trim() !== '') { const d = Money.parse(ds, dec); if (d === null || d < 0) derr = 'الخصم غير صحيح'; else disc = d; }
  return { items, bad, disc, derr };
}
function ieTot() {
  const i = ieInv(), o = ieParse(), el = $('#ietot'); if (!el) return;
  if (o.bad || o.derr) { el.innerHTML = `<span class=bd>${o.derr || 'تحقق من الكميات والأسعار'}</span>`; return; }
  const sub = o.items.reduce((s, x) => s + Money.lineTotal(x.pr, x.q), 0);
  if (o.disc > sub) { el.innerHTML = '<span class=bd>الخصم أكبر من المجموع</span>'; return; }
  // معاينة بنفس معادلة المحرك، بما فيها المرتجعات المسجلة
  const map = {}; o.items.forEach((x, n) => { if (x.k != null) map[x.k] = n; });
  const rt = (i.rt || []).map(r => Object.assign({}, r, { lines: r.lines.map(l => ({ k: map[l.k] != null ? map[l.k] : 0, q: l.q })) }));
  const t = { items: o.items.map(x => ({ q: x.q, pr: x.pr, co: 0 })), disc: o.disc, rate: i.rate, rt };
  let c; try { c = Engine.calcDoc(t, 'pr'); } catch (e) { el.innerHTML = '<span class=bd>تحقق من البنود</span>'; return; }
  o.items.forEach((x, k) => { const e = $('#iet_' + k); if (e) e.innerHTML = fm(c.lines[k].total, IE.cur); });
  const paidOld = Engine.invView(S(), i).paid, pv = ($('#iepay') || {}).value;
  let paid = paidOld; if (pv != null && pv.trim() !== '') { const v = Money.parse(pv, IE.dec); if (v !== null) paid = v; }
  const due = c.totEff - paid;
  el.innerHTML = `المجموع <b>${fm(c.sub, IE.cur)}</b> | الصافي <b>${fm(c.net, IE.cur)}</b> | الضريبة <b>${fm(c.tax, IE.cur)}</b> | الإجمالي <b>${fm(c.tot, IE.cur)}</b>${c.tot !== c.totEff ? ` | بعد المرتجعات <b>${fm(c.totEff, IE.cur)}</b>` : ''}<br>
الإجمالي السابق <b>${fm(Engine.calcInv(i).totEff, IE.cur)}</b> ← الجديد <b>${fm(c.totEff, IE.cur)}</b> | المدفوع <b>${fm(paid, IE.cur)}</b> | ${due > 0 ? `المتبقي <b class=bd>${fm(due, IE.cur)}</b>` : due < 0 ? `رصيد للعميل <b class=ok>${fm(-due, IE.cur)}</b>` : '<b class=ok>مسدّدة</b>'}`;
}
INP.ieq = (v, el) => { IE.rows[+el.dataset.k].qs = v; ieTot(); };
INP.iepr = (v, el) => { IE.rows[+el.dataset.k].ps = v; ieTot(); };
INP.ied = () => ieTot(); INP.iepay = () => ieTot();
CHG.iep = (v, el) => { const r = IE.rows[+el.dataset.k], p = S().prod.find(x => x.id === v); r.p = v; if (p) r.ps = Money.fmt(IE.cur === baseCode() ? p.pr : Money.fromBase(p.pr, decOf(baseCode()), IE.dec, ieInv().fx), IE.dec, { nogroup: true }); $('#ierows').innerHTML = ieRowsHTML(); ieTot(); };
ACT.ieDel = d => { if (IE.rows.length <= 1) return toast('يجب أن تبقى الفاتورة ببند واحد على الأقل', 'err'); IE.rows.splice(+d.k, 1); $('#ierows').innerHTML = ieRowsHTML(); ieTot(); };
ACT.ieAdd = () => {
  const p = S().prod.find(x => !x.arch); if (!p) return toast('أضف منتجًا أولًا', 'err');
  IE.rows.push({ k: null, p: p.id, qs: '1', ps: Money.fmt(IE.cur === baseCode() ? p.pr : Money.fromBase(p.pr, decOf(baseCode()), IE.dec, ieInv().fx), IE.dec, { nogroup: true }) });
  $('#ierows').innerHTML = ieRowsHTML(); ieTot();
};
function ieHist(i) {
  const rev = i.rev || []; if (!rev.length) return '<p class=mu style="margin:6px 0">لم تُعدَّل هذه الفاتورة بعد إصدارها.</p>';
  return tbl(['التاريخ', 'بواسطة', 'الإجمالي قبل ← بعد', 'السبب'], rev.slice().reverse().map(v => [esc(String(v.ts).slice(0, 16).replace('T', ' ')), esc(ieUser(v.by)), `${fm(v.before.tot, i.cur)} ← ${fm(v.after.tot, i.cur)}`, esc(v.reason || '—')]));
}
ACT.invEdit = d => {
  const i = S().inv.find(x => x.id === d.id); if (!i) return;
  if (i.void) return toast('الفاتورة ملغاة ولا تُعدَّل', 'err');
  IE.id = i.id; IE.cur = i.cur; IE.dec = decOf(i.cur);
  IE.ex = (i.ex || []).map(e => ({ l: e.l, as: Money.fmt(e.a, IE.dec, { nogroup: true }) }));
  IE.rows = i.items.map((x, k) => ({ k, p: x.p, qs: Money.fmtQty(x.q).replace(/,/g, ''), ps: Money.fmt(x.pr, IE.dec, { nogroup: true }) }));
  const s = S(), v = Engine.invView(s, i);
  $('#md').innerHTML = `<div class=ov><div class="bx wide"><h3>تعديل ${esc(i.no)} <small class=mu style="font-weight:400">— العملة ${esc(i.cur)} وسعر الصرف والرقم لا يتغيّران</small></h3>
<div class=tb><label>العميل<select id=iec>${optsHTML(s.cust.filter(c => !c.arch || c.id === i.c).map(c => [c.id, c.n]), i.c, 'عميل نقدي')}</select></label>
<label>المندوب<select id=ier>${optsHTML(s.rep.filter(c => !c.arch || c.id === i.r).map(c => [c.id, c.n]), i.r, 'بدون')}</select></label>
<label>التاريخ<input type=date id=iedt value="${esc(i.date)}"></label></div>
<div class=lerow style="font-size:12px;color:var(--mu)"><span>المنتج (المتاح)</span><span>الكمية</span><span>السعر</span><span>الإجمالي</span><span></span></div>
<div id=ierows>${ieRowsHTML()}</div><button class=s data-a=ieAdd>+ إضافة بند</button>
<details style="margin-top:10px"${IE.ex.length ? ' open' : ''}><summary style="cursor:pointer;font-weight:700">رسوم إضافية للطباعة (اختياري — لا تدخل في الإجمالي ولا الأرباح)</summary><datalist id=exsug>${EX_SUG.map(x => `<option value="${x}">`).join('')}</datalist><div id=ieex>${ieExHTML()}</div><button class=s data-a=ieExAdd>+ إضافة رسم</button></details>
<div class=tb style="margin-top:10px"><label>الخصم (${esc(i.cur)})<input id=ied data-i=ied value="${Money.fmt(i.disc, IE.dec, { nogroup: true })}" inputmode=decimal></label>
<label>المدفوع الكلي (${esc(i.cur)}) — عدّله لتسجيل دفعة أو ردّ<input id=iepay data-i=iepay value="${Money.fmt(v.paid, IE.dec, { nogroup: true })}" inputmode=decimal></label>
<label>طريقة الدفع/الرد<select id=iem>${optsHTML(METHODS, 'cash')}</select></label></div>
<div class=tb><label>ملاحظة على الفاتورة<input id=ien value="${esc(i.note || '')}"></label><label>سبب التعديل (يُسجَّل في السجل)<input id=ier2 placeholder="مثال: تصحيح كمية"></label></div>
<div id=ietot class=cd style="margin:8px 0"></div>
<details><summary style="cursor:pointer;font-weight:700">سجل التعديلات (${(i.rev || []).length})</summary>${ieHist(i)}</details>
<p class=mu style="font-size:12.5px">لا يُحذف أي قيد دفع سابق: تغيير المدفوع يضيف قيد تحصيل أو ردّ جديدًا، وكل تعديل يُسجَّل في سجل التدقيق مع الحالة السابقة، وتتحدّث المخزون والتقارير تلقائيًا.</p>
<p id=er class=bd></p><div class=ac><button class=btn id=iesave>حفظ التعديل</button><button class=g2 data-a=close>إلغاء</button></div></div></div>`;
  ieTot();
  $('#iesave').onclick = () => {
    try {
      const o = ieParse(); if (o.bad || o.derr) throw new Error(o.derr || 'تحقق من الكميات والأسعار');
      const pv = $('#iepay').value; let paid; if (pv.trim() !== '') { paid = Money.parse(pv, IE.dec); if (paid === null || paid < 0) throw new Error('المدفوع غير صحيح'); if (paid === v.paid) paid = undefined; }
      const ex = []; const exe = exParse(IE.ex, IE.dec, ex); if (exe) throw new Error(exe);
      const r = AQ.en.amendSale(IE.id, { ex, items: o.items, disc: o.disc, c: $('#iec').value, r: $('#ier').value, date: $('#iedt').value, note: $('#ien').value, reason: $('#ier2').value, paid, method: $('#iem').value, user: AQ.me });
      closeModal(); toast('تم تعديل الفاتورة — الإجمالي الجديد ' + Money.fmt(r.tot, IE.dec) + ' ' + IE.cur, 'ok'); render();
    } catch (e) { $('#er').textContent = /بالآجل يتطلب/.test(e.message) ? 'الفاتورة بلا عميل ولا يمكن أن يبقى فيها مبلغ متبقٍ: اختر عميلاً، أو اجعل «المدفوع» مساوياً للإجمالي الجديد.' : e.message; }
  };
};
