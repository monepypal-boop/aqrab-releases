/* سندات القبض والصرف (طباعة A5). لا تغيّر أي بيانات؛ تُبنى من حركة الصندوق المسجلة. */
let VCH = null;
function vchDone(v) { // بعد تحصيل/سداد ناجح
  VCH = v;
  setTimeout(() => info(v.kind === 'in' ? 'تم التحصيل بنجاح' : 'تم السداد بنجاح', `<p style="font-size:16px"><b>${fm(v.amt, v.cur)}</b> ${esc(v.cur)} — ${esc(vchPartyName(v))}</p><div class=ac style="justify-content:flex-start"><button class=btn data-a=vchPrint>🖨 طباعة ${v.kind === 'in' ? 'سند قبض' : 'سند صرف'} (A5)</button></div>`), 80);
}
function vchPartyName(v) { const s = S(), e = (v.pk === 'cust' ? s.cust : s.sup).find(x => x.id === v.pid); return e ? e.n : (v.pn || 'نقدي'); }
function vchPrint(v) {
  const s = S(), co = s.co, set = s.set, dec = decOf(v.cur), who = vchPartyName(v);
  const isIn = v.kind === 'in', bal = v.pid ? ((Engine.balances(s, v.pk)[v.pid] || {})[v.cur] || 0) : null;
  printHTML(`<div class="a4 a5">
  <div class=a4h><div class=a4co>${set.logo ? `<img class=a4logo src="${esc(set.logo)}" alt="">` : ''}<div><h1>${esc(co.n)}</h1><div class=sm>${esc(co.ad)}${co.ph ? '<br>هاتف: ' + esc(co.ph) : ''}</div></div></div>
    <div class=a4ti><h2>${isIn ? 'سند قبض' : 'سند صرف'}</h2><table class=meta><tr><td>التاريخ</td><td><b>${esc(v.date)}</b></td></tr><tr><td>طريقة الدفع</td><td>${esc(METHOD_L[v.method] || v.method || '')}</td></tr></table></div></div>
  <div class=a4cu><div><span>${isIn ? 'استلمنا من السيد/ة' : 'دفعنا للسيد/ة'}</span><b>${esc(who)}</b></div><div><span>المبلغ</span><b>${fm(v.amt, v.cur)} ${esc(v.cur)}</b></div></div>
  ${v.parts && v.parts.length ? `<table class=a4t><thead><tr><th>عن فاتورة</th><th style="width:120px">المبلغ</th></tr></thead><tbody>${v.parts.map(p => `<tr><td>${esc(p.no)}</td><td class=num>${fm(p.a, v.cur)}</td></tr>`).join('')}</tbody></table>` : ''}
  ${bal !== null ? `<p style="margin:8px 0"><b>${isIn ? 'الرصيد المتبقي على الحساب' : 'الرصيد المتبقي للمورد'} (حتى وقت الطباعة):</b> ${fm(bal, v.cur)} ${esc(v.cur)}</p>` : ''}
  <div class=a4g><div>${isIn ? 'توقيع المستلم' : 'توقيع المستلم (المورد)'}</div><div>ختم وتوقيع المتجر</div></div></div>`, 'a5');
}
ACT.vchPrint = () => { if (VCH) vchPrint(VCH); };
ACT.vchEntry = d => { // سند لدفعة واحدة مسجلة
  const s = S(), e = s.cash.find(x => x.id === d.id); if (!e || !e.ref) return toast('الدفعة غير موجودة', 'err');
  const isIn = e.amt > 0, doc = e.ref.t === 'inv' ? s.inv.find(x => x.id === e.ref.id) : s.pur.find(x => x.id === e.ref.id);
  if (!doc) return toast('المستند غير موجود', 'err');
  const pk = e.ref.t === 'inv' ? 'cust' : 'sup', pid = pk === 'cust' ? doc.c : doc.s;
  vchPrint({ kind: isIn ? 'in' : 'out', pk, pid, pn: pk === 'cust' ? doc.cn : doc.sn, cur: e.cur, amt: Math.abs(e.amt), method: e.method, date: e.date, parts: [{ no: doc.no, a: Math.abs(e.amt) }] });
};
