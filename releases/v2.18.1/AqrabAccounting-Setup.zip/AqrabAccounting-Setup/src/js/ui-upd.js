/* ui-upd.js — بطاقة «التحديثات» في الإعدادات. لا اتصال بالإنترنت إلا عند الضغط على «التحقق». لا تثبيت تلقائي. */
const UPD = { busy: false, res: null, dl: null, pct: 0 };
function updCard() {
  if (!window.aq || !aq.updCheck) return '';
  if (!AQ.ver && !UPD.verAsk) { UPD.verAsk = 1; aq.info().then(i => { AQ.ver = i.version; if (AQ.tab === 'settings') render(); }).catch(() => {}); }
  let body = '';
  if (UPD.busy) body = `<p class=mu>${UPD.dl === 'go' ? 'جارٍ التنزيل… ' + UPD.pct + '%' : 'جارٍ التحقق…'}</p>`;
  else {
    const r = UPD.res;
    if (r && r.state === 'uptodate') body += `<p class=ok>أنت على أحدث إصدار (${esc(r.version)}).</p>`;
    if (r && r.state === 'error') body += `<p class=bd>${esc(r.error)}</p>`;
    if (r && r.state === 'available') body += `<p><b>يتوفر إصدار جديد ${esc(r.info.version)}</b>${r.info.date ? ' — ' + esc(r.info.date) : ''}</p>${r.info.notes ? `<p class=mu style="white-space:pre-wrap">${esc(r.info.notes)}</p>` : ''}`
      + (UPD.dl && UPD.dl.ok ? `<p class=ok>تم تنزيل التحديث والتحقق من سلامته. طريقة التثبيت: أغلق البرنامج، فك ضغط الملف، ثم شغّل Install.bat (بياناتك لا تتأثر، وأُخذت نسخة احتياطية).</p><button class=btn data-a=updShow>📂 فتح مجلد التحديث</button>`
        : `${UPD.dl && UPD.dl.error ? `<p class=bd>${esc(UPD.dl.error)}</p>` : ''}<button class=btn data-a=updDl>⬇ تنزيل التحديث (${fsz(r.info.size)})</button>`);
    body += `<div style="margin-top:8px"><button class=g2 data-a=updCheck>🔄 التحقق من التحديثات</button></div>`;
  }
  return `<div class=cd><h3 style="margin:0 0 6px">التحديثات</h3><p class=mu style="margin:4px 0">الإصدار الحالي: <b>${esc(AQ.ver || '')}</b></p>${body}</div>`;
}
ACT.updCheck = async () => {
  UPD.busy = true; UPD.dl = null; render();
  try { UPD.res = await aq.updCheck(); } catch (e) { UPD.res = { state: 'error', error: e.message }; }
  UPD.busy = false; if (UPD.res && UPD.res.version) AQ.ver = UPD.res.version; render();
};
ACT.updDl = async () => {
  UPD.busy = true; UPD.dl = 'go'; UPD.pct = 0; render();
  try { UPD.dl = await aq.updDownload(); } catch (e) { UPD.dl = { ok: false, error: e.message }; }
  UPD.busy = false; render();
};
ACT.updShow = () => { if (UPD.dl && UPD.dl.file) aq.updShow(UPD.dl.file); };
if (window.aq && aq.onUpdProgress) aq.onUpdProgress(p => { UPD.pct = p; if (UPD.busy && UPD.dl === 'go' && AQ.tab === 'settings') render(); });
if (typeof PAGES !== 'undefined' && PAGES.settings) { const _st2 = PAGES.settings; PAGES.settings = () => _st2() + updCard(); }
