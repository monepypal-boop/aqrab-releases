/* تفاصيل فواتير الشراء + طباعة A5 + فلاتر + تصدير Excel */
function purList() {
  const s = S(), f = FLT.pur, q = f.q.trim().toLowerCase(), pm = Engine.purPaidMap(s);
  return s.pur.slice().reverse().filter(p => {
    if (q && !(p.no.toLowerCase().includes(q) || nrm(p.sn).includes(nrm(q)) || String(p.ref || '').toLowerCase().includes(q) || (/^\d+$/.test(q) && parseInt(String(p.no).replace(/\D/g, ''), 10) === parseInt(q, 10)))) return false;
    if (f.from && p.date < f.from) return false;
    if (f.to && p.date > f.to) return false;
    if (f.s && p.s !== f.s) return false;
    return true;
  }).map(p => ({ p, v: Engine.purView(s, p, pm) })).filter(({ p, v }) => {
    if (f.st === 'void') return !!p.void;
    if (f.st === 'paid') return !p.void && v.due <= 0;
    if (f.st === 'due') return !p.void && v.due > 0;
    return true;
  });
}
CHG.purfrom = v => { FLT.pur.from = v; render(); }; CHG.purto = v => { FLT.pur.to = v; render(); };
CHG.purs = v => { FLT.pur.s = v; render(); }; CHG.purst = v => { FLT.pur.st = v; render(); };
ACT.purClear = () => { FLT.pur = { q: '', from: '', to: '', s: '', st: '' }; render(); };

function purState(p, v) { return p.void ? 'ملغاة' : v.due > 0 ? (v.paid > 0 ? 'جزئي' : 'غير مسددة') : 'مسددة'; }

ACT.purDetail = d => {
  const s = S(), p = s.pur.find(x => x.id === d.id); if (!p) return toast('الفاتورة غير موجودة', 'err');
  const v = Engine.purView(s, p), c = v.c, cur = p.cur, sp = s.sup.find(x => x.id === p.s);
  const items = p.items.map((x, k) => [k + 1, esc(x.n), fq(x.q), fm(x.co, cur), fm(c.lines[k].total, cur), c.lines[k].rq ? `<span class=bd>${fq(c.lines[k].rq)}</span>` : '']);
  const pays = s.cash.filter(e => e.ref && e.ref.t === 'pur' && e.ref.id === p.id).map(e => [e.date, KINDL[e.kind] || esc(e.kind), METHOD_L[e.method] || esc(e.method || ''), `<span class="num ${e.amt < 0 ? 'bd' : 'ok'}">${fm(e.amt, e.cur)}</span>`, esc(e.note || '') + (e.kind === 'sup-pay' ? ' ' + btn('vchEntry', '🖨 سند', { id: e.id }) : '')]);
  const rets = (p.rt || []).map(r => [esc(r.no), r.date, r.lines.map(l => esc(p.items[l.k] ? p.items[l.k].n : '?') + ' × ' + fq(l.q)).join('، ')]);
  const row = (l, val) => `<tr><td>${l}</td><td class=num>${val}</td></tr>`;
  $('#md').innerHTML = `<div class=ov><div class="bx wide"><h3>${esc(p.no)} ${p.void ? chip('ملغاة', 'mu') : v.due > 0 ? chip(v.paid > 0 ? 'جزئي' : 'غير مسددة', 'bd') : chip('مسددة', 'ok')}</h3>
  <div class=tb style="gap:6px 24px;flex-wrap:wrap"><span>التاريخ: <b>${esc(p.date)}</b></span><span>المورد: <b>${esc(p.sn)}</b>${sp && sp.ph ? ' — ' + esc(sp.ph) : ''}</span>${p.ref ? `<span>مرجع المورد: <b>${esc(p.ref)}</b></span>` : ''}<span>العملة: <b>${esc(cur)}</b></span><span>بواسطة: <b>${userName(p.by)}</b></span></div>
  ${p.note ? `<p class=mu>ملاحظة: ${esc(p.note)}</p>` : ''}
  ${p.void ? `<p class=bd>ملغاة: ${esc(p.void.reason)} — ${fdt(p.void.ts)}</p>` : ''}
  ${tbl(['#', 'البند', 'الكمية', 'سعر الشراء', 'الإجمالي', 'مرتجع'], items)}
  <table class=a4s style="max-width:380px;margin:10px 0 0 auto">${row('المجموع', fm(c.sub, cur))}${c.disc ? row('الخصم', fm(c.disc, cur)) : ''}${c.tax ? row('الضريبة (' + Money.fmtPct(p.rate) + '%)', fm(c.tax, cur)) : ''}${c.retGross ? row('المرتجعات', fm(c.retGross, cur)) : ''}${row('<b>الإجمالي</b>', '<b>' + fm(c.totEff, cur) + '</b>')}${row('المدفوع', fm(v.paid, cur))}${row('<b>المتبقي للمورد</b>', '<b>' + fm(v.due, cur) + '</b>')}</table>
  <h4 style="margin:12px 0 4px">الدفعات</h4>${pays.length ? tbl(['التاريخ', 'النوع', 'الطريقة', 'المبلغ', 'ملاحظة'], pays) : '<p class=mu style="margin:0">لا توجد دفعات مسجلة.</p>'}
  ${rets.length ? `<h4 style="margin:12px 0 4px">المرتجعات للمورد</h4>${tbl(['رقم المرتجع', 'التاريخ', 'البنود'], rets)}` : ''}
  <div class=ac><button class=btn data-a=purPrint data-id="${esc(p.id)}">🖨 طباعة A5</button>${p.s ? `<button class=g2 data-a=stmt data-k=sup data-id="${esc(p.s)}">كشف حساب المورد</button>` : ''}<button class=g2 data-a=close>إغلاق</button></div></div></div>`;
};

ACT.purPrint = d => {
  const s = S(), p = s.pur.find(x => x.id === d.id); if (!p) return toast('الفاتورة غير موجودة', 'err');
  const v = Engine.purView(s, p), c = v.c, co = s.co, set = s.set, cur = p.cur, sp = s.sup.find(x => x.id === p.s);
  const rows = p.items.map((x, k) => `<tr><td class=cen>${k + 1}</td><td>${esc(x.n)}</td><td class=num>${fq(x.q)}</td><td class=num>${fm(x.co, cur)}</td><td class=num>${fm(c.lines[k].total, cur)}</td><td class="num rt">${c.lines[k].rq ? fq(c.lines[k].rq) : ''}</td></tr>`).join('');
  const tr = (l, val, cls) => `<tr class="${cls || ''}"><td>${l}</td><td class=num>${val}</td></tr>`;
  const st = p.void ? ['ملغاة', 'vd'] : v.due > 0 ? ['غير مسددة بالكامل', 'du'] : ['مسددة', 'pd'];
  printHTML(`<div class="a4 a5">
  <div class=a4h><div class=a4co>${set.logo ? `<img class=a4logo src="${esc(set.logo)}" alt="">` : ''}<div><h1>${esc(co.n)}</h1><div class=sm>${esc(co.ad)}${co.ph ? '<br>هاتف: ' + esc(co.ph) : ''}</div></div></div>
    <div class=a4ti><h2>فاتورة مشتريات</h2><table class=meta><tr><td>الرقم</td><td><b>${esc(p.no)}</b></td></tr><tr><td>التاريخ</td><td>${esc(p.date)}</td></tr><tr><td>الحالة</td><td><span class="stt ${st[1]}">${st[0]}</span></td></tr></table></div></div>
  <div class=a4cu><div><span>المورد</span><b>${esc(p.sn)}</b></div>${sp && sp.ph ? `<div><span>الهاتف</span><b>${esc(sp.ph)}</b></div>` : ''}${p.ref ? `<div><span>مرجع المورد</span><b>${esc(p.ref)}</b></div>` : ''}</div>
  <table class=a4t><thead><tr><th style="width:26px">#</th><th>البيان</th><th style="width:52px">الكمية</th><th style="width:72px">السعر</th><th style="width:80px">الإجمالي</th><th style="width:44px">مرتجع</th></tr></thead><tbody>${rows}</tbody></table>
  <div class=a4b><div class=a4n>${p.note ? `<h5>ملاحظة</h5><div>${esc(p.note)}</div>` : ''}</div>
    <table class=a4s>${tr('المجموع', fm(c.sub, cur))}${c.disc ? tr('الخصم', fm(c.disc, cur)) : ''}${c.tax ? tr('الضريبة (' + Money.fmtPct(p.rate) + '%)', fm(c.tax, cur)) : ''}${c.retGross ? tr('المرتجعات', fm(c.retGross, cur)) : ''}${tr('الإجمالي', fm(c.totEff, cur), 'tot')}${tr('المدفوع', fm(v.paid, cur))}${v.due > 0 ? tr('المتبقي للمورد', fm(v.due, cur), 'due') : ''}</table></div>
  <div class=a4g><div>توقيع المستلم</div><div>ختم وتوقيع المتجر</div></div></div>`, 'a5');
};

ACT.xlPur = () => {
  const all = purList(), d = c => decOf(c);
  const head = ['رقم الفاتورة', 'التاريخ', 'المورد', 'مرجع المورد', 'العملة', 'الإجمالي (بعد المرتجع)', 'المدفوع', 'المتبقي', 'الحالة'];
  const rows = all.map(({ p, v }) => [p.no, p.date, p.sn, p.ref || '', p.cur, xN(v.c.totEff, d(p.cur)), xN(v.paid, d(p.cur)), xN(v.due, d(p.cur)), purState(p, v)]);
  const lines = []; all.forEach(({ p, v }) => p.items.forEach((x, k) => lines.push([p.no, p.date, p.sn, x.n, xQ(x.q), xN(x.co, d(p.cur)), xN(v.c.lines[k].total, d(p.cur)), p.cur, v.c.lines[k].rq ? xQ(v.c.lines[k].rq) : ''])));
  xlDo('فواتير_الشراء', [{ name: 'فواتير الشراء', head, rows }, { name: 'بنود الشراء', head: ['رقم الفاتورة', 'التاريخ', 'المورد', 'البند', 'الكمية', 'سعر الشراء', 'إجمالي البند', 'العملة', 'الكمية المرتجعة'], rows: lines }]);
};
