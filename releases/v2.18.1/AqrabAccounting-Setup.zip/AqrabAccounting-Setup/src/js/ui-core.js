/* ui-core.js — أدوات الواجهة المشتركة: التخزين، النماذج، التنقل، الطباعة، النسخ الاحتياطي */
'use strict';
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const K = 'aqrab_db', KPW = 'aqrab_pw';
const AQS = (() => {
  try {
    if (window.aq) return { getItem: k => window.aq.get(k), setItem: (k, v) => window.aq.set(k, v), removeItem: k => window.aq.remove(k) };
    return window.localStorage;
  } catch (e) { return { getItem() { return null; }, setItem() { throw new Error('التخزين غير متاح'); }, removeItem() {} }; }
})();
const AQ = { en: null, me: null, tab: 'home', sub: {}, lastSave: null, mig: null };
const ACT = {}, INP = {}, CHG = {};
const S = () => AQ.en.S;
const can = p => E_can(S(), AQ.me, p);
const E_can = (st, uid, p) => Engine.can(st, uid, p);
const baseCode = () => S().set.base;
const cdef = c => Engine.curDef(S(), c || baseCode());
const decOf = c => cdef(c).dec;
const today = () => AQ.en.today();
const isoLocal = d => Engine.localDate(d);

/* ---- تنسيق ---- */
const LTR = s => '⁦' + s + '⁩';
function fm(amt, code) { const c = cdef(code), t = Money.fmt(amt, c.dec); return LTR(c.sym === '$' ? (amt < 0 ? '-$' + t.slice(1) : '$' + t) : t + ' ' + c.sym); }
const fq = q => LTR(Money.fmtQty(q));
const fdt = iso => { try { return LTR(new Date(iso).toLocaleString('en-GB', { hour12: false }).replace(',', '')); } catch (e) { return ''; } };
const pm = (str, dec) => { const v = Money.parse(str, dec); if (v === null) throw new Error('قيمة غير صحيحة'); return v; };
const mInput = (amt, dec) => Money.fmt(amt, dec, { nogroup: true });

/* ---- رسائل ---- */
function toast(msg, kind) {
  const d = document.createElement('div'); d.className = 'tt ' + (kind === 'err' ? 'err' : kind === 'ok' ? 'okk' : ''); d.textContent = msg;
  $('#toast').appendChild(d); setTimeout(() => d.remove(), kind === 'err' ? 6000 : 2800);
}
const fail = e => { console.error(e); toast(e && e.message ? e.message : String(e), 'err'); };

/* ---- نماذج ---- */
function closeModal() { $('#md').innerHTML = ''; }
ACT.close = closeModal;
function fieldHTML(f, v) {
  const id = 'f_' + f.k, val = v[f.k] == null ? '' : v[f.k];
  let inner;
  if (f.t === 'select') inner = `<select id=${id}>${f.opts.map(o => `<option value="${esc(o[0])}"${String(o[0]) === String(val) ? ' selected' : ''}>${esc(o[1])}</option>`).join('')}</select>`;
  else if (f.t === 'textarea') inner = `<textarea id=${id} rows=${f.rows || 3}>${esc(val)}</textarea>`;
  else if (f.t === 'check') return `<label class="ck${f.full ? ' full' : ''}"><input id=${id} type=checkbox${val ? ' checked' : ''}> ${esc(f.l)}</label>`;
  else if (f.t === 'file') inner = `<input id=${id} type=file accept="image/*">`;
  else if (f.t === 'date') inner = `<input id=${id} type=date value="${esc(val)}">`;
  else inner = `<input id=${id} type=${f.t === 'password' ? 'password' : 'text'} ${['money', 'qty', 'pct', 'rate'].includes(f.t) ? 'inputmode=decimal' : ''} value="${esc(val)}" placeholder="${esc(f.ph || '')}"${f.t === 'bc' ? ' inputmode=numeric' : ''}>`;
  return `<label class="${f.full ? 'full' : ''}">${esc(f.l)}${inner}</label>`;
}
function readImg(file, max) {
  max = max || 96;
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onerror = () => rej(new Error('تعذّرت قراءة الصورة'));
    r.onload = () => { const im = new Image(); im.onerror = () => rej(new Error('ملف الصورة غير صالح')); im.onload = () => { const s = max / Math.max(im.width, im.height, max), c = document.createElement('canvas'); c.width = Math.round(im.width * s); c.height = Math.round(im.height * s); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(max > 96 ? c.toDataURL('image/png') : c.toDataURL('image/jpeg', 0.8)); }; im.src = r.result; };
    r.readAsDataURL(file);
  });
}
async function collect(fields) {
  const o = {};
  for (const f of fields) {
    const el = $('#f_' + f.k); if (!el) continue;
    if (f.t === 'check') { o[f.k] = el.checked; continue; }
    if (f.t === 'file') { o[f.k] = el.files && el.files[0] ? await readImg(el.files[0], f.max) : undefined; continue; }
    const raw = el.value.trim();
    if (f.req && !raw) throw new Error('الحقل مطلوب: ' + f.l);
    if (['money', 'qty', 'pct', 'rate'].includes(f.t)) {
      if (raw === '') { o[f.k] = 0; continue; }
      const dec = f.t === 'money' ? (typeof f.dec === 'function' ? f.dec() : (f.dec != null ? f.dec : decOf())) : f.t === 'qty' ? 3 : f.t === 'pct' ? 2 : 6;
      const v = Money.parse(raw, dec); if (v === null) throw new Error('قيمة غير صحيحة: ' + f.l); o[f.k] = v;
    } else o[f.k] = raw;
  }
  return o;
}
/* o: {title, fields, values, submit(o)->error|void|Promise, msg, ok, size} */
function form(o) {
  const v = o.values || {};
  $('#md').innerHTML = `<div class=ov><div class="bx ${o.size || ''}"><h3>${o.title}</h3>${o.msg ? `<div class=msg>${o.msg}</div>` : ''}<div class=fgrid>${(o.fields || []).map(f => fieldHTML(f, v)).join('')}</div>${o.html || ''}<p id=er class=bd></p><div class=ac><button class=btn id=fok>${o.ok || 'تأكيد'}</button><button class=g2 data-a=close>إلغاء</button></div></div></div>`;
  const first = $('#md input:not([type=checkbox]),#md select'); if (first && !o.nofocus) first.focus();
  const ok = $('#fok');
  const run = async () => {
    if (ok.disabled) return; ok.disabled = true; $('#er').textContent = '';
    try { const vals = await collect(o.fields || []); const r = await o.submit(vals); if (r) $('#er').textContent = r; else closeModal(); }
    catch (e) { $('#er').textContent = e.message || String(e); }
    ok.disabled = false;
  };
  ok.onclick = run;
  $('#md').querySelectorAll('input:not([type=file]):not([type=checkbox])').forEach(i => i.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); run(); } }));
}
const ask = (title, msg, fn, okLabel) => form({ title, msg, fields: [], ok: okLabel, submit: async () => { await fn(); }, nofocus: true });
const info = (title, html) => { $('#md').innerHTML = `<div class=ov><div class="bx mid"><h3>${title}</h3>${html}<div class=ac><button class=g2 data-a=close>إغلاق</button></div></div></div>`; };

/* ---- جداول ---- */
const tbl = (h, rows, empty) => `<div class=tw><table><thead><tr>${h.map(x => `<th>${x}</th>`).join('')}</tr></thead><tbody>${rows.length ? rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('') : `<tr><td colspan=${h.length} class=mu style="text-align:center">${empty || 'لا توجد بيانات'}</td></tr>`}</tbody></table></div>`;
const chip = (t, k) => `<span class="chip ${k || ''}">${t}</span>`;
const btn = (a, label, data, cls) => `<button class="s ${cls || ''}" data-a="${a}" ${Object.entries(data || {}).map(([k, v]) => `data-${k}="${esc(v)}"`).join(' ')}>${label}</button>`;

/* ---- التنقل والتخطيط ---- */
const NAV = [
  ['home', 'الرئيسية', '⌂', () => true],
  ['pos', 'نقطة البيع', '🛒', () => can('sell')],
  ['sales', 'المبيعات', '📈', () => ['sell', 'ret', 'collect', 'invedit', 'void', 'rep'].some(can)],
  ['purchases', 'المشتريات والموردون', '🧾', () => can('buy') || can('rep')],
  ['inventory', 'المخزون والمنتجات', '📦', () => ['prod', 'stock', 'sell', 'rep'].some(can)],
  ['customers', 'العملاء والمندوبون', '👥', () => ['party', 'sell', 'collect'].some(can)],
  ['expenses', 'المصاريف والصندوق', '💵', () => can('exp') || can('cash')],
  ['fx', 'جلسة العملات', '💱', () => can('fx')],
  ['reports', 'التقارير', '📊', () => can('rep')],
  ['users', 'إدارة المستخدمين', '🔐', () => can('users')],
  ['settings', 'الإعدادات', '⚙', () => can('set') || can('backup')]
];
function shell() {
  const u = Engine && S().users.find(x => x.id === AQ.me);
  $('#app').innerHTML = `<div class=shell>
  <header class=top><div class=brand><img src="icon.png" alt=""><div><b>العقرب الحسابي</b><small>النظام المحاسبي المتكامل</small></div></div>
  <div class=tinfo><button class="usr posonly" data-a=posExit title="العودة إلى الرئيسية">← الرئيسية</button><button class="usr posonly" data-a=winFs title="ملء الشاشة (F11)">⛶ ملء الشاشة</button><div class=it>📅 <bdi id=dt></bdi></div><div class=it>🕓 <bdi id=clk></bdi></div><button class=usr data-a=umenu>👤 <span>${esc(u ? u.name : '')}</span> ▾</button></div></header>
  <nav class=side id=nv></nav><main id=mn></main>
  <footer class=status><span><b>${esc(S().co.n)}</b> — النظام المحاسبي المتكامل</span><span><i class=dot></i><span id=sv>البيانات محفوظة تلقائيًا</span></span></footer></div>`;
  tick();
}
function tick() { const d = new Date(); const a = $('#dt'), b = $('#clk'); if (a) a.textContent = d.getFullYear() + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + String(d.getDate()).padStart(2, '0'); if (b) b.textContent = d.toLocaleTimeString('en-US'); }
setInterval(tick, 1000);
function saved() { AQ.lastSave = new Date(); const s = $('#sv'); if (s) s.textContent = 'آخر حفظ ' + AQ.lastSave.toLocaleTimeString('en-GB'); }
function go(tab, sub) { AQ.tab = tab; if (sub) AQ.sub[tab] = sub; render(); }
function render() {
  if (!$('#nv')) return;
  const items = NAV.filter(n => n[3]());
  if (!items.some(n => n[0] === AQ.tab)) AQ.tab = items[0] ? items[0][0] : 'home';
  $('#nv').innerHTML = items.map(n => `<button class="${n[0] === AQ.tab ? 'on' : ''}" data-a=nav data-t="${n[0]}"><span class=ic>${n[2]}</span><span class=tx>${n[1]}</span></button>`).join('');
  const m = $('#mn'); m.className = AQ.tab === 'pos' ? 'pos' : '';
  const sh = $('.shell'); if (sh) sh.classList.toggle('posfull', AQ.tab === 'pos');
  try { m.innerHTML = PAGES[AQ.tab](); if (HOOKS[AQ.tab]) HOOKS[AQ.tab](); } catch (e) { m.innerHTML = '<div class=cd><h3>حدث خطأ في عرض الصفحة</h3><p class=bd>' + esc(e.message) + '</p></div>'; console.error(e); }
}
const PAGES = {}, HOOKS = {};
ACT.nav = d => go(d.t);
ACT.posExit = () => go('home');
ACT.winFs = () => { if (window.aq && aq.toggleFullscreen) aq.toggleFullscreen(); else if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); };
document.addEventListener('keydown', e => { if (e.key === 'F11') { e.preventDefault(); ACT.winFs(); } });
ACT.sub = d => { AQ.sub[AQ.tab] = d.s; render(); };
const tabsHTML = (list, cur) => `<div class=tabs>${list.map(([k, l]) => `<button class="${k === cur ? 'on' : ''}" data-a=sub data-s="${k}">${l}</button>`).join('')}</div>`;
const curSub = (page, def) => AQ.sub[page] || def;
ACT.umenu = () => form({
  title: 'حسابي', size: '', fields: [], ok: 'تغيير كلمة السر', nofocus: true,
  html: `<p>${esc(S().users.find(x => x.id === AQ.me).name)} — ${esc(Engine.ROLES[S().users.find(x => x.id === AQ.me).role].name)}</p><div class=ac><button class=g2 data-a=logout>تسجيل الخروج</button></div>`,
  submit: async () => { setTimeout(changePw, 0); }
});
function changePw() {
  form({ title: 'تغيير كلمة السر', fields: [{ k: 'o', l: 'الحالية', t: 'password', full: 1 }, { k: 'n', l: 'الجديدة', t: 'password', full: 1 }, { k: 'n2', l: 'تأكيد الجديدة', t: 'password', full: 1 }], submit: async v => { if (v.n !== v.n2) return 'التأكيد لا يطابق'; await AQ.en.changeOwnPassword(AQ.me, v.o, v.n); toast('تم تغيير كلمة السر', 'ok'); } });
}
ACT.logout = () => { try { sessionStorage.removeItem('aq_uid'); } catch (e) {} AQ.me = null; closeModal(); $('#app').innerHTML = ''; gate(); };

/* ---- مستمعات عامة ---- */
document.addEventListener('click', e => { const t = e.target.closest('[data-a]'); if (!t || t.disabled) return; const f = ACT[t.dataset.a]; if (f) { e.preventDefault(); try { const r = f(t.dataset, t, e); if (r && r.catch) r.catch(fail); } catch (er) { fail(er); } } });
document.addEventListener('input', e => { const t = e.target; if (t.dataset && t.dataset.i && INP[t.dataset.i]) INP[t.dataset.i](t.value, t, e); });
/* توحيد النص العربي للبحث: يتجاهل التشكيل والتطويل والفروق (أ إ آ ← ا) و(ى ← ي) و(ة ← ه) */
const nrm = v => String(v == null ? '' : v).toLowerCase().replace(/[\u064B-\u065F\u0670\u0640]/g, '').replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/ة/g, 'ه').replace(/\s+/g, ' ').trim();
/* بحث فوري: حقول البحث (data-c تنتهي بـ q) تُحدّث النتائج أثناء الكتابة مع بقاء المؤشر في الحقل */
let liveT = 0;
document.addEventListener('input', e => {
  const t = e.target, k = t && t.dataset && t.dataset.c;
  if (!k || !/q$/.test(k) || !CHG[k] || t.tagName !== 'INPUT') return;
  clearTimeout(liveT);
  liveT = setTimeout(() => {
    const pos = t.selectionStart, val = t.value;
    CHG[k](val, t, e);
    const n = document.querySelector('[data-c=' + k + ']');
    if (n && n !== t) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (x) {} }
  }, 180);
});
document.addEventListener('change', e => { const t = e.target; if (t.dataset && t.dataset.c && CHG[t.dataset.c]) CHG[t.dataset.c](t.value, t, e); });
const KEYS = [];
document.addEventListener('keydown', e => { for (const k of KEYS) if (k(e)) return; });

/* ---- الطباعة ---- */
function printHTML(html, kind) {
  $('#pr').innerHTML = html;
  let st = $('#pgs'); if (!st) { st = document.createElement('style'); st.id = 'pgs'; document.head.appendChild(st); }
  st.textContent = kind === 'rc' ? '@page{size:80mm auto;margin:2mm}' : kind === 'a5' ? '@page{size:A5;margin:8mm}' : '@page{size:A4;margin:10mm}';
  PVK = kind; PVH = html;
  /* معاينة داخل البرنامج (نافذة طباعة ويندوز داخل Electron لا تدعم المعاينة) */
  $('#md').innerHTML = `<div class=ov><div class="bx pvbox"><div class=pvbar><b>معاينة الطباعة</b><span class=sp></span>${window.aq && window.aq.printDirect ? `<select id=pvprn title="الطابعة"><option value="">الطابعة الافتراضية للنظام</option></select><button class=btn data-a=pvDirect>🖨 طباعة</button><button class=g2 data-a=pvPrint>⚙ خيارات الطباعة</button>` : '<button class=btn data-a=pvPrint>🖨 طباعة</button>'}${window.aq && window.aq.printPdf ? '<button class=g2 data-a=pvPdf>📄 حفظ PDF</button>' : ''}<button class=g2 data-a=close>إغلاق</button></div><div class=pvwrap><div class="sheet ${kind === 'rc' ? 'rcsheet' : kind === 'a5' ? 'a5sheet' : 'a4sheet'}">${html}</div></div></div></div>`;
  document.dispatchEvent(new Event('pvopen'));
}
let PVK = 'a5', PVH = '';
if (window.aq && window.aq.printers) document.addEventListener('pvopen', async () => {
  const sel = $('#pvprn'); if (!sel) return;
  try { const r = await window.aq.printers(); (r.items || []).forEach(p => { const o = document.createElement('option'); o.value = p.name; o.textContent = p.label + (p.def ? ' (الافتراضية)' : ''); sel.appendChild(o); }); if (r.saved && (r.items || []).some(p => p.name === r.saved)) sel.value = r.saved; } catch (e) {}
});
const pvArgs = () => {
  const sel = $('#pvprn'), sh = document.querySelector('.pvbox .sheet');
  return { kind: PVK, html: PVH, printer: sel ? sel.value : '', heightMm: sh ? Math.ceil(sh.getBoundingClientRect().height * 25.4 / 96) : 150 };
};
ACT.pvDirect = async () => {
  const r = await window.aq.printDirect(pvArgs());
  if (r && r.ok) toast('أُرسلت الفاتورة إلى الطابعة', 'ok'); else toast((r && r.error) || 'تعذّرت الطباعة', 'err');
};
ACT.pvPrint = async () => {
  if (!(window.aq && window.aq.printDialog)) { window.print(); return; }
  const r = await window.aq.printDialog(pvArgs());
  if (r && r.ok) toast('أُرسلت الفاتورة إلى الطابعة', 'ok'); else if (r && r.error && r.error !== 'أُلغيت الطباعة') toast(r.error, 'err');
};
ACT.pvPdf = async () => { try { const r = await window.aq.printPdf(pvArgs()); if (r && r.ok) toast('تم حفظ ملف PDF', 'ok'); else if (r && r.error) toast(r.error, 'err'); } catch (e) { toast('تعذّر إنشاء PDF', 'err'); } };
function docHeader() { const o = S().co; return `<h4>${esc(o.n)}</h4><div class=c>${esc(o.ad)} ${o.ph ? ' — هاتف: ' + esc(o.ph) : ''}${o.tx ? '<br>الرقم الضريبي: ' + esc(o.tx) : ''}</div>`; }
function invoiceA5(id) {
  const v = S().inv.find(x => x.id === id), w = Engine.invView(S(), v), c = w.c, co = S().co, set = S().set;
  const cu = (S().cust || []).find(x => x.id === v.c);
  const rows = v.items.map((x, k) => `<tr><td class=cen>${k + 1}</td><td>${esc(x.n)}</td><td class=num>${fq(x.q)}</td><td class=num>${fm(x.pr, v.cur)}</td><td class=num>${fm(c.lines[k].total, v.cur)}</td><td class="num rt">${c.lines[k].rq ? fq(c.lines[k].rq) : ''}</td></tr>`).join('');
  const tr = (l, val, cls) => `<tr class="${cls || ''}"><td>${l}</td><td class=num>${val}</td></tr>`;
  const ex = v.ex || [], exSum = ex.reduce((a, e) => a + e.a, 0);
  const exRows = ex.length ? `<tr class=exh><td colspan=2>رسوم إضافية (غير مشمولة في الإجمالي أعلاه)</td></tr>` + ex.map(e => `<tr class=exr><td>${esc(e.l)}</td><td class=num>${fm(e.a, v.cur)}</td></tr>`).join('') + tr('الإجمالي مع الرسوم الإضافية', fm(c.totEff + exSum, v.cur), 'exs') : '';
  const state = v.void ? ['ملغاة', 'vd'] : (w.due > 0 ? ['غير مسددة بالكامل', 'du'] : ['مسددة', 'pd']);
  printHTML(`<div class="a4 a5">
  <div class=a4h><div class=a4co>${set.logo ? `<img class=a4logo src="${esc(set.logo)}" alt="">` : ''}<div><h1>${esc(co.n)}</h1><div class=sm>${esc(co.ad)}${co.ph ? '<br>هاتف: ' + esc(co.ph) : ''}${co.tx ? '<br>الرقم الضريبي: ' + esc(co.tx) : ''}</div></div></div>
    <div class=a4ti><h2>فاتورة مبيعات</h2><table class=meta><tr><td>رقم الفاتورة</td><td><b>${esc(v.no)}</b></td></tr><tr><td>التاريخ</td><td>${esc(v.date)}</td></tr><tr><td>الحالة</td><td><span class="stt ${state[1]}">${state[0]}</span></td></tr></table></div></div>
  <div class=a4cu><div><span>العميل</span><b>${esc(v.cn)}</b></div>${cu && cu.ph ? `<div><span>الهاتف</span><b>${esc(cu.ph)}</b></div>` : ''}${cu && cu.ad ? `<div><span>العنوان</span><b>${esc(cu.ad)}</b></div>` : ''}${v.rn ? `<div><span>المندوب</span><b>${esc(v.rn)}</b></div>` : ''}</div>
  <table class=a4t><thead><tr><th style="width:26px">#</th><th>البيان</th><th style="width:52px">الكمية</th><th style="width:72px">السعر</th><th style="width:80px">الإجمالي</th><th style="width:44px">مرتجع</th></tr></thead><tbody>${rows}</tbody></table>
  <div class=a4b><div class=a4n>${set.terms ? `<h5>ملاحظات وشروط</h5><div>${esc(set.terms).replace(/\n/g, '<br>')}</div>` : ''}</div>
    <table class=a4s>${tr('المجموع', fm(c.sub, v.cur))}${c.disc ? tr('الخصم', fm(c.disc, v.cur)) : ''}${c.tax ? tr('الضريبة (' + Money.fmtPct(v.rate) + '%)', fm(c.tax, v.cur)) : ''}${c.retGross ? tr('المرتجعات', fm(c.retGross, v.cur)) : ''}${tr('الإجمالي', fm(c.totEff, v.cur), 'tot')}${tr('المدفوع', fm(w.paid, v.cur))}${w.due > 0 ? tr('المتبقي', fm(w.due, v.cur), 'due') : ''}${exRows}</table></div>
  <div class=a4g><div>توقيع المستلم</div><div>ختم وتوقيع المتجر</div></div>
  <div class=a4f>${esc(set.rfoot)}</div></div>`, 'a5');
}
function receipt(id) {
  const v = S().inv.find(x => x.id === id), w = Engine.invView(S(), v), c = w.c;
  const rows = v.items.map((x, k) => `<tr><td colspan=3>${esc(x.n)}</td></tr><tr><td class=num>${fq(x.q)} × ${fm(x.pr, v.cur)}</td><td></td><td class=num>${fm(c.lines[k].total, v.cur)}</td></tr>`).join('');
  printHTML(`<div class=rc>${docHeader()}<hr><div class=t><span>فاتورة: ${esc(v.no)}</span><span>${v.date}</span></div><div>العميل: ${esc(v.cn)}</div><hr><table>${rows}</table><hr>
  <div class=t><span>المجموع</span><span>${fm(c.sub, v.cur)}</span></div>${c.disc ? `<div class=t><span>الخصم</span><span>${fm(c.disc, v.cur)}</span></div>` : ''}${c.tax ? `<div class=t><span>الضريبة (${Money.fmtPct(v.rate)}%)</span><span>${fm(c.tax, v.cur)}</span></div>` : ''}
  <div class="t big"><span>الإجمالي</span><span>${fm(c.totEff, v.cur)}</span></div><div class=t><span>المدفوع</span><span>${fm(w.paid, v.cur)}</span></div>${w.due > 0 ? `<div class=t><span>المتبقي</span><span>${fm(w.due, v.cur)}</span></div>` : ''}
  <hr><div class=c>${esc(S().set.rfoot)}</div></div>`, 'rc');
}
/* الفاتورة تُطبع بمقاس A5 فقط */
ACT.print = d => invoiceA5(d.id);
ACT.printA4 = ACT.printRc = ACT.printA5 = d => invoiceA5(d.id);

/* ---- النسخ الاحتياطي والاستعادة (سطح المكتب) ---- */
const KL = { manual: 'يدوية', close: 'عند الإغلاق', auto: 'تلقائية (كل 20 دقيقة عند التغيير)', daily: 'يومية', 'pre-restore': 'قبل استعادة', 'pre-delete': 'قبل مسح البيانات', 'pre-migrate': 'قبل الترحيل', 'pre-import': 'قبل الاستيراد', export: 'تصدير' };
const fsz = b => (b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
const stx = s => (s ? `${s.inv} فاتورة، ${s.cust} عميل، ${s.prod} منتج` : '');
function afterRestore(r) {
  if (!r || !r.ok) { alert((r && r.error) || 'فشلت الاستعادة'); return; }
  alert('تمت الاستعادة بنجاح.' + (r.safety ? '\nتم حفظ نسخة أمان للبيانات السابقة (' + r.safety + ').' : '') + '\nسجّل الدخول من جديد.');
  try { sessionStorage.removeItem('aq_uid'); } catch (e) {}
  location.reload();
}
async function lgRestore() {
  const el = $('#lrs'); if (!el || !window.aq) return;
  let inf; try { inf = await aq.info(); } catch (e) { return; }
  const b = inf.items, first = !S().users.length && b.length;
  el.innerHTML = `<details ${first ? 'open' : ''}><summary>↩ استعادة من نسخة احتياطية</summary><div style="margin-top:8px">${first ? `<p style="font-size:13px">وُجدت ${b.length} نسخة احتياطية.<br>آخر نسخة: ${fdt(b[0].created)}<br>${stx(b[0].stats)}</p><button class="btn" style="width:100%;margin-bottom:6px" id=lr1>استعادة آخر نسخة</button>` : ''}<button class=g2 style="width:100%;margin-bottom:6px" id=lr2>📂 اختيار ملف نسخة احتياطية…</button><button class=g2 style="width:100%" id=lr3>📋 استعادة من نص منسوخ (النسخة القديمة)</button><div id=lr4></div></div></details>`;
  const warn = S().users.length ? '\n\nسيتم استبدال البيانات الحالية (مع حفظ نسخة أمان منها).' : '';
  if (first) $('#lr1').onclick = () => { if (confirm('استعادة نسخة ' + b[0].created.slice(0, 16).replace('T', ' ') + '؟' + warn)) aq.restore(b[0].name).then(afterRestore); };
  $('#lr2').onclick = async () => { const p = await aq.pick(); if (p.canceled) return; if (!p.ok) { alert(p.error); return; } if (confirm('استعادة من الملف «' + p.file + '»\n' + stx(p.stats) + warn)) aq.restorePicked().then(afterRestore); };
  $('#lr3').onclick = () => { $('#lr4').innerHTML = '<textarea id=lt rows=4 placeholder="الصق نص النسخة الاحتياطية القديمة هنا"></textarea><button class=btn style="width:100%;margin-top:6px" id=lt2>استعادة</button>'; $('#lt2').onclick = () => { if (confirm('استعادة البيانات من النص؟' + warn)) aq.restoreText($('#lt').value).then(afterRestore); }; };
}
function backupCard() {
  if (!can('backup')) return '';
  if (!window.aq) return `<div class=cd><h3>النسخ الاحتياطي</h3><p class=mu>النسخ الاحتياطي التلقائي متاح في نسخة سطح المكتب فقط.</p></div>`;
  return `<div class=cd><h3>النسخ الاحتياطي والاستعادة</h3>
<p class=mu style="margin-top:0">بياناتك تُحفظ تلقائيًا على جهازك أثناء العمل. النسخ الاحتياطية تُحفظ في مجلد منفصل (داخل «المستندات») فتبقى سليمة حتى لو حُذف البرنامج أو بياناته، ويمكنك استعادتها في أي وقت.</p>
<div id=bi class=pth>…</div>
<div class=bka><button class=btn data-a=bkNow>💾 إنشاء نسخة الآن</button><button class=g2 data-a=bkExport>📤 تصدير نسخة إلى مكان آخر…</button><button class=g2 data-a=bkImport>📂 استعادة من ملف…</button><button class=g2 data-a=bkOpen>🗁 فتح مجلد النسخ</button><button class=g2 data-a=bkDir>تغيير المجلد…</button></div>
<div class=cd style="background:var(--bg);margin:10px 0"><b>🛟 نسخة إضافية في مكان آخر (موصى به)</b><p class=mu style="margin:4px 0">كل نسخة احتياطية تُنسخ أيضًا إلى مجلد ثانٍ، مثل فلاش أو قرص خارجي أو مجلد OneDrive. فإذا تعطّل القرص أو سُرق الجهاز تبقى بياناتك.</p><div id=bm class=pth></div><div class=bka><button class=g2 data-a=bkMirror>اختيار مجلد النسخة الإضافية…</button><button class=g2 data-a=bkMirrorOff id=bmoff style="display:none">إيقاف</button></div></div>
<label style="max-width:380px">عند إغلاق البرنامج<select id=oc data-c=onclose><option value=ask>اسألني هل أحفظ نسخة احتياطية</option><option value=auto>احفظ نسخة تلقائيًا دائمًا</option><option value=never>لا تحفظ نسخة</option></select></label>
<h3 style="margin-top:14px">النسخ المحفوظة</h3><div id=bl>جارٍ التحميل…</div>
<details style="margin-top:12px"><summary style="cursor:pointer">استعادة من نص منسوخ (النسخة القديمة)</summary><textarea id=bt rows=3 placeholder="الصق نص النسخة الاحتياطية القديمة هنا"></textarea><div class=ac><button class=g2 data-a=bkTxt>استعادة من النص</button></div></details>
${can('users') ? '<div class=ac style="margin-top:14px"><button class="g2 dl" data-a=bkClear>مسح كل البيانات</button></div>' : ''}
<p class=mu style="font-size:12px">ملاحظة: ملفات النسخ الاحتياطية غير مشفّرة، فاحفظها في مكان آمن.</p></div>`;
}
async function ldb() {
  if (!window.aq || !$('#bl')) return;
  let inf; try { inf = await aq.info(); } catch (e) { return; } if (!$('#bl')) return;
  $('#bi').innerHTML = 'ملف البيانات: ' + esc(inf.dataFile) + '<br>مجلد النسخ: ' + esc(inf.dir) + '<br>آخر نسخة: ' + (inf.settings.lastBackupAt ? fdt(inf.settings.lastBackupAt) : 'لا توجد') + ' | الإصدار ' + esc(inf.version);
  $('#oc').value = inf.settings.onClose;
  const lm = inf.settings.lastMirror;
  $('#bm').innerHTML = inf.mirrorDir ? 'المجلد: ' + esc(inf.mirrorDir) + '<br>' + (lm ? (lm.ok ? '<span class=ok>آخر نسخة إضافية ناجحة: ' + fdt(lm.at) + '</span>' : '<span class=bd>فشل آخر نسخ إضافي: ' + esc(lm.error) + ' — تأكد أن الفلاش/القرص موصول.</span>') : 'لم تُنشأ نسخة بعد') : '<span class=mu>غير مفعّلة — الاعتماد على نسخة واحدة على نفس الجهاز.</span>';
  $('#bmoff').style.display = inf.mirrorDir ? '' : 'none';
  if (inf.saveErr) $('#bi').innerHTML += '<br><b class=bd>⚠ تعذّر حفظ البيانات: ' + esc(inf.saveErr) + '</b>';
  $('#bl').innerHTML = tbl(['التاريخ', 'النوع', 'المحتوى', 'الحجم', ''], inf.items.map(b => [fdt(b.created), KL[b.kind] || esc(b.kind), stx(b.stats), fsz(b.size), btn('bkRes', 'استعادة', { n: b.name }) + btn('bkDel', 'حذف', { n: b.name }, 'dl')]));
}
HOOKS.settings = ldb;
CHG.onclose = v => aq.setOnClose(v);
const bkMsg = (t, m) => info(t, '<p>' + m + '</p>');
ACT.bkMirror = async () => { const r = await aq.chooseMirror(); if (r.error) return bkMsg('النسخة الإضافية', esc(r.error)); if (!r.ok) return; bkMsg('النسخة الإضافية', r.test && r.test.mirror && r.test.mirror.ok ? 'تم التفعيل وأُنشئت نسخة تجريبية بنجاح في:<br><span class=pth>' + esc(r.dir) + '</span>' : 'تم اختيار المجلد لكن النسخة التجريبية فشلت: ' + esc((r.test && (r.test.error || (r.test.mirror && r.test.mirror.error))) || '')); ldb(); };
ACT.bkMirrorOff = () => aq.clearMirror().then(ldb);
ACT.bkNow = () => aq.backup('manual').then(r => { bkMsg('النسخ الاحتياطي', r.ok ? 'تم حفظ النسخة الاحتياطية بنجاح وتم التحقق منها (قراءة ومطابقة):<br><span class=pth>' + esc(r.file) + '</span>' + (r.mirror ? (r.mirror.ok ? '<br>✓ نسخة إضافية: <span class=pth>' + esc(r.mirror.file) + '</span>' : '<br><b class=bd>⚠ فشلت النسخة الإضافية: ' + esc(r.mirror.error) + '</b>') : '') : esc(r.error)); ldb(); });
ACT.bkExport = () => aq.exportTo().then(r => { if (r.canceled) return; bkMsg('تصدير نسخة', r.ok ? 'تم التصدير إلى:<br><span class=pth>' + esc(r.file) + '</span>' : esc(r.error)); });
ACT.bkImport = async () => { const p = await aq.pick(); if (p.canceled) return; if (!p.ok) return bkMsg('خطأ', esc(p.error)); ask('استعادة من ملف', 'الملف: ' + esc(p.file) + '<br>' + stx(p.stats) + '<br><b>سيتم استبدال البيانات الحالية</b> (مع حفظ نسخة أمان منها تلقائيًا).', () => aq.restorePicked().then(afterRestore)); };
ACT.bkOpen = () => aq.openDir();
ACT.bkDir = () => aq.chooseDir().then(r => { if (r.ok) ldb(); });
ACT.bkRes = d => ask('استعادة نسخة', '<b>سيتم استبدال البيانات الحالية</b> بمحتوى هذه النسخة، مع حفظ نسخة أمان من البيانات الحالية قبل ذلك.', () => aq.restore(d.n).then(afterRestore));
ACT.bkDel = d => ask('حذف النسخة', 'حذف ملف النسخة الاحتياطية نهائيًا؟', () => aq.remove_backup(d.n).then(ldb));
ACT.bkTxt = () => { const t = $('#bt').value; if (!t.trim()) return; ask('استعادة من نص', '<b>سيتم استبدال البيانات الحالية</b> (مع حفظ نسخة أمان منها).', () => aq.restoreText(t).then(afterRestore)); };
ACT.bkClear = () => ask('مسح كل البيانات', 'سيتم مسح كل الفواتير والمنتجات والعملاء والحركات (يبقى المستخدمون والإعدادات). قبل المسح تُحفظ نسخة احتياطية تلقائيًا يمكنك الاستعادة منها.', async () => {
  const r = await aq.backup('pre-delete'); if (!r.ok && !r.empty) throw new Error('لم يتم المسح لأن النسخة الأمنية فشلت: ' + r.error);
  const keep = { co: S().co, set: S().set, users: S().users, audit: S().audit };
  AQ.en.tx(D => { Object.assign(D, { cust: [], sup: [], rep: [], prod: [], inv: [], pur: [], exp: [], cash: [], mv: [], seq: { inv: 1, pur: 1, ret: 1, pret: 1 } }); AQ.en.log(D, AQ.me, 'data.clear', null, 'مسح كل البيانات (نسخة أمان: ' + (r.name || 'لا بيانات') + ')'); });
  toast('تم مسح البيانات', 'ok'); render();
}, 'مسح نهائي');
