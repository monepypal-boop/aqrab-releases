/* ui-guard.js — تنبيهات حماية البيانات: فشل الحفظ على القرص، فشل النسخ الاحتياطي، وتأخّر النسخ الاحتياطي. عرض فقط. */
'use strict';
const GUARD = { save: '', backup: '', stale: '' };
function guardRender() {
  let b = document.getElementById('guardbar');
  const msgs = [GUARD.save && ['err', '⚠ تعذّر حفظ بياناتك على القرص: ' + GUARD.save + ' — لا تُغلق البرنامج، تأكد من مساحة القرص، وسيعيد البرنامج المحاولة تلقائيًا كل 5 ثوانٍ.'], GUARD.backup && ['err', '⚠ فشل النسخ الاحتياطي التلقائي: ' + GUARD.backup], GUARD.stale && ['warn', GUARD.stale]].filter(Boolean);
  if (!msgs.length) { if (b) b.remove(); document.body.classList.remove('hasguard'); return; }
  if (!b) { b = document.createElement('div'); b.id = 'guardbar'; document.body.appendChild(b); }
  b.innerHTML = msgs.map(m => `<div class="gb ${m[0]}">${esc(m[1])}</div>`).join('') + (GUARD.stale && !GUARD.save && !GUARD.backup ? '<button class=gbb data-a=guardBackup>💾 إنشاء نسخة الآن</button>' : '');
  document.body.classList.add('hasguard'); document.documentElement.style.setProperty('--gh', b.offsetHeight + 'px');
}
ACT.guardBackup = async () => { const r = await aq.backup('manual'); if (r.ok) { GUARD.stale = ''; GUARD.backup = ''; toast('تم حفظ نسخة احتياطية والتحقق منها', 'ok'); } else toast(r.error || 'فشلت النسخة', 'err'); guardRender(); };
async function guardCheck() {
  if (!window.aq || !aq.info) return;
  try {
    const inf = await aq.info(), last = inf.settings.lastBackupAt ? Date.parse(inf.settings.lastBackupAt) : 0;
    const hasInv = AQ.en && AQ.en.S && AQ.en.S.inv && AQ.en.S.inv.length > 0;
    const days = (Date.now() - last) / 864e5;
    GUARD.stale = hasInv && (!last || days > 3) ? (last ? `لم تُحفظ نسخة احتياطية منذ ${Math.floor(days)} أيام.` : 'لا توجد أي نسخة احتياطية لبياناتك بعد.') : '';
    GUARD.save = inf.saveErr || '';
    if (inf.mirrorDir && inf.settings.lastMirror && !inf.settings.lastMirror.ok) GUARD.backup = 'النسخة الإضافية فشلت: ' + inf.settings.lastMirror.error; else if (GUARD.backup.startsWith('النسخة الإضافية')) GUARD.backup = '';
  } catch (e) { /* لا شيء */ }
  guardRender();
}
if (window.aq) {
  if (aq.onStoreError) aq.onStoreError(m => { GUARD.save = m || 'خطأ غير معروف'; guardRender(); });
  if (aq.onStoreOk) aq.onStoreOk(() => { GUARD.save = ''; guardRender(); toast('عاد الحفظ إلى القرص بنجاح', 'ok'); });
  if (aq.onBackupWarn) aq.onBackupWarn(m => { GUARD.backup = m; guardRender(); });
  setTimeout(guardCheck, 8000); setInterval(guardCheck, 30 * 60 * 1000);
}
