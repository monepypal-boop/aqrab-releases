'use strict';
/* storage.js — كتابة/قراءة آمنة لملفات البيانات والنسخ الاحتياطي (بدون اعتماد على Electron ليسهل اختبارها).
 * المبادئ:
 *  1) الكتابة الذرّية: ملف مؤقت ← fsync (إجبار القرص) ← إعادة تسمية. لا يبقى ملف نصف مكتوب.
 *  2) النسخة السابقة (.bak) لا تُحدَّث إلا إذا كان الملف الحالي سليمًا، فلا تتلف بنسخة تالفة.
 *  3) الملف التالف لا يُحذف ولا يُكتب فوقه: يُحفظ بجانبه باسم .corrupt-<وقت> ثم تُستعاد البيانات من .bak أو من آخر نسخة احتياطية.
 *  4) كل نسخة احتياطية يُعاد قراءتها بعد كتابتها للتأكد أنها مطابقة تمامًا.
 *  5) سياسة الاحتفاظ بالنسخ بحسب نوعها، حتى لا تطرد النسخ الدورية الكثيرة النسخ المهمة. */
const fs = require('fs');
const path = require('path');

const pad = n => String(n).padStart(2, '0');
function stamp(d = new Date()) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}
const todayStr = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

function isJson(text) { try { JSON.parse(text); return true; } catch (e) { return false; } }
function readText(file) { try { return fs.readFileSync(file, 'utf8'); } catch (e) { return null; } }
function readJson(file) { const t = readText(file); if (t == null) return null; try { return JSON.parse(t); } catch (e) { return null; } }

/* كتابة ذرّية مع fsync. opts.noBak لتعطيل نسخة .bak (للنسخ الاحتياطية نفسها). */
function writeAtomic(file, text, opts) {
  opts = opts || {};
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = file + '.tmp';
  const fd = fs.openSync(tmp, 'w');
  try {
    fs.writeSync(fd, text, null, 'utf8');
    try { fs.fsyncSync(fd); } catch (e) { /* بعض أنظمة الملفات لا تدعمها */ }
  } finally { fs.closeSync(fd); }
  if (!opts.noBak) {
    try {
      const cur = readText(file);
      if (cur != null && isJson(cur)) fs.writeFileSync(file + '.bak', cur, 'utf8'); // لا نسخ لملف تالف
    } catch (e) { /* النسخة السابقة اختيارية */ }
  }
  fs.renameSync(tmp, file);
}

/* يقرأ مخزن البيانات مع الاسترداد. يُرجع { store, status, corruptCopy }
 * status: fresh (أول تشغيل) | ok | bak (استُرد من النسخة الداخلية) | lost (الملفان تالفان: مخزن فارغ والتالف محفوظ) */
function loadStore(file, validate) {
  const valid = d => d && typeof d === 'object' && d.items && typeof d.items === 'object' && (!validate || validate(d));
  const empty = () => ({ version: 1, items: {} });
  const hasMain = fs.existsSync(file), hasBak = fs.existsSync(file + '.bak');
  if (!hasMain && !hasBak) return { store: empty(), status: 'fresh' };
  const d = hasMain ? readJson(file) : null;
  if (valid(d)) return { store: d, status: 'ok' };
  let corruptCopy = '';
  if (hasMain) { // احفظ الملف التالف ولا تكتب فوقه
    try { corruptCopy = file + '.corrupt-' + stamp(); fs.copyFileSync(file, corruptCopy); } catch (e) { corruptCopy = ''; }
  }
  const b = readJson(file + '.bak');
  if (valid(b)) return { store: b, status: 'bak', corruptCopy };
  return { store: empty(), status: 'lost', corruptCopy };
}

/* سياسة الاحتفاظ: items مرتبة من الأحدث؛ تُرجع أسماء الملفات التي تُحذف. manual/export/غيرها لا تُحذف أبدًا. */
const KEEP = { auto: 12, daily: 30, close: 15, pre: 15 };
function pickPrune(items, keep) {
  keep = Object.assign({}, KEEP, keep || {});
  const groups = {};
  items.forEach(b => {
    const g = b.kind.startsWith('pre-') ? 'pre' : (Object.prototype.hasOwnProperty.call(keep, b.kind) ? b.kind : null);
    if (g) (groups[g] = groups[g] || []).push(b);
  });
  const del = [];
  Object.keys(groups).forEach(g => groups[g].slice(keep[g]).forEach(b => del.push(b.name)));
  return del;
}

/* يكتب نسخة احتياطية ثم يقرؤها ويتحقق أنها مطابقة. يُرجع { ok, error } */
function writeVerified(file, text) {
  try {
    writeAtomic(file, text, { noBak: true });
    const back = readText(file);
    if (back !== text) return { ok: false, error: 'تحقق القراءة بعد الكتابة فشل: الملف المحفوظ لا يطابق الأصل (قد يكون القرص ممتلئًا أو تالفًا).' };
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

module.exports = { stamp, todayStr, isJson, readText, readJson, writeAtomic, loadStore, pickPrune, writeVerified, KEEP };
