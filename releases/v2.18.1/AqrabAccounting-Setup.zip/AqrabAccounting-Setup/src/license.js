'use strict';
/* license.js — ترخيص بدون إنترنت: مفاتيح موقّعة بـ Ed25519 (غير مربوطة بجهاز): مفتاح دائم، ومفتاح تجريبي لمدة محددة تبدأ من لحظة التفعيل.
 * التطبيق يحمل المفتاح العام فقط؛ المفتاح الخاص عند البائع (tools/vendor) ولا يُشحن مع التطبيق. */
const crypto = require('crypto');
const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAbVOjCNHIEEixayPsMUKW7dpKWHMh6qSvPFMUtG9684w=
-----END PUBLIC KEY-----`;
const DAY = 86400000;

const b64u = b => Buffer.from(b).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = s => Buffer.from(String(s).replace(/-/g, '+').replace(/_/g, '/'), 'base64');

const clean = s => String(s || '').replace(/\s+/g, '');
function sign(payload, privatePem) {
  const body = b64u(JSON.stringify(payload));
  const sig = crypto.sign(null, Buffer.from(body), privatePem);
  return body + '.' + b64u(sig);
}
/* يتحقق من توقيع المفتاح فقط. أنواعه: perm (دائم) | trial (days يومًا من لحظة التفعيل) */
function verify(text, pub) {
  try {
    const [body, sig] = clean(text).split('.');
    if (!body || !sig) return { ok: false, reason: 'صيغة المفتاح غير صحيحة' };
    if (!crypto.verify(null, Buffer.from(body), pub || PUBLIC_KEY, unb64u(sig))) return { ok: false, reason: 'المفتاح غير أصلي أو معدَّل' };
    const p = JSON.parse(unb64u(body).toString('utf8'));
    if (!p || p.v !== 2 || (p.t !== 'perm' && p.t !== 'trial')) return { ok: false, reason: 'نوع المفتاح غير مدعوم' };
    if (p.t === 'trial' && !(Number.isInteger(p.days) && p.days > 0 && p.days <= 3650)) return { ok: false, reason: 'مدة المفتاح التجريبي غير صحيحة' };
    return { ok: true, info: p };
  } catch (e) { return { ok: false, reason: 'تعذّر قراءة المفتاح' }; }
}
/* التفعيل: يُرجع السجل الجديد. المفتاح التجريبي نفسه إذا أُعيد إدخاله لا يبدأ فترة جديدة. */
function activate(rec, text, now, pub) {
  const v = verify(text, pub); if (!v.ok) return { ok: false, error: v.reason };
  rec = Object.assign({ key: '', start: 0, seen: 0 }, rec || {});
  const k = clean(text);
  if (v.info.t === 'trial') {
    if (rec.key !== k) { // مفتاح تجريبي مختلف: إن كان هناك ترخيص دائم فعّال لا نستبدله بتجريبي
      const cur = rec.key ? verify(rec.key, pub) : null;
      if (cur && cur.ok && cur.info.t === 'perm') return { ok: false, error: 'البرنامج مرخّص بمفتاح دائم، لا حاجة لمفتاح تجريبي.' };
      rec.start = now;
    }
  } else rec.start = rec.start || now;
  rec.key = k; rec.seen = Math.max(rec.seen || 0, now);
  return { ok: true, rec };
}
/* حالة الترخيص. required=false (نسختك الشخصية): لا قفل أبدًا. */
function evaluate(rec, now, required, pub) {
  rec = Object.assign({ key: '', start: 0, seen: now }, rec || {});
  const rolled = now + DAY < rec.seen; // رجوع بالساعة للخلف
  if (!rolled) rec.seen = Math.max(rec.seen, now);
  const out = { required, rec };
  if (!required) return Object.assign(out, { status: 'off' });
  if (!rec.key) return Object.assign(out, { status: 'locked', reason: 'البرنامج غير مفعّل. أدخل مفتاح الترخيص (دائم أو تجريبي) للمتابعة.' });
  const v = verify(rec.key, pub);
  if (!v.ok) return Object.assign(out, { status: 'locked', reason: 'مفتاح الترخيص المحفوظ غير صالح: ' + v.reason });
  if (v.info.t === 'perm') return Object.assign(out, { status: 'ok', type: 'perm', name: v.info.name || '' });
  if (rolled) return Object.assign(out, { status: 'locked', reason: 'تم اكتشاف تغيير في ساعة الجهاز. أدخل مفتاح ترخيص دائمًا للمتابعة.' });
  const left = Math.ceil((rec.start + v.info.days * DAY - now) / DAY);
  if (left > 0) return Object.assign(out, { status: 'trial', type: 'trial', daysLeft: left, name: v.info.name || '', days: v.info.days });
  return Object.assign(out, { status: 'locked', type: 'trial', reason: 'انتهت الفترة التجريبية (' + v.info.days + ' يومًا). أدخل مفتاح الترخيص الدائم للمتابعة.' });
}
module.exports = { PUBLIC_KEY, sign, verify, activate, evaluate, b64u };
